package eventcalendar.model;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Map;

/**
 * Utility class providing common functionality for event operations.
 */
public class ModelUtils {

  /**
   * Adjusts an event's time considering timezone differences and date changes.
   * This method handles timezone conversion and date adjustments for events being
   * copied between different calendars or dates.
   *
   * @param originalStartTime The original start time of the event
   * @param sourceTimeZone    The timezone of the source calendar
   * @param targetTimeZone    The timezone of the target calendar
   * @param sourceDate        The source date (for calculating day differences)
   * @param targetDate        The target date (for calculating day differences)
   * @param eventDuration     The duration of the event
   * @return An array of LocalDateTime objects where index 0 is the adjusted start time
   *         and index 1 is the adjusted end time maintaining the original duration
   */
  protected static LocalDateTime[] adjustEventTimeForTimezoneAndDate(
          LocalDateTime originalStartTime,
          ZoneId sourceTimeZone,
          ZoneId targetTimeZone,
          LocalDate sourceDate,
          LocalDate targetDate,
          Duration eventDuration) {

    // Convert to ZonedDateTime in source timezone
    ZonedDateTime originalZonedStart = originalStartTime.atZone(sourceTimeZone);

    // Apply timezone adjustment
    ZonedDateTime targetZonedDateTime = originalZonedStart.withZoneSameInstant(targetTimeZone);

    // Calculate days difference between source and target date
    long daysDiff = ChronoUnit.DAYS.between(sourceDate, targetDate);

    // Adjust by the specified day difference
    targetZonedDateTime = targetZonedDateTime.plusDays(daysDiff);

    // Convert back to LocalDateTime for the builder
    LocalDateTime newStartDateTime = targetZonedDateTime.toLocalDateTime();

    // Calculate new end time maintaining the same duration
    LocalDateTime newEndDateTime = newStartDateTime.plus(eventDuration);

    return new LocalDateTime[]{newStartDateTime, newEndDateTime};
  }

  /**
   * Common logic to getValue from hashmap for a key and escaping quotes if they exist.
   */
  public static String getValue(Map<String, String> args, String key) {
    String value = args.get(key);

    // Remove quotes if they exist
    if (value != null && value.startsWith("\"") && value.endsWith("\"")) {
      value = value.substring(1, value.length() - 1);
    }
    if (value == null || value.isEmpty()) {
      return null;
    }
    return value;
  }

  /**
   * Common logic to change time of event when copying the event from one timeline to another.
   */
  public static boolean changeEventTime(Event event, ICalendar calendar,
                                        ZoneId sourceTimeZone,
                                        ZoneId targetTimeZone,
                                        LocalDate sourceDate,
                                        LocalDate targetDate) {
    // Get the original event's details
    LocalDateTime originalStartTime = event.getEventStartDateTime();
    LocalDateTime originalEndTime = event.getEventEndDateTime();
    Duration eventDuration = Duration.between(originalStartTime, originalEndTime);
    String eventName = event.getEventName();
    String eventDescription = event.getEventDescription();
    String eventLocation = event.getEventLocation();
    boolean isPublic = event.isPublic();

    // Use utility method to adjust event time for timezone and date
    LocalDateTime[] adjustedTimes = adjustEventTimeForTimezoneAndDate(
            originalStartTime, sourceTimeZone, targetTimeZone,
            sourceDate, targetDate, eventDuration);

    // Get the adjusted start and end times
    LocalDateTime newStartDateTime = adjustedTimes[0];
    LocalDateTime newEndDateTime = adjustedTimes[1];

    // Use the builder to create the new event
    SingleEvent.Builder builder = new SingleEvent.Builder(eventName, newStartDateTime)
            .eventEndDateTime(newEndDateTime);
    builder.isPublic(isPublic);

    // Add optional fields if they exist
    if (eventDescription != null && !eventDescription.isEmpty()) {
      builder.eventDescription(eventDescription);
    }
    if (eventLocation != null && !eventLocation.isEmpty()) {
      builder.eventLocation(eventLocation);
    }

    // Add to target calendar and return the boolean to the caller method.
    return calendar.addEvent(builder, true);
  }
}