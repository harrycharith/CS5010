package eventcalendar.view.dialogs;

import java.awt.Component;
import java.awt.GridLayout;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import eventcalendar.controller.commands.CreateCalendarCommand;
import eventcalendar.model.ICalendarManager;


/**
 * Manages dialog windows for calendar-related operations in the application.
 */
public class CalendarDialogManager {

  private final Component parentComponent;
  private final ICalendarManager calendarManager;

  /**
   * Constructor for CalendarDialogManager.
   */
  public CalendarDialogManager(Component parentComponent, ICalendarManager calendarManager) {
    this.parentComponent = parentComponent;
    this.calendarManager = calendarManager;
  }

  /**
   * Show dialog for creating a new calendar.
   *
   * @param onSuccess Callback for when a calendar is successfully created
   */
  public void showCreateCalendarDialog(Consumer<String> onSuccess) {
    JPanel panel = new JPanel(new GridLayout(0, 1));

    JTextField nameField = new JTextField(20);
    JTextField timezoneField = new JTextField("America/New_York", 20);

    panel.add(new JLabel("Calendar Name:"));
    panel.add(nameField);
    panel.add(new JLabel("Timezone (e.g., America/New_York):"));
    panel.add(timezoneField);

    int result = JOptionPane.showConfirmDialog(
            parentComponent, panel, "Create New Calendar",
            JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

    if (result == JOptionPane.OK_OPTION) {
      String name = nameField.getText().trim();
      String timezone = timezoneField.getText().trim();

      if (!name.isEmpty() && !timezone.isEmpty()) {
        // Use CreateCalendarCommand to create the calendar
        CreateCalendarCommand command = new CreateCalendarCommand(calendarManager);
        Map<String, String> args = new HashMap<>();
        args.put("calendarName", name);
        args.put("calendarTimeZone", timezone);

        String response = command.execute(args);

        // Show result to user
        JOptionPane.showMessageDialog(parentComponent, response);

        // Call success callback if successful
        if (response.startsWith("Calendar created successfully")) {
          onSuccess.accept(name);
        }
      } else {
        JOptionPane.showMessageDialog(
                parentComponent, "Calendar name and timezone cannot be empty.",
                "Invalid Input", JOptionPane.ERROR_MESSAGE);
      }
    }
  }
}
