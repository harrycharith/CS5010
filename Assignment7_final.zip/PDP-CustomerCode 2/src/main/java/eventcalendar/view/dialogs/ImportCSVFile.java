package eventcalendar.view.dialogs;

import java.io.File;
import java.time.format.DateTimeFormatter;

import javax.swing.JFrame;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileFilter;

import eventcalendar.controller.commands.ImportCSVCommand;
import eventcalendar.model.ICalendar;

/**
 * This concrete class handles the import dialog box of the GUI.
 * It accepts only csv files and sends them to the controller to
 * import the events to the calendar.
 */
public class ImportCSVFile {
  private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("MM/dd/yyyy");
  private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("HH:mm:ss");

  ICalendar calendar;

  public ImportCSVFile(ICalendar calendar) {
    this.calendar = calendar;
  }

  /**
   * Opens a fileChooser dialog to get the CSV file to import the events from.
   */
  public static String showImportCSVDialog(JFrame parentFrame, ICalendar calendar) {
    // Setup JFileChooser object to choose the file.
    JFileChooser fileChooser = new JFileChooser();
    // Set the title of the dialog box.
    fileChooser.setDialogTitle("Select the csv file to import the events to " +
            calendar.getName() + " calendar");

    //Set filter to get just the csv files
    fileChooser.setFileFilter(new FileFilter() {
      /**
       * Only allows directory or a csv file to be shown.
       * @param f the File to test
       * @return boolean value indicating whether to display the file.
       */
      @Override
      public boolean accept(File f) {
        return f.isDirectory() || f.getName().toLowerCase().endsWith(".csv");
      }

      @Override
      public String getDescription() {
        return "CSV Files (*.csv)";
      }
    });

    int result = fileChooser.showOpenDialog(parentFrame);

    // Get the file selected by the user.
    if (result == JFileChooser.APPROVE_OPTION) {
      File selectedFile = fileChooser.getSelectedFile();

      try {
        ImportCSVCommand csvImporter = new ImportCSVCommand();
        String response = csvImporter.execute(calendar, selectedFile);
        JOptionPane.showMessageDialog(parentFrame, "Status: " + response);
      } catch (Exception e) {
        JOptionPane.showMessageDialog(parentFrame, "Error importing events: " +
                e.getMessage(), "Import Error", JOptionPane.ERROR_MESSAGE);
      }
    }

    return "Event not added.";
  }
}
