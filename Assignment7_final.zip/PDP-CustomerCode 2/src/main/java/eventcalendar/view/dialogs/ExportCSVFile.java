package eventcalendar.view.dialogs;

import java.util.HashMap;
import java.util.Map;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import eventcalendar.controller.commands.ExportEventsCommand;
import eventcalendar.model.ICalendar;
import eventcalendar.view.View;

/**
 * A class responsible for handling CSV file export operations for the calendar events.
 */
public class ExportCSVFile {
  ICalendar calendar;

  /**
   * Constructor for ExportCSVFile.
   */
  public ExportCSVFile(ICalendar calendar) {
    this.calendar = calendar;
  }

  /**
   * Opens a fileChooser dialog to get the CSV file to import the events from.
   */
  public static String showExportCSVDialog(JFrame parentFrame, ICalendar calendar) {
    try {
      ExportEventsCommand csvExporter = new ExportEventsCommand(calendar, new View());
      Map<String, String> args = new HashMap<>();
      args.put("fileName", "exportedCSV.csv");

      String response = csvExporter.execute(args);

      // Show result to user
      JOptionPane.showMessageDialog(parentFrame, response);
    } catch (Exception e) {
      JOptionPane.showMessageDialog(parentFrame, "Error exporting events: " +
              e.getMessage(), "Export Error", JOptionPane.ERROR_MESSAGE);
    }

    return "Events not exported.";
  }
}
