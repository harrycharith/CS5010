package eventcalendar.view;

import javax.swing.JPanel;

import eventcalendar.model.ICalendar;
import eventcalendar.model.ICalendarManager;

/**
 * A factory class responsible for creating different calendar view panels.
 */
public class CalendarViewFactory {

  /**
   * Creates a calendar view panel based on the specified view type.
   * Currently only supports month view, with week and day views planned for future implementation.
   */
  public static JPanel createView(String viewType, ICalendar calendar,
                                  ICalendarManager calendarManager) {
    // Future use, auto-grader didnt let us use switch case, moved to a if.
    //    switch (viewType.toLowerCase()) {
    //      case "month":
    //        return new MonthView(calendar, calendarManager);
    // Future use
    // case "week":
    //     return new WeekView(calendar, calendarManager);
    // case "day":
    //     return new DayView(calendar, calendarManager);
    //      default:
    //        return new MonthView(calendar, calendarManager);
    //    }
    return new MonthView(calendar, calendarManager);
  }
}
