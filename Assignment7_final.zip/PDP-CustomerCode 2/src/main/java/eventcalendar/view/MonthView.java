package eventcalendar.view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Font;
import java.awt.Color;
import java.awt.FlowLayout;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.TextStyle;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.swing.JPanel;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JDialog;
import javax.swing.JComboBox;

import eventcalendar.model.Event;
import eventcalendar.model.ICalendar;
import eventcalendar.model.ICalendarManager;
import eventcalendar.view.dialogs.EventDialogManager;

/**
 * Component for displaying a month view of the calendar.
 */
public class MonthView extends AbstractCalendarView {
  private final EventDialogManager eventDialogManager;
  private JPanel daysPanel;
  private YearMonth currentYearMonth;

  /**
   * Constructor for MonthView.
   */
  public MonthView(ICalendar calendarModel, ICalendarManager calendarManager) {
    super(calendarModel, calendarManager);
    this.currentYearMonth = YearMonth.from(currentDate);
    this.eventDialogManager = new EventDialogManager(this, calendarModel);
  }

  /**
   * Initialize the UI components.
   */
  @Override
  protected void initializeUI() {
    setLayout(new BorderLayout());

    // Header panel with day names
    JPanel headerPanel = new JPanel(new GridLayout(1, 7));
    headerPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

    // Add day of week headers
    for (int i = 0; i < 7; i++) {
      DayOfWeek dayOfWeek = DayOfWeek.of(i == 0 ? 7 : i); // Start with Sunday
      JLabel label = new JLabel(dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault()));
      label.setHorizontalAlignment(JLabel.CENTER);
      label.setFont(new Font("Arial", Font.BOLD, 12));

      // Highlight weekend days
      if (dayOfWeek == DayOfWeek.SATURDAY || dayOfWeek == DayOfWeek.SUNDAY) {
        label.setForeground(Color.RED);
      }

      headerPanel.add(label);
    }

    // Days panel
    daysPanel = new JPanel();
    daysPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

    add(headerPanel, BorderLayout.NORTH);
    add(daysPanel, BorderLayout.CENTER);
  }

  /**
   * Set the date to display in the month view.
   *
   * @param date The date within the month to display
   */
  @Override
  public void setDate(LocalDate date) {
    super.setDate(date);
    this.currentYearMonth = YearMonth.from(date);
    updateMonthDisplay();
  }

  @Override
  protected void updateView() {
    updateMonthDisplay();
  }

  /**
   * Update the month display with the current data.
   */
  private void updateMonthDisplay() {
    daysPanel.removeAll();

    // Get first day of month and calculate padding for first week
    LocalDate firstDayOfMonth = currentYearMonth.atDay(1);
    int firstDayOfWeek = firstDayOfMonth.getDayOfWeek().getValue() % 7; // 0 = Sunday, 6 = Saturday

    // Calculate number of rows needed (weeks in month view)
    int daysInMonth = currentYearMonth.lengthOfMonth();
    int rows = (int) Math.ceil((firstDayOfWeek + daysInMonth) / 7.0);

    // Set up the grid
    daysPanel.setLayout(new GridLayout(rows, 7, 5, 5));

    // Add empty cells before the 1st of the month
    for (int i = 0; i < firstDayOfWeek; i++) {
      daysPanel.add(new JLabel(""));
    }

    // Add day cells for each day of the month
    LocalDate today = LocalDate.now(calendarModel.getTimeZone());

    for (int day = 1; day <= daysInMonth; day++) {
      LocalDate date = currentYearMonth.atDay(day);
      JPanel dayPanel = createDayPanel(date, day);

      // Highlight today
      if (date.equals(today)) {
        dayPanel.setBorder(BorderFactory.createLineBorder(Color.RED, 2));
      } else {
        dayPanel.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
      }

      daysPanel.add(dayPanel);
    }

    // Add empty cells after the last day of the month
    int remainingCells = rows * 7 - (firstDayOfWeek + daysInMonth);
    for (int i = 0; i < remainingCells; i++) {
      daysPanel.add(new JLabel(""));
    }

    revalidate();
    repaint();
  }

  /**
   * Create a panel representing a single day in the month view.
   *
   * @param date The date to create the panel for
   * @param day  The day number of the month
   * @return A panel representing the day
   */
  private JPanel createDayPanel(LocalDate date, int day) {
    JPanel dayPanel = new JPanel(new BorderLayout());
    dayPanel.setBackground(new Color(230, 240, 250));

    // Day number label
    JLabel dayLabel = new JLabel(String.valueOf(day));
    dayLabel.setHorizontalAlignment(JLabel.RIGHT);
    dayLabel.setVerticalAlignment(JLabel.TOP);
    dayLabel.setBorder(BorderFactory.createEmptyBorder(2, 5, 2, 5));

    // Weekend days in different color
    if (date.getDayOfWeek() == DayOfWeek.SATURDAY || date.getDayOfWeek() == DayOfWeek.SUNDAY) {
      dayLabel.setForeground(Color.RED);
    }

    dayPanel.add(dayLabel, BorderLayout.NORTH);

    // Make the panel clickable to show events
    dayPanel.addMouseListener(new java.awt.event.MouseAdapter() {
      @Override
      public void mouseClicked(java.awt.event.MouseEvent evt) {
        showDayEvents(date);
      }
    });

    return dayPanel;
  }

  /**
   * Show events for a specific day when clicked.
   *
   * @param date The date to show events for
   */
  private void showDayEvents(LocalDate date) {
    List<Event> eventsForDate = calendarModel.getEventByDate(date);
    // Main panel content
    JPanel panel = new JPanel(new BorderLayout(10, 10));
    // Build event list string
    StringBuilder sb = new StringBuilder("Selected date: " + date + "\n\n");

    if (eventsForDate.isEmpty()) {
      sb.append("No events scheduled.");
    } else {
      for (Event event : eventsForDate) {
        sb.append("- ")
                .append(event.getEventName())
                .append(" (")
                .append(event.getEventStartDateTime().toLocalTime())
                .append(" to ")
                .append(event.getEventEndDateTime().toLocalTime())
                .append(")\n");
      }
    }

    // Create a text area for displaying the text with proper line breaks
    JTextArea textArea = new JTextArea(sb.toString());
    textArea.setEditable(false);
    textArea.setBackground(panel.getBackground());
    textArea.setFont(new JLabel().getFont());
    textArea.setLineWrap(true);
    textArea.setWrapStyleWord(true);

    panel.add(textArea, BorderLayout.CENTER);

    // Button panel
    JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    JButton createBtn = new JButton("Create Event");
    JButton createRecurringBtn = new JButton("Create Recurring Event");
    JButton editBtn = new JButton("Edit Event");

    buttonPanel.add(createBtn);
    buttonPanel.add(createRecurringBtn);
    buttonPanel.add(editBtn);

    panel.add(buttonPanel, BorderLayout.SOUTH);

    // Create a custom dialog
    JOptionPane optionPane = new JOptionPane(panel, JOptionPane.PLAIN_MESSAGE,
            JOptionPane.DEFAULT_OPTION);
    JDialog dialog = optionPane.createDialog(this, "Create Event");
    dialog.setModal(true);

    // Add button actions before showing the dialog
    createBtn.addActionListener(e -> {
      dialog.dispose();
      addEventToDay(date);
    });

    createRecurringBtn.addActionListener(e -> {
      dialog.dispose();
      showRecurringEventDialog(date);
    });

    editBtn.addActionListener(e -> {
      dialog.dispose();
      showEditEventDialog(date);
    });

    dialog.pack();
    dialog.setLocationRelativeTo(this);
    dialog.setVisible(true);
  }

  private void showEditEventDialog(LocalDate date) {
    List<Event> events = calendarModel.getEventByDate(date);

    if (events.isEmpty()) {
      JOptionPane.showMessageDialog(this, "No events to edit " +
              "on this date.");
      return;
    }

    Map<String, Event> labelToEvent = new LinkedHashMap<>();
    for (Event event : events) {
      String label = event.getEventName() + " (" +
              event.getEventStartDateTime() + " to " +
              event.getEventEndDateTime() + ")";
      labelToEvent.put(label, event);
    }

    JComboBox<String> comboBox = new JComboBox<>(labelToEvent.keySet().toArray(new String[0]));

    JPanel panel = new JPanel(new GridLayout(0, 1));
    panel.add(new JLabel("Select an event to edit:"));
    panel.add(comboBox);

    int result = JOptionPane.showConfirmDialog(this, panel, "Edit Event",
            JOptionPane.OK_CANCEL_OPTION);
    if (result == JOptionPane.OK_OPTION) {
      String selectedLabel = (String) comboBox.getSelectedItem();
      if (selectedLabel != null) {
        Event selectedEvent = labelToEvent.get(selectedLabel);
        askEditScope(selectedEvent);
      }
    }
  }

  private void askEditScope(Event event) {
    eventDialogManager.askEditScope(event);
  }

  private void showRecurringEventDialog(LocalDate date) {
    eventDialogManager.showRecurringEventDialog(date);
  }

  private void addEventToDay(LocalDate date) {
    eventDialogManager.showAddEventDialog(date);
  }

  /**
   * Get the current year-month being displayed.
   *
   * @return The current year-month
   */
  public YearMonth getCurrentYearMonth() {
    return currentYearMonth;
  }
}
