package eventcalendar.view;

/**
 * View class for the Calendar.
 * Provides methods for displaying messages and formatting output.
 */
public class View {
  /**
   * This method displays the message to the user.
   *
   * @param message The message to be displayed.
   */
  public void displayMessage(String message) {
    System.out.println(message);
  }
}