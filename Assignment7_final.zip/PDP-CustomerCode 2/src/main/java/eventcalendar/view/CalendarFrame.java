package eventcalendar.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import eventcalendar.model.ICalendar;
import eventcalendar.model.ICalendarManager;
import eventcalendar.view.dialogs.CalendarDialogManager;
import eventcalendar.view.dialogs.ExportCSVFile;
import eventcalendar.view.dialogs.ImportCSVFile;

/**
 * Provides the main window and layout for the calendar GUI application.
 * Displays a calendar view, navigation controls, and calendar management options.
 */
public class CalendarFrame extends JFrame {
  private final ICalendarManager calendarManager;
  private final Map<String, Color> calendarColorMap;
  private final CalendarDialogManager calendarDialogManager;
  private ICalendar calendarModel;
  private JPanel controlPanel;
  private JPanel calendarPanel;
  private JPanel statusPanel;
  private JLabel currentDateLabel;
  private JComboBox<String> calendarSelector;
  private LocalDate currentDate;
  private Color calendarColor;

  /**
   * Constructs a CalendarFrame for the specified calendar and manager.
   *
   * @param calendar the initial calendar to display
   * @param calendarManager manages calendar instances
   */
  public CalendarFrame(ICalendar calendar, ICalendarManager calendarManager) {
    super("Event Calendar - " + calendar.getName());
    this.calendarModel = calendar;
    this.calendarManager = calendarManager;
    this.currentDate = LocalDate.now();
    this.calendarColorMap = new HashMap<>();
    this.calendarDialogManager = new CalendarDialogManager(this, calendarManager);

    this.calendarColor = generateRandomColor();
    this.calendarColorMap.put(calendar.getName(), this.calendarColor);

    initializeUI();
    updateView();

    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setSize(1000, 700);
    setLocationRelativeTo(null);
    setVisible(true);
  }

  /**
   * Initializes the UI components and layout of the frame.
   */
  private void initializeUI() {
    setLayout(new BorderLayout());

    // Control Panel (Top)
    controlPanel = new JPanel(new BorderLayout());
    controlPanel.setBackground(calendarColor);
    controlPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

    JPanel navigationPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    JButton prevButton = new JButton("◀ Previous");
    JButton nextButton = new JButton("Next ▶");
    JButton todayButton = new JButton("Today");
    currentDateLabel = new JLabel("", JLabel.CENTER);
    currentDateLabel.setFont(new Font("Arial", Font.BOLD, 16));

    navigationPanel.add(prevButton);
    navigationPanel.add(todayButton);
    navigationPanel.add(nextButton);

    controlPanel.add(navigationPanel, BorderLayout.WEST);
    controlPanel.add(currentDateLabel, BorderLayout.CENTER);

    // Calendar Selection Panel (Top-Right)
    JPanel calendarControlPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    calendarSelector = new JComboBox<>();
    updateCalendarSelector();

    JButton createCalendarButton = new JButton("New Calendar");
    createCalendarButton.addActionListener(e -> showCreateCalendarDialog());

    JButton importCSVButton = new JButton("Import CSV");
    importCSVButton.addActionListener(e -> showImportCSVDialog());

    JButton exportCSVButton = new JButton("Export CSV");
    exportCSVButton.addActionListener(e -> showExportCSVDialog());

    JButton analyticsButton = new JButton("Analytics Dashboard");
    analyticsButton.addActionListener(e -> showAnalyticsDashboard());

    calendarControlPanel.add(new JLabel("Calendar: "));
    calendarControlPanel.add(calendarSelector);
    calendarControlPanel.add(createCalendarButton);
    calendarControlPanel.add(importCSVButton);
    calendarControlPanel.add(exportCSVButton);
    calendarControlPanel.add(analyticsButton);

    controlPanel.add(calendarControlPanel, BorderLayout.EAST);

    // Calendar Panel (Center)
    calendarPanel = new JPanel(new BorderLayout());
    calendarPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

    // Status Panel (Bottom)
    statusPanel = new JPanel(new BorderLayout());
    statusPanel.setBorder(BorderFactory.createEmptyBorder(3, 5, 3, 5));
    JLabel statusLabel = new JLabel("Calendar: " + calendarModel.getName() + " and Calendar Timezone: "
            + calendarModel.getTimeZone());
    statusPanel.add(statusLabel, BorderLayout.WEST);

    // Add panels to frame
    add(controlPanel, BorderLayout.NORTH);
    add(calendarPanel, BorderLayout.CENTER);
    add(statusPanel, BorderLayout.SOUTH);

    // Add event listeners
    prevButton.addActionListener(e -> navigatePrevious());
    nextButton.addActionListener(e -> navigateNext());
    todayButton.addActionListener(e -> {
      currentDate = LocalDate.now();
      updateView();
    });

    calendarSelector.addActionListener(e -> {
      String selectedCalendarName = (String) calendarSelector.getSelectedItem();
      if (selectedCalendarName != null && !selectedCalendarName.equals(calendarModel.getName())) {
        calendarModel = calendarManager.getCalendar(selectedCalendarName);
        setTitle("Event Calendar - " + calendarModel.getName());
        updateCalendarColour();
        updateCalendarView();
      }
    });
  }

  /**
   * Opens a dialog to import events from a CSV file.
   */
  private void showImportCSVDialog() {
    String importCompleted = ImportCSVFile.showImportCSVDialog(this, calendarModel);
    if (importCompleted.contains("success")) {
      updateCalendarView();
    }
  }

  /**
   * Opens a dialog to export events to a CSV file.
   */
  private void showExportCSVDialog() {
    String exportCompleted = ExportCSVFile.showExportCSVDialog(this, calendarModel);
    if (exportCompleted.contains("success")) {
      updateCalendarView();
    }
  }

  /**
   * Opens the analytics dashboard dialog.
   */
  private void showAnalyticsDashboard() {
    AnalyticsDashboardView dashboardView = new AnalyticsDashboardView(this, calendarModel);
    dashboardView.setVisible(true);
  }

  /**
   * Updates the calendar selector dropdown with all available calendars.
   */
  private void updateCalendarSelector() {
    calendarSelector.removeAllItems();
    List<ICalendar> calendars = calendarManager.getCalendars();
    for (ICalendar calendar : calendars) {
      calendarSelector.addItem(calendar.getName());
      if (!calendarColorMap.containsKey(calendar.getName())) {
        calendarColorMap.put(calendar.getName(), generateRandomColor());
      }
    }
  }

  /**
   * Opens a dialog to create a new calendar.
   */
  private void showCreateCalendarDialog() {
    calendarDialogManager.showCreateCalendarDialog(newCalendarName -> {
      if (!calendarColorMap.containsKey(newCalendarName)) {
        calendarColorMap.put(newCalendarName, generateRandomColor());
      }
      updateCalendarSelector();
      calendarSelector.setSelectedItem(newCalendarName);
    });
  }

  /**
   * Updates the entire calendar view based on current settings.
   */
  private void updateView() {
    calendarPanel.removeAll();
    updateDateLabel();
    updateCalendarView();
    calendarPanel.revalidate();
    calendarPanel.repaint();
  }

  /**
   * Updates the control panel color based on the current calendar.
   */
  private void updateCalendarColour() {
    String calendarName = calendarModel.getName();
    if (calendarColorMap.containsKey(calendarName)) {
      this.calendarColor = calendarColorMap.get(calendarName);
    } else {
      this.calendarColor = generateRandomColor();
      calendarColorMap.put(calendarName, this.calendarColor);
    }
    controlPanel.setBackground(calendarColor);
    controlPanel.revalidate();
    controlPanel.repaint();
  }

  /**
   * Generates a random color for a calendar.
   *
   * @return a randomly generated Color object
   */
  private Color generateRandomColor() {
    int r = (int) (Math.random() * 256);
    int g = (int) (Math.random() * 256);
    int b = (int) (Math.random() * 256);
    return new Color(r, g, b);
  }

  /**
   * Updates the calendar view with the current calendar model.
   */
  private void updateCalendarView() {
    calendarPanel.removeAll();
    String viewType = "month";
    JPanel calendarView = CalendarViewFactory.createView(viewType, calendarModel, calendarManager);
    calendarPanel.add(calendarView, BorderLayout.CENTER);

    if (calendarView instanceof MonthView) {
      ((MonthView) calendarView).setDate(currentDate);
    }

    JLabel statusLabel = new JLabel("Calendar: " + calendarModel.getName() + " and Calendar Timezone: "
            + calendarModel.getTimeZone());
    statusPanel.removeAll();
    statusPanel.add(statusLabel, BorderLayout.WEST);

    controlPanel.setBackground(calendarColor);

    calendarPanel.revalidate();
    calendarPanel.repaint();
    statusPanel.revalidate();
    statusPanel.repaint();
  }

  /**
   * Updates the date label with the current display date.
   */
  private void updateDateLabel() {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM yyyy");
    currentDateLabel.setText(currentDate.format(formatter));
  }

  /**
   * Navigates to the previous month.
   */
  private void navigatePrevious() {
    currentDate = currentDate.minusMonths(1);
    updateView();
  }

  /**
   * Navigates to the next month.
   */
  private void navigateNext() {
    currentDate = currentDate.plusMonths(1);
    updateView();
  }
}