package eventcalendar.controller.commands;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This concrete class parses a given CSV file into a map of keys as
 * headers, rows and columnToIndex mapping, and values as List of String arrays
 * containing the data.
 */
public class CSVParser {
  /**
   * This static method is used to parse a CSV file into a map of keys as
   * headers, rows and columnToIndex mapping, and values as List of String arrays
   * containing the data.
   *
   * @param file The csv file to be parsed.
   * @return a map containing headers, rows and columToIndex mapping.
   * @throws IOException when the input file is invalid or not present.
   */
  public static Map<String, List<String[]>> parseCSV(File file) throws IOException {
    BufferedReader csvReader = new BufferedReader(new FileReader(file));

    // Read header line
    String csvHeaderLine = csvReader.readLine();
    if (csvHeaderLine == null) {
      csvReader.close();
      throw new IOException("CSV file is empty");
    }

    // // debug
    // System.out.println("Reading CSV.\n");

    // Get the csvHeaders and set an index for each header in the map
    String[] csvHeaders = parseLine(csvHeaderLine);
    Map<String, Integer> columnToIndexMap = mapColumns(csvHeaders);

    // Parsing the rows of the file based on the csvHeaders.
    List<String[]> csvRows = new ArrayList<>();
    String csvLine = csvReader.readLine(); // get the first row after the header.

    while (csvLine != null) {
      String[] csvRow = parseLine(csvLine);
      // // debug
      // System.out.println("csvRow: " + Arrays.toString(csvRow));
      csvRows.add(csvRow);

      // get teh next line from the file.
      csvLine = csvReader.readLine();
    }
    // Close the bufferedReader object.
    csvReader.close();

    // Define the map to be returned with keys as
    // header, rows, columnToIndexMap
    Map<String, List<String[]>> csvMap = new HashMap<>();
    List<String[]> headersList = new ArrayList<>();
    headersList.add(csvHeaders);
    csvMap.put("headers", headersList);
    csvMap.put("rows", csvRows);
    csvMap.put("columnIndex", Arrays.asList(new String[][]{{"map", columnToIndexMap.toString()}}));

    //    // debug
    //    for (String[] array : csvMap.get("headers")) {
    //      System.out.println(Arrays.toString(array));
    //    }
    //    for (String[] array : csvMap.get("rows")) {
    //      System.out.println(Arrays.toString(array));
    //    }
    //    for (String[] array : csvMap.get("columIndex")) {
    //      System.out.println(Arrays.toString(array));
    //    }

    return csvMap;
  }

  /**
   * This method parses a line of the csv file.
   */
  public static String[] parseLine(String headerLine) {
    List<String> parsedLine = new ArrayList<>();
    // variable to check if we are inside quotes.
    boolean inQuotes = false;
    // to store each piece of data.
    StringBuilder data = new StringBuilder();

    for (int i = 0; i < headerLine.length(); i++) {
      char c = headerLine.charAt(i);

      // Check for quotes and flip the existing flag inQuotes.
      if (c == '"') {
        inQuotes = !inQuotes;
      }
      // If a ','  is encountered and we not inside quotes then a column's data is complete.
      else if (c == ',' && !inQuotes) {
        parsedLine.add(data.toString());
        data = new StringBuilder();
      }
      // keep appending the characters to the current StringBuilder object.
      else {
        data.append(c);
      }
    }
    // Add the last column's data as well.
    parsedLine.add(data.toString());

    return parsedLine.toArray(new String[0]);
  }


  /**
   * This method maps column names from the header to the indices.
   */
  public static Map<String, Integer> mapColumns(String[] csvHeaders) {
    Map<String, Integer> columnToIndexMap = new HashMap<>();

    // Get the column names from the header and adding indices for them.
    for (int i = 0; i < csvHeaders.length; i++) {
      String columnName = csvHeaders[i].trim().replace("\"", "");
      columnToIndexMap.put(columnName, i);
    }

    return columnToIndexMap;
  }

  /**
   * This method gets teh data for a specified column.
   */
  public static String getData(String[] row,
                               Map<String, Integer> columnToIdxMap,
                               String colName) {
    // Get teh index mapped to the columnName from header.
    Integer idx = columnToIdxMap.get(colName);

    if (idx != null && idx < row.length) {
      return row[idx].trim().replace("\"", "");
    }

    return "";
  }
}
