package eventcalendar.controller.commands;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Map;

import eventcalendar.model.ICalendar;

/**
 * Command to edit events in the calendar.
 * Supports three types of editing:
 * 1. Edit a specific event by name and time range (edit event)
 * 2. Edit events by name and start time (edit events)
 * 3. Edit all events with a specific name (edit events)
 */
public class EditEventCommand implements Command {
  private static final DateTimeFormatter DATE_TIME_FORMATTER =
          DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");
  private final ICalendar calendar;

  /**
   * Constructor for EditEventCommand.
   *
   * @param calendar The calendar containing events to edit
   */
  public EditEventCommand(ICalendar calendar) {
    this.calendar = calendar;
  }

  /**
   * The Command interface represents an executable command in the event calendar system.
   */
  @Override
  public String execute(Map<String, String> args) {
    // Get the object type (event or events)
    String objectType = args.get("object");

    if (!"event".equals(objectType) && !"events".equals(objectType)) {
      return "Invalid command. Use 'edit event' for single event or " +
              "'edit events' for multiple events.";
    }

    String property = args.get("property");

    // Remove quotes if they exist
    if (property != null && property.startsWith("\"") && property.endsWith("\"")) {
      property = property.substring(1, property.length() - 1);
    }
    if (property == null || property.isEmpty()) {
      return "Invalid command, property is empty";
    }

    // add check to have only certain properties to be edited
    if (!isValidProperty(property)) {
      return "Invalid property: " + property + ". Only 'name', 'description', " +
              "'location', and 'isPublic' are editable.";
    }

    String eventName = args.get("eventName");
    String newValue = args.get("newValue");

    // Remove quotes if they exist
    if (eventName != null && eventName.startsWith("\"") && eventName.endsWith("\"")) {
      eventName = eventName.substring(1, eventName.length() - 1);
    }

    // Remove quotes if they exist
    if (newValue != null && newValue.startsWith("\"") && newValue.endsWith("\"")) {
      newValue = newValue.substring(1, newValue.length() - 1);
    }

    // Special handling for isPublic property
    if ("isPublic".equals(property)) {
      if (args.containsKey("isPublic")) {
        newValue = java.util.Objects.equals(args.get("isPublic"), "true") ? "true" : "false";
      }
    }

    if (eventName == null || newValue == null) {
      return "Invalid Command: Missing required name/newValue for editing event(s).";
    }

    try {
      // case 1 ; Single event edit - "edit event" command
      // edit event <property> <eventName> from <dateStringTtimeString>
      // to <dateStringTtimeString> with <NewPropertyValue>
      if ("event".equals(objectType)) {
        String startTime = args.get("startTime");
        String endTime = args.get("endTime");

        if (startTime == null || endTime == null) {
          return "For editing a single event, both start time and end time must be specified.";
        }

        return editSingleEvent(property, eventName, startTime, endTime, newValue);
      }
      // Multiple events edit - "edit events" command
      else {
        String startTime = args.get("startTime");

        if (startTime != null) {
          // Edit events with specific name and start time
          return editMultipleEventsByStartTime(property, eventName, startTime, newValue);
        } else {
          // Edit all events with specific name
          // edit this behaviour
          return editAllEventsByName(property, eventName, newValue);
        }
      }
    } catch (DateTimeParseException e) {
      return "Invalid date/time format: " + e.getMessage();
    } catch (IllegalArgumentException e) {
      return "Invalid argument: " + e.getMessage();
    } catch (Exception e) {
      return "Error while editing event: " + e.getMessage();
    }
  }

  /**
   * Edits a single specific event identified by name, start time, and end time.
   * Used for "edit event" command.
   *
   * @param property     The property to edit (name, description, location, etc.)
   * @param eventName    The name of the event to edit
   * @param startTimeStr The start time of the event (as string)
   * @param endTimeStr   The end time of the event (as string)
   * @param newValue     The new value for the property
   * @return A message indicating the result of the operation
   */
  private String editSingleEvent(String property, String eventName, String startTimeStr,
                                 String endTimeStr, String newValue) {
    LocalDateTime startTime = LocalDateTime.parse(startTimeStr, DATE_TIME_FORMATTER);
    LocalDateTime endTime = LocalDateTime.parse(endTimeStr, DATE_TIME_FORMATTER);

    if (endTime.isBefore(startTime)) {
      throw new IllegalArgumentException("Event end date cannot be before event start date");
    }

    // Delegate to the model to edit the event
    boolean success = calendar.editSingleEvent(eventName, startTime, endTime, property, newValue);

    if (success) {
      return "Successfully updated " + property + " of event '" + eventName + "'.";
    } else {
      return "Failed to update " + property + " of event '" + eventName + "'. " +
              "No matching event found or invalid property/value.";
    }
  }

  /**
   * Edits all events with a specific name that start at a specific time.
   * Used for "edit events" command with start time.
   *
   * @param property     The property to edit
   * @param eventName    The name of the events to edit
   * @param startTimeStr The start time of the events (as string)
   * @param newValue     The new value for the property
   * @return A message indicating the result of the operation
   */
  private String editMultipleEventsByStartTime(String property, String eventName,
                                               String startTimeStr, String newValue) {
    LocalDateTime startTime = LocalDateTime.parse(startTimeStr, DATE_TIME_FORMATTER);

    // Delegate to the model to edit all events with the given name and start time
    int successCount = calendar.editEventsByNameAndStartTime(eventName, startTime, property,
            newValue);

    if (successCount > 0) {
      return "Successfully updated " + property + " of " + successCount + " event(s) with name '" +
              eventName + "' starting at the specified time.";
    } else {
      return "No events found with name '" + eventName + "' starting at the specified time.";
    }
  }

  /**
   * Edits all events with a specific name.
   * Used for "edit events" command without start time.
   *
   * @param property  The property to edit
   * @param eventName The name of the events to edit
   * @param newValue  The new value for the property
   * @return A message indicating the result of the operation
   */
  private String editAllEventsByName(String property, String eventName, String newValue) {
    // Delegate to the model to edit all events with the given name
    int successCount = calendar.editAllEventsByName(eventName, property, newValue);

    if (successCount > 0) {
      return "Successfully updated " + property + " of " + successCount +
              " event(s) with name '" + eventName + "'.";
    } else {
      return "No events found with name '" + eventName + "'.";
    }
  }

  /**
   * Checks if the provided property is valid for editing.
   * Based on the Event class properties that can be modified.
   *
   * @param property The property to validate
   * @return true if the property is valid, false otherwise
   */
  private boolean isValidProperty(String property) {
    return "name".equals(property) || "description".equals(property) ||
            "location".equals(property) || "isPublic".equals(property);
  }
}
