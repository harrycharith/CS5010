package eventcalendar.controller.commands;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import eventcalendar.model.Event;
import eventcalendar.model.ICalendar;
import eventcalendar.model.ICalendarManager;
import eventcalendar.model.ModelUtils;
import eventcalendar.model.SingleEvent;

/**
 * A command class that handles various event copying operations in a calendar system.
 * This class implements the Command interface and provides functionality to copy events
 * in three different ways:
 * 1. Copy a single event from one date/time to another
 * 2. Copy multiple events from one specific date to another
 * 3. Copy multiple events within a date range to a new starting date
 *
 * @see Command
 * @see ICalendarManager
 * @see ICalendar
 */
public class CopyEventCommand implements Command {
  private static final DateTimeFormatter DATE_TIME_FORMATTER =
          DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");
  private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
  private final ICalendarManager calendarManager;
  private final ICalendar calendar;

  public CopyEventCommand(ICalendarManager calendarManager, ICalendar calendar) {
    this.calendarManager = calendarManager;
    this.calendar = calendar;
  }

  @Override
  public String execute(Map<String, String> args) {
    if ("event".equals(args.get("object"))) {

      String eventName = ModelUtils.getValue(args, "eventName");
      if (eventName == null) {
        return "Event name cannot be empty";
      }

      return copySingleEvent(args, eventName);
    } else if ("events".equals(args.get("object"))) {
      if (args.containsKey("sourceDate") && args.containsKey("targetDate")) {
        return copyMultipleEventsOnSpecificDate(args);
      } else if (args.containsKey("sourceDateTo") && args.containsKey("targetStartDate")) {
        return copyMultipleEventsInRange(args);
      }
    }
    return "Invalid copy command";
  }

  private String copyMultipleEventsInRange(Map<String, String> args) {
    LocalDate sourceDateTo = LocalDate.parse(args.get("sourceDateTo"), DATE_FORMATTER);
    LocalDate targetStartDate = LocalDate.parse(args.get("targetStartDate"), DATE_FORMATTER);
    LocalDate sourceDateFrom = LocalDate.parse(args.get("sourceDateFrom"), DATE_FORMATTER);

    List<Event> events = calendar.getEvents();

    // fine all events that occur in the source date range
    List<Event> matchingEvents = events.stream()
            .filter(e -> {
              LocalDateTime eventStart = e.getEventStartDateTime();
              // Compare only the date part (year, month, day), ignoring time
              return (eventStart.toLocalDate().isAfter(sourceDateFrom) ||
                      eventStart.toLocalDate().isEqual(sourceDateFrom)) &&
                      (eventStart.toLocalDate().isBefore(sourceDateTo) ||
                              eventStart.toLocalDate().isEqual(sourceDateTo));
            })
            .collect(Collectors.toList());

    if (matchingEvents.isEmpty()) {
      return "No events found with specified time interval" + sourceDateFrom + "-" + sourceDateTo;
    }

    // Extract timezone id of current calendar
    ZoneId sourceTimeZone = calendar.getTimeZone();

    // For each event we need to account for the time difference in the timezone of the calendars
    String calendarName = ModelUtils.getValue(args, "targetCalendar");
    if (calendarName == null) {
      return "Calendar name cannot be empty";
    }

    if (!calendarManager.hasCalendarName(calendarName)) {
      return "Calendar name '" + calendarName + "' does not exist";
    }

    ICalendar targetCalendar = calendarManager.getCalendar(calendarName);
    ZoneId targetTimeZone = targetCalendar.getTimeZone();

    List<String> results = new ArrayList<>();
    for (Event event : matchingEvents) {
      // Get the date of the current event
      LocalDate eventDate = event.getEventStartDateTime().toLocalDate();

      // Calculate how many days this event is from the start of the source range
      long daysDifference = ChronoUnit.DAYS.between(sourceDateFrom, eventDate);

      // Calculate the target date by adding the same number of days to the target start date
      LocalDate targetDate = targetStartDate.plusDays(daysDifference);

      // Add to target calendar, maintaining the same relative position from the range start
      boolean added = ModelUtils.changeEventTime(event, targetCalendar, sourceTimeZone,
              targetTimeZone, eventDate, targetDate);
      if (added) {
        results.add("Event copied successfully: " + event.getEventName());
      } else {
        results.add("Could not copy event due to conflicts: " + event.getEventName());
      }
    }
    // Summarize all the results at the end
    int successCount = (int) results.stream().filter(s ->
            s.contains("copied successfully")).count();

    return successCount + " Event(s) copied successfully";
  }

  private String copyMultipleEventsOnSpecificDate(Map<String, String> args) {
    LocalDate sourceDate = LocalDate.parse(args.get("sourceDate"), DATE_FORMATTER);
    LocalDate targetDate = LocalDate.parse(args.get("targetDate"), DATE_FORMATTER);

    List<Event> events = calendar.getEvents();

    // Find all events that occur on the source date
    List<Event> matchingEvents = events.stream()
            .filter(e -> {
              LocalDateTime eventStart = e.getEventStartDateTime();
              // Compare only the date part (year, month, day), ignoring time
              return eventStart.toLocalDate().isEqual(sourceDate);
            })
            .collect(Collectors.toList());

    if (matchingEvents.isEmpty()) {
      return "No events found with specified startDate " + sourceDate;
    }

    // Extract timezone id of current calendar
    ZoneId sourceTimeZone = calendar.getTimeZone();

    // For each event we need to account for the time difference in the timezone of the calendars
    String calendarName = ModelUtils.getValue(args, "targetCalendar");
    if (calendarName == null) {
      return "Calendar name cannot be empty";
    }

    if (!calendarManager.hasCalendarName(calendarName)) {
      return "Calendar name '" + calendarName + "' does not exist";
    }

    ICalendar targetCalendar = calendarManager.getCalendar(calendarName);
    ZoneId targetTimeZone = targetCalendar.getTimeZone();

    List<String> results = new ArrayList<>();
    for (Event event : matchingEvents) {
      // Add to target calendar
      boolean added = ModelUtils.changeEventTime(event, targetCalendar, sourceTimeZone,
              targetTimeZone, sourceDate, targetDate);
      if (added) {
        results.add("Event copied successfully: " + event.getEventName());
      } else {
        results.add("Could not copy event due to conflicts: " + event.getEventName());
      }
    }

    // Summarize all the results at the end
    int successCount = (int) results.stream().filter(s ->
            s.contains("copied successfully")).count();

    return successCount + " Event(s) copied successfully";
  }

  private String copySingleEvent(Map<String, String> args, String eventName) {
    LocalDateTime sourceDateTime = LocalDateTime.parse(args.get("sourceDateTime"),
            DATE_TIME_FORMATTER);
    LocalDateTime targetDateTime = LocalDateTime.parse(args.get("targetDateTime"),
            DATE_TIME_FORMATTER);

    List<Event> events = calendar.getEvents();

    // Find the event that matches the name and start time
    Event matchingEvent = events.stream()
            .filter(e -> e.getEventName().equals(eventName) &&
                    e.getEventStartDateTime().equals(sourceDateTime))
            .findFirst()
            .orElse(null);

    if (matchingEvent == null) {
      return "No events found with name '" + eventName + "' starting at the specified time.";
    }

    // Calculate the duration of the original event
    Duration eventDuration = Duration.between(
            matchingEvent.getEventStartDateTime(),
            matchingEvent.getEventEndDateTime());

    // Calculate the new end time by adding the duration to the target start time
    LocalDateTime newEndDateTime = targetDateTime.plus(eventDuration);

    // extract info about matching event
    String matchingEventDescription = matchingEvent.getEventDescription();
    String matchingEventLocation = matchingEvent.getEventLocation();
    boolean matchingEventIsPublic = matchingEvent.isPublic();

    String calendarName = ModelUtils.getValue(args, "targetCalendar");
    if (calendarName == null) {
      return "Calendar name cannot be empty";
    }

    // Check if the Calendar name is already present
    if (calendarManager.hasCalendarName(calendarName)) {
      ICalendar targetCalendar = calendarManager.getCalendar(calendarName);

      // The targetDateTime is already specified in the timezone of the target calendar,
      // and we've calculated the new end time based on the event duration

      // Copy over the event details to the target calendar
      SingleEvent.Builder builder = new SingleEvent.Builder(eventName, targetDateTime)
              .eventEndDateTime(newEndDateTime);
      builder.isPublic(matchingEventIsPublic);

      // optional fields to populate
      if (matchingEventDescription != null && !matchingEventDescription.isEmpty()) {
        builder.eventDescription(matchingEventDescription);
      }
      if (matchingEventLocation != null && !matchingEventLocation.isEmpty()) {
        builder.eventLocation(matchingEventLocation);
      }

      boolean added = targetCalendar.addEvent(builder, true);
      if (added) {
        return "Event copied successfully: " + eventName;
      } else {
        return "Could not copy event due to conflicts.";
      }
    }

    return "Target Calendar does not exist.";
  }
}
