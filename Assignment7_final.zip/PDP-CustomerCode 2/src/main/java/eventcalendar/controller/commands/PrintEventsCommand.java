package eventcalendar.controller.commands;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import eventcalendar.model.Calendar;
import eventcalendar.model.Event;
import eventcalendar.model.ICalendar;
import eventcalendar.view.View;

/**
 * A command implementation that handles the printing of events from a calendar.
 * This class provides functionality to display events either for a specific date
 *
 * @see Command
 * @see Calendar
 * @see View
 */
public class PrintEventsCommand implements Command {

  private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
  private static final DateTimeFormatter DATE_TIME_FORMATTER =
          DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");
  private final ICalendar calendar;

  /**
   * Constructs a new PrintEventsCommand with the specified calendar and view.
   * This command is responsible for displaying events from the calendar through the view.
   *
   * @param calendar The calendar containing events to be printed
   * @param view     The view used to display the calendar events
   */
  public PrintEventsCommand(ICalendar calendar, View view) {
    this.calendar = calendar;
  }

  /**
   * The Command interface represents an executable command in the event calendar system.
   */
  @Override
  public String execute(Map<String, String> args) {
    String printType = args.get("printType");

    try {
      if ("date".equals(printType)) {
        return printEventOnDate(args);
      } else if ("interval".equals(printType)) {
        return printEventInInterval(args);
      } else {
        return "Invalid print type: " + printType;
      }
    } catch (DateTimeParseException e) {
      return "Error Parsing Date: " + e.getMessage();
    } catch (Exception e) {
      return "Error Printing Event: " + e.getMessage();
    }
  }

  /**
   * Retrieves and formats events occurring on a specific date.
   * An event is considered to occur on a date if it:
   * 1. Starts on that date
   * 2. Ends on that date
   * 3. Spans over that date (starts before and ends after)
   *
   * @param args A Map containing command arguments, must include "date" key with
   *             date string in format specified by DATE_FORMATTER
   * @return A formatted string containing all events on the specified date
   * @throws DateTimeParseException if the date string cannot be parsed
   */
  private String printEventOnDate(Map<String, String> args) {
    String dateStr = args.get("date");
    LocalDate date = LocalDate.parse(dateStr, DATE_FORMATTER);

    // find events on this date with stream and filter
    List<Event> eventsOnDate = calendar.getEvents().stream()
            .filter(event -> {
              LocalDate eventStartDate = event.getEventStartDateTime().toLocalDate();
              LocalDate eventEndDate = event.getEventEndDateTime().toLocalDate();

              // Event occurs on this date if:
              // 1. It starts on this date, or
              // 2. It ends on this date, or
              // 3. It spans over this date (starts before and ends after)
              return eventStartDate.equals(date) ||
                      eventEndDate.equals(date) ||
                      (eventStartDate.isBefore(date) && eventEndDate.isAfter(date));
            })
            .collect(Collectors.toList());

    if (eventsOnDate.isEmpty()) {
      return "No events found on " + dateStr;
    }

    StringBuilder result = new StringBuilder();
    result.append("Events on ").append(dateStr).append("\n");

    return returnResult(eventsOnDate, result);
  }

  /**
   * Prints all events that occur within a specified time interval.
   * An event is considered to be within the interval if:
   * 1. It starts within the interval
   * 2. It ends within the interval
   * 3. It spans the entire interval (starts before and ends after)
   *
   * @param args Map containing the following required parameters:
   *             - "startTime": Start time of the interval in datetime format
   *             - "endTime": End time of the interval in datetime format
   * @return A formatted string
   * @throws DateTimeParseException if the datetime strings cannot be parsed
   */
  private String printEventInInterval(Map<String, String> args) {
    String startTimeStr = args.get("startTime");
    String endTimeStr = args.get("endTime");

    LocalDateTime startTime = LocalDateTime.parse(startTimeStr, DATE_TIME_FORMATTER);
    LocalDateTime endTime = LocalDateTime.parse(endTimeStr, DATE_TIME_FORMATTER);

    if (endTime.isBefore(startTime)) {
      return "End time cannot be before start time";
    }

    // find events on this date with stream and filter
    List<Event> eventsInInterval = calendar.getEvents().stream()
            .filter(event -> {
              LocalDateTime eventStart = event.getEventStartDateTime();
              LocalDateTime eventEnd = event.getEventEndDateTime();

              // Event occurs in this interval if:
              // 1. It starts within the interval, or
              // 2. It ends within the interval, or
              // 3. It spans the entire interval (starts before and ends after)
              return (eventStart.isEqual(startTime) || eventStart.isAfter(startTime))
                      && eventStart.isBefore(endTime)
                      || (eventEnd.isAfter(startTime) && (eventEnd.isBefore(endTime)
                      || eventEnd.isEqual(endTime)))
                      || (eventStart.isBefore(startTime) && eventEnd.isAfter(endTime));
            })
            .collect(Collectors.toList());

    if (eventsInInterval.isEmpty()) {
      return "No events found between " + startTimeStr + " and " + endTimeStr;
    }

    StringBuilder result = new StringBuilder();
    result.append("Events between ").append(startTimeStr).append(" and ").
            append(endTimeStr).append(":\n");

    return returnResult(eventsInInterval, result);
  }

  /**
   * Formats a list of events into a human-readable string representation.
   * For each event, includes name, start/end times, location (if specified),
   * and description (if specified).
   *
   * @param eventsInInterval The list of events to format
   * @param result           The StringBuilder to append the formatted events to
   * @return A formatted string containing all event details with each event on new lines
   */
  private String returnResult(List<Event> eventsInInterval, StringBuilder result) {
    for (Event event : eventsInInterval) {
      result.append("• ").append(event.getEventName())
              .append(" (").append(formatDateTime(event.getEventStartDateTime()))
              .append(" to ").append(formatDateTime(event.getEventEndDateTime())).append(")");

      if (event.getEventLocation() != null && !event.getEventLocation().isEmpty()) {
        result.append(" at ").append(event.getEventLocation());
      }

      result.append("\n");

      if (event.getEventDescription() != null && !event.getEventDescription().isEmpty()) {
        result.append("  Description: ").append(event.getEventDescription()).append("\n");
      }
    }

    return result.toString();
  }

  /**
   * Formats a LocalDateTime object to a string using the predefined DATE_TIME_FORMATTER.
   *
   * @param dateTime the LocalDateTime object to be formatted
   * @return a formatted string representation of the datetime
   */
  private String formatDateTime(LocalDateTime dateTime) {
    return dateTime.format(DATE_TIME_FORMATTER);
  }
}
