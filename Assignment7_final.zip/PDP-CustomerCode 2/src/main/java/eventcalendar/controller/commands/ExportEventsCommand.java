package eventcalendar.controller.commands;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

import eventcalendar.model.Event;
import eventcalendar.model.ICalendar;
import eventcalendar.model.ModelUtils;
import eventcalendar.view.View;

/**
 * A command class that exports calendar events to a CSV file.
 * The CSV file format follows a standard calendar import/export,
 * format compatible with most calendar applications.
 */
public class ExportEventsCommand implements Command {
  // Format date as MM/dd/yyyy
  private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("MM/dd/yyyy");
  // Format time as h:mm a (for example, 10:00 AM)
  private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("h:mm a");

  private final ICalendar calendar;

  /**
   * Constructs a new ExportEventsCommand with the specified calendar and view.
   *
   * @param calendar The calendar containing events to be exported
   * @param view     The view interface for displaying information to the user
   */
  public ExportEventsCommand(ICalendar calendar, View view) {
    this.calendar = calendar;
  }

  /**
   * The Command interface represents an executable command in the event calendar system.
   */
  @Override
  public String execute(Map<String, String> args) {
    String filename = ModelUtils.getValue(args, "fileName");
    if (filename == null || filename.isEmpty()) {
      return "Error: filename is null or empty";
    }
    try (PrintWriter writer = new PrintWriter(filename)) {
      // Write CSV header
      writer.println("Subject,Start Date,Start Time,End Date,End Time," +
              "All Day Event,Description,Location,Private");

      for (Event event : calendar.getEvents()) {
        StringBuilder sb = new StringBuilder();

        // Subject (event name)
        sb.append(escapeCSV(event.getEventName())).append(",");

        // Get datetime values
        LocalDateTime start = event.getEventStartDateTime();
        LocalDateTime end = event.getEventEndDateTime();

        // Determine if this is an all-day event
        boolean isAllDay = isAllDayEvent(start, end);

        // Start Date (MM/dd/yyyy)
        sb.append(start.format(DATE_FORMATTER)).append(",");

        // Start Time (h:mm a) - leave empty if all-day event
        if (!isAllDay) {
          sb.append(start.format(TIME_FORMATTER));
        }
        sb.append(",");

        // End Date (MM/dd/yyyy)
        sb.append(end.format(DATE_FORMATTER)).append(",");

        // End Time (h:mm a) - leave empty if all-day event
        if (!isAllDay) {
          sb.append(end.format(TIME_FORMATTER));
        }
        sb.append(",");

        // All Day Event (True/False)
        sb.append(isAllDay ? "True" : "False").append(",");

        // Description
        sb.append(escapeCSV(event.getEventDescription() != null ?
                event.getEventDescription() : "")).append(",");

        // Location
        sb.append(escapeCSV(event.getEventLocation() != null ?
                event.getEventLocation() : "")).append(",");

        // Private (invert isPublic to get private status)
        sb.append(!event.isPublic() ? "True" : "False");

        writer.println(sb);
      }
      return "Calendar exported successfully to " + filename;
    } catch (FileNotFoundException e) {
      return "Error: Could not create file " + filename;
    } catch (Exception e) {
      return "Error exporting calendar: " + e.getMessage();
    }
  }

  /**
   * Determines if an event spans an entire day based on its start and end times.
   * Checks if the event starts at midnight (00:00) and ends at the last minute of the day (23:59).
   *
   * @param start The start date and time of the event
   * @param end   The end date and time of the event
   * @return true if the event spans the entire day, false otherwise
   */
  private boolean isAllDayEvent(LocalDateTime start, LocalDateTime end) {
    // This is a simple implementation - you may need to adjust based on how
    // all-day events are actually represented in your system
    return start.getHour() == 0 && start.getMinute() == 0 &&
            end.getHour() == 23 && end.getMinute() == 59;
  }

  /**
   * Escapes and formats a string value for CSV output.
   *
   * @param value The string value to be escaped for CSV format
   * @return The escaped string
   */
  private String escapeCSV(String value) {
    if (value == null) {
      return "";
    }

    // Escape quotes and wrap in quotes if needed
    if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
      return "\"" + value.replace("\"", "\"\"") + "\"";
    }
    return value;
  }
}