package eventcalendar.controller.commands;

import java.util.Map;

import eventcalendar.model.ICalendar;
import eventcalendar.model.ICalendarManager;


/**
 * This class supports the edit calendar command features.
 *
 * <p>This command class is used to change/modify an existing property ( name or timezone )
 * of the calendar. The command is invalid if the property being changed is absent
 * or the value is invalid in the context of the property.
 */
public class EditCalendarCommand extends AbstractCommand {
  private final ICalendarManager calendarManager;
  private ICalendar calendar;

  /**
   * This constructor initializes the calendarManager object.
   *
   * @param calendarManager CalendarManager object to manage all the calendars.
   */
  public EditCalendarCommand(ICalendarManager calendarManager) {
    this.calendarManager = calendarManager;
  }

  @Override
  public String execute(Map<String, String> args) throws IllegalArgumentException {
    // Get the calendar to edit.
    String calendarName = removeQuotes(args.get("calendarName"));
    if (calendarName == null || calendarName.isEmpty()) {
      return "Calendar name cannot be empty (EditCalendarCommand class)";
    }

    // Check is the Calendar name is present
    if (!calendarManager.hasCalendarName(calendarName)) {
      return calendarName + " is not present in the Calendar Manger, choose another calendar.";
    }
    // Get the calendar and set it as the current calendar
    calendar = calendarManager.getCalendar(calendarName);

    // Get the Property to edit and remove quotes if they exist.
    String calendarProperty = removeQuotes(args.get("property"));
    // Check for null or empty string.
    if (calendarProperty == null || calendarProperty.isEmpty()) {
      return "Property to change cannot be empty";
    }

    // Get the New value to replace the old one and remove quotes if they exist.
    String newValue = removeQuotes(args.get("newValue"));
    // Check for null or empty string.
    if (newValue == null || newValue.isEmpty()) {
      return "newValue cannot be empty";
    }

    // Edit property
    switch (calendarProperty) {
      case "name":
        return changeName(calendarName, newValue);
      case "timezone":
        return changeTimeZone(newValue);
      default:
        return "Invalid property provided: calender cannot be edited.";
    }
  }

  private String changeName(String oldName, String newValue) {
    // Use the new CalendarManager method to update both the calendar object and the HashMap key
    boolean success = calendarManager.updateCalendarName(oldName, newValue);

    if (success) {
      // Update the calendar reference to point to the renamed calendar
      calendar = calendarManager.getCalendar(newValue);
      return "Successfully changed the calendar name to " + newValue;
    } else {
      return "Failed to update calendar name. A calendar with name '" + newValue +
              "' might already exist.";
    }
  }

  private String changeTimeZone(String newValue) throws IllegalArgumentException {
    calendar.setTimeZone(newValue);

    return "Successfully changed the calendar timezone to " + calendar.getTimeZone();
  }
}
