package eventcalendar.controller.parsers;

import java.util.HashMap;
import java.util.Map;

import eventcalendar.controller.CommandParserStrategy;

/**
 * Parser implementation for handling copy commands in the event calendar system.
 */
public class CopyCommandParser implements CommandParserStrategy {

  @Override
  public Map<String, String> parse(String[] commandParts) throws IllegalArgumentException {
    Map<String, String> resultMap = new HashMap<>();
    resultMap.put("command", "copy");

    // Check if there are enough command parts
    if (commandParts.length < 2) {
      throw new IllegalArgumentException("Invalid Copy Command: missing object type after 'copy'");
    }

    int idx = 1;

    if (commandParts[idx].equals("event")) {
      resultMap.put("object", "event");
      idx++;

      // Parse event name and collect string array elements until we reach "on"
      StringBuilder eventName = new StringBuilder();
      int nameStartIndex = idx;
      while (idx < commandParts.length && !commandParts[idx].equals("on")) {
        idx++;
      }
      for (int i = nameStartIndex; i < idx; i++) {
        eventName.append(commandParts[i]).append(" ");
      }
      resultMap.put("eventName", eventName.toString().trim());

      // Parse the common pattern
      // isEvent - true means it is a single event
      idx = ParserUtils.parseOnTargetToPattern(commandParts, idx, resultMap, true);

      return resultMap;
    } else if (commandParts[idx].equals("events")) {
      resultMap.put("object", "events");
      idx++;

      // Parse the common pattern
      // isEvent - false means it is a multiple events command
      if (commandParts[idx].equals("on")) {
        idx = ParserUtils.parseOnTargetToPattern(commandParts, idx, resultMap, false);
      } else if (commandParts[idx].equals("between")) {
        idx++;
        if (idx < commandParts.length) {
          // For single events we expect dateTime, for multiple events just date
          resultMap.put("sourceDateFrom", commandParts[idx]);
          idx++;
        } else {
          throw new IllegalArgumentException("Invalid Command: Missing date after 'between'");
        }

        if (commandParts[idx].equals("and")) {
          idx++;
          if (idx < commandParts.length) {
            resultMap.put("sourceDateTo", commandParts[idx]);
            idx++;
          } else {
            throw new IllegalArgumentException("Invalid Command: Missing date after 'to'");
          }
        }

        if (commandParts[idx].equals("--target")) {
          idx++;
          if (idx >= commandParts.length) {
            throw new IllegalArgumentException("Missing calendar name after --target parameter");
          }

          // Extract the target calendar name (it might contain spaces)
          StringBuilder targetCalendar = new StringBuilder();
          while (idx < commandParts.length && !commandParts[idx].equals("to")) {
            targetCalendar.append(commandParts[idx]).append(" ");
            idx++;
          }
          resultMap.put("targetCalendar", targetCalendar.toString().trim());
        }

        if (commandParts[idx].equals("to")) {
          idx++;
          if (idx < commandParts.length) {
            resultMap.put("targetStartDate", commandParts[idx]);
          } else {
            throw new IllegalArgumentException("Invalid Command: Missing dates after 'to'");
          }
        }
      } else {
        throw new IllegalArgumentException("Invalid copy command format");
      }

      return resultMap;
    }
    throw new IllegalArgumentException("Invalid Copy Command after: " + commandParts[idx - 1]);
  }

  @Override
  public boolean canHandle(String command) {
    return "copy".equals(command);
  }
}
