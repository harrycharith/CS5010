package eventcalendar.controller.parsers;

import java.util.HashMap;
import java.util.Map;

import eventcalendar.controller.CommandParserStrategy;

/**
 * A parser implementation for handling create commands in the event calendar system.
 */
public class CreateCommandParser implements CommandParserStrategy {
  @Override
  public Map<String, String> parse(String[] commandParts) throws IllegalArgumentException {
    Map<String, String> resultMap = new HashMap<>();
    resultMap.put("command", "create");

    // Start after the command word
    if (commandParts.length == 1) {
      throw new IllegalArgumentException("Invalid command: " + commandParts[0]);
    }

    int idx = 1;

    // Check what we're creating
    if (commandParts[idx].equals("event")) {
      return parseCreateEvent(commandParts, idx, resultMap);
    } else if (commandParts[idx].equals("calendar")) {
      return parseCreateCalendar(commandParts, idx, resultMap);
    }

    throw new IllegalArgumentException("Invalid Create Command after: " + commandParts[idx - 1]);
  }

  private Map<String, String> parseCreateCalendar(String[] commandParts,
                                                  int idx, Map<String, String> resultMap) {
    resultMap.put("object", "calendar");
    idx++;

    // process calendar params
    while (idx < commandParts.length) {
      if (commandParts[idx].equals("--name")) {
        idx = ParserUtils.extractCalendarName(commandParts, resultMap, idx);
      } else if (commandParts[idx].equals("--timezone")) {
        idx++;
        if (idx >= commandParts.length) {
          throw new IllegalArgumentException("Missing timezone value after --timezone parameter");
        }
        resultMap.put("calendarTimeZone", commandParts[idx]);
        idx++;
      } else {
        idx++;
      }
    }

    // Check if calendar name was provided
    if (!resultMap.containsKey("calendarName")) {
      throw new IllegalArgumentException("Calendar name must be provided with --name parameter");
    }

    if (!resultMap.containsKey("calendarTimeZone")) {
      throw new IllegalArgumentException("Timezone must be provided with --timezone parameter");
    }

    return resultMap;
  }

  private Map<String, String> parseCreateEvent(String[] commandParts, int idx,
                                               Map<String, String> resultMap) {
    resultMap.put("object", "event");
    idx++;

    // Check if autoDecline is provided in the command, default false - old requirement
    // new requirement makes autoDecline - true by default.
    boolean autoDecline = true;
    if (idx < commandParts.length && "--autoDecline".equals(commandParts[idx])) {
      autoDecline = true;
      idx++;
    }
    // Store the autoDecline boolean value as string value for autoDecline key.
    resultMap.put("autoDecline", autoDecline ? "True" : "False");

    // Parse event name and collect string array elements until we reach
    // a time related token
    StringBuilder eventName = new StringBuilder();
    int nameStartIndex = idx;
    // Traverse the array to find the last idx of eventName which will before
    // just before "from" or "on".
    while (idx < commandParts.length && !commandParts[idx].equals("from")
            && !commandParts[idx].equals("on")) {
      idx++;
    } // now we are at "from" or "on"
    // Get the complete string for eventName
    for (int i = nameStartIndex; i < idx; i++) {
      eventName.append(commandParts[i]).append(" ");
    }
    resultMap.put("eventName", eventName.toString().trim());

    // Parse date and time information.
    if (idx < commandParts.length) {
      if (commandParts[idx].equals("from")) {
        parseFixedTimeEvent(commandParts, idx, resultMap);
      } else if (commandParts[idx].equals("on")) {
        parseAllDayEvent(commandParts, idx, resultMap);
      }
    } else {
      throw new IllegalArgumentException("Date and time information is not provided.");
    }
    return resultMap;
  }

  @Override
  public boolean canHandle(String command) {
    return "create".equals(command);
  }

  /**
   * Get the key value pairs for a fixed time event.
   *
   * @param commandParts A string array containing all the words in the command.
   * @param idx          Index in commandParts to start traversing from.
   * @param resultMap    Map to be populated with the key value pairs found in the command.
   */
  private void parseFixedTimeEvent(String[] commandParts, int idx, Map<String, String> resultMap) {
    // parse "from" time
    if (idx + 1 < commandParts.length) {
      idx++;
      resultMap.put("startTime", commandParts[idx]);
      idx++;
    } else {
      throw new IllegalArgumentException("Invalid Command: Missing startTime after keyword 'from'");
    }

    // parse "on" time
    if (idx + 1 < commandParts.length && commandParts[idx].equals("to")) {
      idx++;
      resultMap.put("endTime", commandParts[idx]);
      idx++;
    } else {
      throw new IllegalArgumentException("Invalid Command: Missing endTime after the keyword 'to'");
    }

    // Parse the optional parameters
    parseOptionalParameters(commandParts, idx, resultMap);
  }

  /**
   * Get the key value pairs for all day event.
   *
   * @param commandParts A string array containing all the words in the command.
   * @param idx          Index in commandParts to start traversing from.
   * @param resultMap    Map to be populated with the key value pairs found in the command.
   */
  private void parseAllDayEvent(String[] commandParts, int idx, Map<String, String> resultMap) {
    // Parse "on" time
    if (idx + 1 < commandParts.length) {
      idx++;
      resultMap.put("date", commandParts[idx]);
      idx++;
    } else {
      throw new IllegalArgumentException("Invalid Command: Missing date after 'on'");
    }

    // For all-day events, "endDate" is not a valid parameter
    // Check if the next parameter is "endDate" and throw an error if it is
    if (idx < commandParts.length && commandParts[idx].equals("endDate")) {
      throw new IllegalArgumentException("Invalid parameter for all-day event: " +
              "'endDate' is not allowed");
    }

    // Parse optional parameters.
    parseOptionalParameters(commandParts, idx, resultMap);
  }

  /**
   * This method parses for the optional parameters in the command provided.
   *
   * @param commandParts A string array containing all the words in the command.
   * @param idx          Index in commandParts to start traversing from.
   * @param resultMap    Map to be populated with the key value pairs found in the command.
   */
  private void parseOptionalParameters(String[] commandParts, int idx,
                                       Map<String, String> resultMap) {
    // Get all the remaining optional parameters.
    while (idx < commandParts.length) {
      switch (commandParts[idx]) {
        case "description":
          idx++;
          StringBuilder description = new StringBuilder();
          // Build the description string till we reach another keyword.
          while (idx < commandParts.length && !isKeyWord(commandParts[idx])) {
            description.append(commandParts[idx]).append(" ");
            idx++;
          }
          resultMap.put("description", description.toString().trim());
          break;
        case "location":
          idx++;
          StringBuilder location = new StringBuilder();
          // Build the location string till we reach another keyword.
          while (idx < commandParts.length && !isKeyWord(commandParts[idx])) {
            location.append(commandParts[idx]).append(" ");
            idx++;
          }
          resultMap.put("location", location.toString().trim());
          break;
        case "end":
          idx++;
          if (idx < commandParts.length) {
            resultMap.put("endDate", commandParts[idx]);
            idx++;
          }
          break;
        case "public":
          resultMap.put("isPublic", "true");
          idx++;
          break;
        case "private":
          resultMap.put("isPublic", "false");
          idx++;
          break;
        case "repeats":
          idx++;
          if (idx < commandParts.length) {
            resultMap.put("repeatDays", commandParts[idx]);
            idx++;

            if (idx + 1 < commandParts.length && commandParts[idx].equals("for")) {
              idx++;
              resultMap.put("repeatTimes", commandParts[idx]);
              idx++;
            } else if (idx + 1 < commandParts.length && commandParts[idx].equals("until")) {
              idx++;
              resultMap.put("repeatUntil", commandParts[idx]);
              idx++;
            }
          }
          break;
        default:
          idx++;
          break;
      }
    }
  }

  /**
   * Method to check if the given string is a key word.
   *
   * @param commandPart String to be checked for being a key word.
   * @return a boolean value as true if the string is a key word, false otherwise.
   */
  private boolean isKeyWord(String commandPart) {
    return commandPart.equals("description") || commandPart.equals("location")
            || commandPart.equals("end") || commandPart.equals("public")
            || commandPart.equals("private") || commandPart.equals("repeats");
  }
}
