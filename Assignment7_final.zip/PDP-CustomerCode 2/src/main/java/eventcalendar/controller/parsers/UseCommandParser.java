package eventcalendar.controller.parsers;

import java.util.HashMap;
import java.util.Map;

import eventcalendar.controller.CommandParserStrategy;

/**
 * A parser implementation for handling use commands in the event calendar system.
 */
public class UseCommandParser implements CommandParserStrategy {
  @Override
  public Map<String, String> parse(String[] commandParts) throws IllegalArgumentException {
    Map<String, String> resultMap = new HashMap<>();
    resultMap.put("command", "use");

    // start the idx after the first word.
    int idx = 1;

    // check the object value from second word.
    // Create event.
    if (commandParts[idx].equals("calendar")) {
      resultMap.put("object", "calendar");
      idx++;

      // process calendar params
      while (idx < commandParts.length) {
        if (commandParts[idx].equals("--name")) {
          idx = ParserUtils.extractCalendarName(commandParts, resultMap, idx);
        } else {
          idx++;
        }
      }
    }

    // Check if calendar name was provided
    if (!resultMap.containsKey("calendarName")) {
      throw new IllegalArgumentException("Calendar name must be provided with --name parameter");
    }

    return resultMap;
  }

  @Override
  public boolean canHandle(String command) {
    return "use".equals(command);
  }
}
