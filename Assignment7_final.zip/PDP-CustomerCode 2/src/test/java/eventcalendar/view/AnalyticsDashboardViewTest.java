package eventcalendar.view;

import org.junit.Before;
import org.junit.Test;

import java.util.Collections;



import eventcalendar.model.CalendarAnalyticsTest;

import static org.junit.Assert.assertTrue;

public class AnalyticsDashboardViewTest {
  private AnalyticsDashboardView dashboardView;
  private CalendarAnalyticsTest.MockCalendar mockCalendar;

  @Before
  public void setUp() {
    mockCalendar = new CalendarAnalyticsTest.MockCalendar("Test Calendar", Collections.emptyList());
    dashboardView = new AnalyticsDashboardView(null, mockCalendar);
  }

  @Test
  public void testGenerateDashboardValidInput() {
    dashboardView.startDateField.setText("2025-04-01");
    dashboardView.endDateField.setText("2025-04-02");
    dashboardView.generateDashboard();
    String dashboardText = dashboardView.dashboardArea.getText();
    assertTrue(dashboardText.contains("Analytics Dashboard for Test Calendar"));
    assertTrue(dashboardText.contains("Total number of events: 0"));
  }

  @Test
  public void testInvalidDateFormat() {
    dashboardView.startDateField.setText("2025-04-01");
    dashboardView.endDateField.setText("invalid-date");
    dashboardView.generateDashboard();
    assertTrue(dashboardView.dashboardArea.getText().contains("Invalid date format"));
  }

  @Test
  public void testEndDateBeforeStartDate() {
    dashboardView.startDateField.setText("2025-04-02");
    dashboardView.endDateField.setText("2025-04-01");
    dashboardView.generateDashboard();
    assertTrue(dashboardView.dashboardArea.getText().contains("End date cannot be before start date"));
  }
}