package eventcalendar.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import eventcalendar.model.Calendar;
import eventcalendar.model.ICalendar;
import eventcalendar.model.ICalendarManager;

/**
 * Mock Class of CalendarManager implementing the CalendarManager interface, used to
 * test the controller in isolation.
 */
public class MockCalendarManager implements ICalendarManager {
  private final StringBuilder log;
  private final Map<String, ICalendar> mockCalendars = new HashMap<>();

  /**
   * Default constructor for the manager.
   */
  public MockCalendarManager(StringBuilder log) {
    this.log = log;
  }

  /**
   * Method to add mock calendar.
   */
  public boolean addMockCalendar(ICalendar calendar) {
    if (mockCalendars.containsKey(calendar.getName())) {
      return false;
    }
    mockCalendars.put(calendar.getName(), calendar);
    return true;
  }

  @Override
  public boolean addCalendar(Calendar.Builder calendarBuilder) {
    log.append("addCalendar:").append(calendarBuilder.toString()).append("\n");
    ICalendar calendar = calendarBuilder.build();
    mockCalendars.put(calendar.getName(), calendar);
    return true;
  }

  @Override
  public boolean hasCalendarName(String name) {
    log.append("hasCalendarName:").append(name).append("\n");
    return mockCalendars.containsKey(name);
  }

  @Override
  public ICalendar getCalendar(String name) {
    log.append("getCalendar:").append(name).append("\n");
    return mockCalendars.get(name);
  }

  @Override
  public boolean updateCalendarName(String oldName, String newName) {
    log.append("updateCalendarName:").append(oldName)
            .append(":").append(newName).append("\n");

    if (mockCalendars.containsKey(newName)) {
      return false;
    }

    ICalendar calendar = mockCalendars.get(oldName);
    if (calendar == null) {
      return false;
    }

    mockCalendars.remove(oldName);
    calendar.setName(newName);
    mockCalendars.put(newName, calendar);

    return true;
  }

  @Override
  public List<ICalendar> getCalendars() {
    return List.of();
  }

  public ICalendar removeCalendar(String name) {
    return mockCalendars.remove(name);
  }
}