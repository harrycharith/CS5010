package eventcalendar.controller.commands;

import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.IOException;

import eventcalendar.controller.Controller;
import eventcalendar.model.Calendar;
import eventcalendar.model.CalendarManager;
import eventcalendar.model.ICalendar;
import eventcalendar.model.ICalendarManager;
import eventcalendar.view.View;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * This class tests the functionality of the ImportCSVCommandTest.
 */
public class ImportCSVCommandTest {
  private ICalendar calendar;
  private File tempFile;
  private File tempFileInvalid;

  @Before
  public void setup() throws IOException {
    // Initialize the model and view objects for the calendar instance.
    ICalendarManager calendarManager = new CalendarManager();
    // Create the Calendar using builder.
    Calendar.Builder calendarBuilder = new Calendar.Builder();
    calendarManager.addCalendar(calendarBuilder);
    calendar = calendarManager.getCalendar("My Calendar");

    Controller controller = new Controller(calendar);
    View view = new View();


    // Create a temporary CSV file
    tempFile = File.createTempFile("testCSVParser", ".csv");
    tempFile.deleteOnExit();

    // Adding data to teh test file
    try (java.io.FileWriter writer = new java.io.FileWriter(tempFile)) {
      writer.write("\"Subject\",\"Start Date\",\"Start Time\",\"End Date\",\"End Time\"," +
              "\"All Day Event\",\"Description\",\"Location\",\"Private\"\n");
      writer.write("\"Team Meeting\",\"03/15/2025\",\"10:00 am\",\"03/15/2025\",\"11:00 am\"," +
              "\"False\",\"Team sync-up\",\"Conference Room\",\"False\"\n");
      writer.write("\"All Day Meeting\",\"03/20/2025\",\"\",\"03/20/2025\",\"\",\"True\"," +
              "\"Company holiday\",\"\",\"False\"\n");
      writer.write("\"Doctor Appointment\",\"03/18/2025\",\"2:00 pm\",\"03/18/2025\"," +
              "\"3:00 pm\",\"False\",\"\",\"\",\"True\"\n");
    } catch (IOException e) {
      throw new RuntimeException(e);
    }

    // Create a temporary CSV file
    tempFileInvalid = File.createTempFile("testInvalidCSVParser", ".csv");
    tempFileInvalid.deleteOnExit();

    // Adding data to teh test file
    try (java.io.FileWriter writer = new java.io.FileWriter(tempFileInvalid)) {
      writer.write("\"Subject\",\"Start Date\",\"Start Time\",\"End Date\"," +
              "\"End Time\",\"All Day Event\",\"Description\",\"Location\",\"Private\"\n");
      writer.write("\"TestValue\",\"TestValue1\",\"TestValue2\"\n");
      writer.write("\"Team Meeting\",\"03/15/2025\",\"10:00 am\",\"03/15/2025\"," +
              "\"11:00 am\",\"False\",\"Team sync-up\",\"Conference Room\",\"False\"\n");
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }


  @Test
  public void testExecuteWithNullCalendar() throws IOException {
    ImportCSVCommand command = new ImportCSVCommand();

    // Using a null calendar for teh execute command
    String result = command.execute(null, new File("test.csv"));

    assertEquals("Error: Please choose a Calendar.", result);
  }

  @Test
  public void testExecuteNoFile() throws IOException {
    ImportCSVCommand command = new ImportCSVCommand();

    // Using an incorrect file name for teh execute command with calendar
    String result = command.execute(calendar, new File("noCSVFile.csv"));

    assertEquals("Error: File not found.", result);
  }

  @Test
  public void testExecuteValid() throws IOException {
    ImportCSVCommand command = new ImportCSVCommand();

    String result = command.execute(calendar, tempFile);

    assertTrue(result.contains("3 events were imported successfully"));
  }

  @Test
  public void testExecuteValidCSV() throws IOException {
    ImportCSVCommand command = new ImportCSVCommand();

    String result = command.execute(calendar, tempFile);

    assertTrue(result.contains("3 events were imported successfully"));
    assertFalse(result.contains("Number of conflicted events: 1"));
  }

  @Test
  public void testExecuteInvalidCSV() throws IOException {
    ImportCSVCommand command = new ImportCSVCommand();

    String result = command.execute(calendar, tempFileInvalid);

    assertTrue(result.contains("Number of conflicted events: 1"));
  }

}