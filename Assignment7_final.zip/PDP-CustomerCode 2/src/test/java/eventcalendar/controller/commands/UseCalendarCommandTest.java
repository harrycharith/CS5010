package eventcalendar.controller.commands;

import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

import eventcalendar.controller.MockCalendar;
import eventcalendar.controller.MockCalendarManager;
import eventcalendar.controller.MockEvent;
import eventcalendar.model.ICalendar;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 * This class tests the UseCalendarCommand class.
 */
public class UseCalendarCommandTest {
  private MockCalendarManager mockCalendarManager;
  private MockCalendar sourceCalendar;
  private MockEvent testEvent;
  private MockCalendar mockCalendar1;
  private MockCalendar mockCalendar2;

  @Before
  public void setup() {
    // Setup test logging
    StringBuilder log = new StringBuilder();

    // Create mock calendar manager
    mockCalendarManager = new MockCalendarManager(log);

    // Create source calendar with test event
    sourceCalendar = new MockCalendar("Source Calendar", log);

    // Create target calendar with different timezone
    MockCalendar targetCalendar = new MockCalendar("Target Calendar", log);
    targetCalendar.setTimeZone("Asia/Kolkata");

    mockCalendar1 = null;
    mockCalendar2 = null;


    // Add both calendars to the manager
    mockCalendarManager.addMockCalendar(sourceCalendar);
    mockCalendarManager.addMockCalendar(targetCalendar);

    // Create the command to test
    CreateCalendarCommand createCalendarCommand = new CreateCalendarCommand(mockCalendarManager);
  }

  @Test
  public void testEmptyCalendarName() {
    Map<String, String> args = new HashMap<>();
    args.put("calendarName", "");

    Consumer<ICalendar> consumer = c -> { /* no-operations for the test */ };
    UseCalendarCommand useCalendarCommand = new UseCalendarCommand(mockCalendarManager, consumer);

    String result = useCalendarCommand.execute(args);

    assertEquals("Calendar name cannot be empty", result);
  }

  @Test
  public void testCalendarNotFound() {
    Map<String, String> args = new HashMap<>();
    args.put("calendarName", "New");
    Consumer<ICalendar> consumer = c -> {
    };

    UseCalendarCommand command = new UseCalendarCommand(mockCalendarManager, consumer);
    String expected = "New is not present in the Calendar Manger, choose another calendar.";

    String result = command.execute(args);
    assertEquals(expected, result);
  }

  @Test
  public void testSuccessfulUseCalendar() {
    Consumer<ICalendar> updateCalendarConsumer = newCalendar -> {
      mockCalendar1 = (MockCalendar) newCalendar;
      System.out.println("Calendar " + newCalendar.getName() + " is being used.");
    };

    Map<String, String> args = new HashMap<>();
    args.put("calendarName", sourceCalendar.getName());

    UseCalendarCommand command = new UseCalendarCommand(mockCalendarManager,
            updateCalendarConsumer);
    String result = command.execute(args);

    // Verify that the consumer was called and the correct calendar was passed
    assertNotNull(mockCalendar1);

    // The expected message includes quotes around the calendar name.
    assertEquals("Now using calendar: \"" + sourceCalendar.getName() + "\"", result);
  }

  @Test
  public void testQuotesRemoved() {
    Consumer<ICalendar> updateCalendarConsumer = newCalendar -> {
      mockCalendar2 = (MockCalendar) newCalendar;
      System.out.println("Calendar " + newCalendar.getName() + " is being used.");
    };

    Map<String, String> args = new HashMap<>();
    args.put("calendarName", "\"" + sourceCalendar.getName() + "\"");

    UseCalendarCommand command = new UseCalendarCommand(mockCalendarManager,
            updateCalendarConsumer);
    String result = command.execute(args);

    assertNotNull(mockCalendar2);
    assertEquals("Now using calendar: \"Source Calendar\"", result);
  }

  @Test
  public void testNullConsumer() {

    Map<String, String> args = new HashMap<>();
    args.put("calendarName", sourceCalendar.getName());

    UseCalendarCommand command = new UseCalendarCommand(mockCalendarManager,
            null);

    String result = command.execute(args);
    assertEquals("Calendar cannot be changed due to null Consumer", result);
  }


}