package eventcalendar.controller.commands;

import org.junit.Before;
import org.junit.Test;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;

import eventcalendar.controller.CommandProcessor;
import eventcalendar.controller.Controller;
import eventcalendar.model.Calendar;
import eventcalendar.model.CalendarManager;
import eventcalendar.model.Event;
import eventcalendar.model.ICalendar;
import eventcalendar.model.ICalendarManager;
import eventcalendar.view.View;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Test class for CreateEventCommand.
 */
public class CreateEventCommandTest {

  // Test data
  private static final String TEST_EVENT_NAME = "Team Meeting";
  // Test objects
  private Controller controller;
  private ICalendar calendar;
  private View view;
  private CommandProcessor commandProcessor;
  private ICalendarManager calendarManger;

  @Before
  public void setup() {
    // Initialize test objects
    calendarManger = new CalendarManager();
    calendar = new Calendar.Builder().build();
    controller = new Controller(calendar);
    view = new View();
    Consumer<ICalendar> updateCalendarConsumer = null;
    commandProcessor = new CommandProcessor(calendarManger,
            updateCalendarConsumer, controller, calendar, view, "");
  }

  @Test
  public void testProcessCommand_NullCommand() {
    // Test with null command
    String result = commandProcessor.processCommand(null);
    assertEquals("Please enter a command", result);
  }

  @Test
  public void testProcessCommand_EmptyCommand() {
    // Test with empty command
    String result = commandProcessor.processCommand("   ");
    assertEquals("Please enter a command", result);
  }

  @Test
  public void testProcessCommand_UnknownCommand() {
    // Test with unknown command
    String result = commandProcessor.processCommand("unknown command");
    assertTrue(result.contains("Error processing command"));
  }

  @Test
  public void testProcessCommand_CreateSingleEvent() {
    // Test creating a single event
    String command = "create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00 description Test Description " +
            "location Conference Room public";

    String result = commandProcessor.processCommand(command);
    assertTrue(result.contains("successfully"));

    // Verify the event was added to the calendar
    List<Event> events = calendar.getEvents();
    assertEquals(1, events.size());

    Event createdEvent = events.get(0);
    assertEquals(TEST_EVENT_NAME, createdEvent.getEventName());
    assertEquals(LocalDateTime.of(2025, 3, 15, 10, 0),
            createdEvent.getEventStartDateTime());
    assertEquals(LocalDateTime.of(2025, 3, 15, 11, 0),
            createdEvent.getEventEndDateTime());
    assertEquals("Test Description", createdEvent.getEventDescription());
    assertEquals("Conference Room", createdEvent.getEventLocation());
  }

  @Test
  public void testProcessCommand_CreateAllDayEvent() {
    // Test creating an all-day event
    String command = "create event All Day Meeting on 2025-03-15 description " +
            "All day planning session location Conference Room";

    String result = commandProcessor.processCommand(command);
    assertTrue(result.contains("successfully"));

    // Verify the event was added to the calendar
    List<Event> events = calendar.getEvents();
    assertEquals(1, events.size());

    Event createdEvent = events.get(0);
    assertEquals("All Day Meeting", createdEvent.getEventName());
    assertEquals(LocalDateTime.of(2025, 3, 15, 0, 0),
            createdEvent.getEventStartDateTime());
    assertEquals(LocalDateTime.of(2025, 3, 15, 23, 59,
            59), createdEvent.getEventEndDateTime());
    assertEquals("All day planning session", createdEvent.getEventDescription());
  }

  @Test
  public void testProcessCommand_CreateAllDayRecurringEvent() {
    // Test creating an all-day event
    String invalidCommand = "create event All Day Meeting Recurring on 2025-03-15 repeats " +
            "MWF for 9 times";
    String invalidResult = commandProcessor.processCommand(invalidCommand);
    assertEquals("Event start day should be part of the recurrence pattern",
            invalidResult);

    String validCommand = "create event All Day Meeting Recurring on 2025-03-19 repeats " +
            "MTWRFSU for 9 times public";
    String result = commandProcessor.processCommand(validCommand);
    assertTrue(result.contains("successfully"));

    // Verify the event was added to the calendar
    List<Event> events = calendar.getEvents();
    assertEquals(9, events.size());
  }

  @Test
  public void testProcessCommand_CreateEventWithAutoDecline() {
    // First create an event
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00");

    // Try to create a conflicting event with auto-decline
    String command = "create event --autoDecline Conflicting Meeting from 2025-03-15T10:30 " +
            "to 2025-03-15T11:30";

    String result = commandProcessor.processCommand(command);
    assertTrue(result.contains("conflicts"));

    // Verify only the first event is in the calendar
    List<Event> events = calendar.getEvents();
    assertEquals(1, events.size());
    assertEquals(TEST_EVENT_NAME, events.get(0).getEventName());
  }

  @Test
  public void testProcessCommand_CreateEventWithoutAutoDecline() {
    // First create an event
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00");

    // Create a conflicting event without auto-decline
    String command = "create event Second Meeting from 2025-03-15T10:30 to 2025-03-15T11:30";

    String result = commandProcessor.processCommand(command);
    // This should conflict now.
    assertTrue(result.contains("conflicts"));

    // Verify both events are in the calendar
    List<Event> events = calendar.getEvents();
    assertEquals(1, events.size());
  }

  @Test
  public void testProcessCommand_InvalidDateFormat() {
    // Test with invalid date format
    String command = "create event Invalid Date Meeting from 2025/03/15T10:00 to " +
            "2025-03-15T11:00";

    String result = commandProcessor.processCommand(command);
    assertTrue(result.contains("Incorrect date format"));
  }

  @Test
  public void testProcessCommand_ExceptionHandling() {
    // Test command processor's exception handling
    // This test simulates an exception in the command execution
    String command = "create event Event with end time before start time from " +
            "2025-03-15T11:00 to 2025-03-15T10:00";

    String result = commandProcessor.processCommand(command);
    assertTrue(result.contains("Error") || result.contains("Invalid"));
  }

  @Test
  public void testCreateEvent_InvalidDateFormat() {
    // Test with invalid date format
    String command = "create event Invalid Date Meeting from 2025/03/15T10:00" +
            " to 2025-03-15T11:00";

    String result = commandProcessor.processCommand(command);
    assertTrue("Should report incorrect date format",
            result.contains("Incorrect date format"));
  }

  @Test
  public void testCreateEvent_EndTimeBeforeStartTime() {
    // Test with end time before start time
    String command = "create event Invalid Time Meeting from 2025-03-15T11:00" +
            " to 2025-03-15T10:00";
    String result = commandProcessor.processCommand(command);
    assertTrue("Should report error for end time before start time",
            result.contains("Error") || result.contains("Invalid"));
  }

  @Test
  public void testCreateEvent_InvalidRepeatDaysPattern() {
    // Test with invalid repeat days pattern
    String command = "create event Invalid Pattern Meeting from 2025-03-17T10:00" +
            " to 2025-03-15T11:00 " +
            "repeats \"\" for 3 times";

    String result = commandProcessor.processCommand(command);
    assertTrue("Should report invalid weekdays pattern",
            result.contains("Recurring event must specify weekdays pattern (e.g., MWF)"));
  }

  @Test
  public void testCreateEvent_NegativeRepeatTimes() {
    // Test with negative repeat times
    String command = "create event Negative Repeat Meeting from 2025-03-17T10:00" +
            " to 2025-03-17T11:00 " +
            "repeats MWF for -3 times";

    String result = commandProcessor.processCommand(command);
    assertTrue("Should report invalid repeat times",
            result.contains("Invalid repeatTimes"));
  }

  @Test
  public void testCreateEvent_ZeroRepeatTimes() {
    // Test with zero repeat times
    String command = "create event Zero Repeat Meeting from 2025-03-17T10:00 " +
            "to 2025-03-17T11:00 " +
            "repeats MWF for 0 times";

    String result = commandProcessor.processCommand(command);
    assertTrue("Should report invalid repeat times",
            result.contains("Invalid repeatTimes"));
  }

  @Test
  public void testCreateEvent_MissingRepeatParams() {
    // Test with missing repeat parameters (no repeatTimes or repeatUntil)
    String command = "create event Missing Params Meeting from 2025-03-17T10:00 " +
            "to 2025-03-17T11:00 " +
            "repeats MWF";

    String result = commandProcessor.processCommand(command);

    assertTrue("Should report missing repeat count or end date",
            result.contains("must specify either repeat count or end date"));
  }

  @Test
  public void testCreateEvent_InvalidRepeatUntilFormat() {
    // Test with invalid repeat until date format
    String command = "create event Invalid Until Meeting from 2025-03-17T10:00 " +
            "to 2025-03-17T11:00 " +
            "repeats MWF until 2025/04/15T11:00";

    String result = commandProcessor.processCommand(command);
    assertTrue("Should report invalid date format",
            result.contains("Invalid date format"));
  }

  @Test
  public void testCreateEvent_RepeatUntilBeforeStartTime() {
    // Test with repeat until before start time
    String command = "create event Invalid Until Meeting from 2025-03-17T10:00 " +
            "to 2025-03-17T11:00 " +
            "repeats MWF until 2025-03-14T11:00";

    String result = commandProcessor.processCommand(command);
    assertTrue("Should report error or create 0 events",
            result.contains("Invalid until date value; it is before event start date"));
  }

  @Test
  public void testCreateAllDayEvent_InvalidDateFormat() {
    // Test all-day event with invalid date format
    String command = "create event Invalid All Day Meeting on 2025/03/15";

    String result = commandProcessor.processCommand(command);
    assertTrue("Should report incorrect date format",
            result.contains("Incorrect date format"));
  }

  @Test
  public void testCreateAllDayEvent_InvalidEndDateInAllDayEvent() {
    // Test all-day event with invalid end date format
    String command = "create event Invalid End Date Meeting on 2025-03-15 endDate 2025/03/16";

    String result = commandProcessor.processCommand(command);

    assertTrue("Should report incorrect date format",
            result.contains("Invalid parameter for all-day event"));
  }

  @Test
  public void testCreateAllDayRecurringEvent_InvalidRepeatParams() {
    // Test all-day recurring event with invalid repeat parameters
    String command = "create event Invalid All Day Recurring on 2025-03-17 " +
            "repeats MWF with 1000";

    String result = commandProcessor.processCommand(command);
    assertTrue("Should report invalid repeat times",
            result.contains("Recurring event must specify either repeat count or end date"));
  }

  @Test
  public void testCreateEvent_ConflictingEvents() {
    // First create an event
    commandProcessor.processCommand("create event --autoDecline First Meeting " +
            "from 2025-03-15T10:00 to 2025-03-15T11:00");

    // Try to create another event at the same time
    String command = "create event --autoDecline Conflicting Meeting from 2025-03-15T10:00 to" +
            " 2025-03-15T11:00";

    String result = commandProcessor.processCommand(command);

    assertTrue("Should report conflict",
            result.contains("Could not create event due to conflicts"));
  }

  @Test
  public void testCreateEvent_EmptyEventName() {
    // Test with empty event name
    String command = "create event \"\" from 2025-03-15T10:00 to 2025-03-15T11:00";

    String result = commandProcessor.processCommand(command);
    assertTrue("Should report error for empty event name",
            result.contains("Event name cannot be empty"));
  }

  @Test
  public void testCreateEvent_MissingStartTime() {
    // Test with missing start time
    String command = "create event Missing Start Time to 2025-03-15T11:00";

    String result = commandProcessor.processCommand(command);
    assertTrue("Should report error for missing start time",
            result.contains("Error processing command"));
  }

  @Test
  public void testCreateEvent_MissingEndTime() {
    // Test with missing end time
    String command = "create event Missing End Time from 2025-03-15T10:00";

    String result = commandProcessor.processCommand(command);
    assertTrue("Should report error for missing end time",
            result.contains("Error processing command"));
  }

  @Test
  public void testCreateAllDayEvent_EndDateBeforeStartDate() {
    // Test all-day event with end date before start date
    String command = "create event Invalid End Date Meeting on 2025-03-15 endDate 2025-03-14";

    String result = commandProcessor.processCommand(command);

    assertTrue("Should report error for end date before start date",
            result.contains("Invalid parameter for all-day event: 'endDate' is not allowed"));
  }

  @Test
  public void testCreateRecurringEvent_StartDayNotInPattern() {
    // Test recurring event where start day is not in the repeat pattern
    // March 17, 2025 is a Monday
    String command = "create event Invalid Pattern Meeting from 2025-03-17T10:00 " +
            "to 2025-03-17T11:00 repeats TRF for 3 times";

    String result = commandProcessor.processCommand(command);
    assertTrue("Should report error that start day is not in pattern",
            result.contains("Event start day should be part of the recurrence pattern"));
  }

  @Test
  public void testCreateEvent_ExtremelyLongEventName() {
    // Test with extremely long event name
    StringBuilder longName = new StringBuilder();
    for (int i = 0; i < 10000; i++) {
      longName.append("a");
    }

    String command = "create event " + longName + " from 2025-03-15T10:00 " +
            "to 2025-03-15T11:00";

    String result = commandProcessor.processCommand(command);
    // The command should either succeed or fail with a specific error message
    assertTrue(result.contains("successfully"));
  }

  @Test
  public void testCreateRecurringEvent_InvalidRepeatParams() {
    String command = "create event TeamMeeting from 2025-03-17T10:00 " +
            "to 2025-03-17T11:00 repeats MTW for -3 times";
    String result = commandProcessor.processCommand(command);

    assertEquals("Invalid repeatTimes value: -3", result);
  }

  @Test
  public void testEventNameWithQuotes() {
    // Test creating an event with quoted name
    String command = "create event \"Quoted Event Name\" from 2025-03-15T10:00 " +
            "to 2025-03-15T11:00";

    String result = commandProcessor.processCommand(command);
    assertTrue("Should successfully create event with quoted name",
            result.contains("successfully"));

    // Verify the event was added with the correct name (quotes removed)
    List<Event> events = calendar.getEvents();
    assertEquals(1, events.size());
    assertEquals("Quoted Event Name", events.get(0).getEventName());
  }

  @Test
  public void testCreateAllDayRecurringEventWithAllWeekdays() {
    // Test creating an all-day recurring event with all weekdays
    String command = "create event All Weekdays Meeting on 2025-03-17 repeats " +
            "MTWRFSU for 7 times";

    String result = commandProcessor.processCommand(command);
    assertTrue("Should successfully create all-day recurring event with all weekdays",
            result.contains("successfully"));

    // Verify the events were added
    List<Event> events = calendar.getEvents();
    assertEquals(7, events.size());
  }

  @Test
  public void testCreateEventWithInvalidDateTimeFormat() {
    // Test creating an event with invalid date/time format
    String command = "create event Invalid Format from 2025/03/15 10:00 to 2025-03-15T11:00";

    String result = commandProcessor.processCommand(command);

    assertEquals(result, ("Error processing command: Invalid Command:" +
            " Missing endTime after the keyword 'to'"));
  }

  @Test
  public void testCreateAllDayEventWithIsPublicTrue() {
    // Test creating an all-day event with isPublic=true
    String command = "create event Public All Day Meeting on 2025-03-15 public";

    String result = commandProcessor.processCommand(command);
    assertTrue("Should successfully create public all-day event",
            result.contains("successfully"));

    // Verify the event was added with correct public setting
    List<Event> events = calendar.getEvents();
    assertEquals(1, events.size());
    assertTrue(events.get(0).isPublic());
  }

  @Test
  public void testCreateAllDayEventWithIsPublicFalse() {
    // Test creating an all-day event with isPublic=false
    String command = "create event Private All Day Meeting on 2025-03-15 private";

    String result = commandProcessor.processCommand(command);
    assertTrue("Should successfully create private all-day event",
            result.contains("successfully"));

    // Verify the event was added with correct public setting
    List<Event> events = calendar.getEvents();
    assertEquals(1, events.size());
    assertFalse(events.get(0).isPublic());
  }

  @Test
  public void testCalculateOccurrences() {
    // Test the calculateOccurrences method indirectly through createRecurringEvent
    String command = "create event Weekend Meeting from 2025-03-15T10:00 to 2025-03-15T11:00 " +
            "repeats SU until 2025-03-30T23:59";

    String result = commandProcessor.processCommand(command);
    assertTrue("Should successfully create recurring events",
            result.contains("successfully"));

    // Verify the correct number of events were created
    List<Event> events = calendar.getEvents();
    assertEquals("Should create 6 occurrences based on calculateOccurrences result",
            6, events.size());
  }

  @Test
  public void testConvertDayOfWeekToWeekDaysSpecificDays() {
    calendar = new Calendar.Builder().build();
    Consumer<ICalendar> updateCalendarConsumer = null;
    commandProcessor = new CommandProcessor(calendarManger, updateCalendarConsumer,
            controller, calendar, view, "");

    // Create a recurring event that spans Thursday, Friday, and Saturday
    // March 13, 2025 is a Thursday
    String command = "create event TFS Meeting from 2025-03-13T10:00 to 2025-03-13T11:00 " +
            "repeats RFS until 2025-03-15T23:59";

    String result = commandProcessor.processCommand(command);
    assertTrue("Should successfully create events for Thursday, Friday, and Saturday",
            result.contains("successfully"));

    // Verify we have exactly 3 events (one for each day)
    List<Event> events = calendar.getEvents();
    assertEquals("Should have exactly 3 events (Thu, Fri, Sat)", 3,
            events.size());

    // Sort events by start date to verify each specific day
    events.sort(Comparator.comparing(Event::getEventStartDateTime));

    // First event should be on Thursday (March 13)
    assertEquals("First event should be on Thursday (March 13)",
            java.time.DayOfWeek.THURSDAY, events.get(0).getEventStartDateTime().getDayOfWeek());
    assertEquals("First event should be on March 13",
            13, events.get(0).getEventStartDateTime().getDayOfMonth());

    // Second event should be on Friday (March 14)
    assertEquals("Second event should be on Friday (March 14)",
            java.time.DayOfWeek.FRIDAY, events.get(1).getEventStartDateTime().getDayOfWeek());
    assertEquals("Second event should be on March 14",
            14, events.get(1).getEventStartDateTime().getDayOfMonth());

    // Third event should be on Saturday (March 15)
    assertEquals("Third event should be on Saturday (March 15)",
            java.time.DayOfWeek.SATURDAY, events.get(2).getEventStartDateTime().getDayOfWeek());
    assertEquals("Third event should be on March 15",
            15, events.get(2).getEventStartDateTime().getDayOfMonth());
  }
}