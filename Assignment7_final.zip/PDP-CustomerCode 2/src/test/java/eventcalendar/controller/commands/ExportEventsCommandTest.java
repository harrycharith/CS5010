package eventcalendar.controller.commands;

import org.junit.Before;
import org.junit.Test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

import eventcalendar.controller.CommandProcessor;
import eventcalendar.controller.Controller;
import eventcalendar.model.Calendar;
import eventcalendar.model.CalendarManager;
import eventcalendar.model.ICalendar;
import eventcalendar.model.ICalendarManager;
import eventcalendar.view.View;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

/**
 * Test class for ExportEventsCommand.
 */
public class ExportEventsCommandTest {

  // Test data
  private static final String TEST_EVENT_NAME = "Team Meeting";
  // Test objects
  private Controller controller;
  private View view;
  private CommandProcessor commandProcessor;
  private ICalendarManager calendarManger;

  @Before
  public void setup() {
    // Initialize test objects
    calendarManger = new CalendarManager();
    ICalendar calendar = new Calendar.Builder().build();
    controller = new Controller(calendar);
    view = new View();
    Consumer<ICalendar> updateCalendarConsumer = null;
    commandProcessor = new CommandProcessor(calendarManger,
            updateCalendarConsumer, controller, calendar, view, "");
  }

  @Test
  public void testProcessCommand_ExportCalendarToCSV() {
    // Create multiple events with different properties
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00 description Team sync-up location" +
            " Conference Room private");
    commandProcessor.processCommand("create event All Day Meeting on " +
            "2025-03-20 description Company holiday private");
    commandProcessor.processCommand("create event Doctor Appointment from " +
            "2025-03-18T14:00 to 2025-03-18T15:00 public");

    // Test file path for export
    String testFilePath = "test_export.csv";
    File testFile = new File(testFilePath);

    try {
      // Export the calendar to CSV
      String command = "export cal " + testFilePath;
      String result = commandProcessor.processCommand(command);
      // Verify export was successful
      assertTrue("Export should succeed", result.contains("successfully"));
      assertTrue("Export file should exist", testFile.exists());

      // Read the CSV file and verify its contents
      List<String> lines = Files.readAllLines(testFile.toPath());

      // Verify header
      String header = lines.get(0);
      assertEquals("CSV header should match expected format",
              "Subject,Start Date,Start Time,End Date,End Time," +
                      "All Day Event,Description,Location,Private", header);

      // Find specific event lines
      String teamMeetingLine = lines.stream()
              .filter(line -> line.contains(TEST_EVENT_NAME))
              .findFirst()
              .orElseThrow(() -> new AssertionError("Team Meeting not found in CSV"));

      String allDayMeetingLine = lines.stream()
              .filter(line -> line.contains("All Day Meeting"))
              .findFirst()
              .orElseThrow(() -> new AssertionError("All Day Meeting not found in CSV"));

      String doctorAppointmentLine = lines.stream()
              .filter(line -> line.contains("Doctor Appointment"))
              .findFirst()
              .orElseThrow(() -> new AssertionError("Doctor Appointment not found in CSV"));

      // Verify Team Meeting properties
      String[] teamFields = teamMeetingLine.split(",");
      System.out.println(Arrays.toString(teamFields));
      assertEquals("Team Meeting subject should match", TEST_EVENT_NAME, teamFields[0]);
      assertEquals("Team Meeting location should be Conference " +
              "Room", "Conference Room", teamFields[7]);
      assertEquals("Team Meeting should be private by default",
              "True", teamFields[8]);

      // Verify All Day Meeting properties
      String[] allDayFields = allDayMeetingLine.split(",");
      assertEquals("All Day Meeting subject should match", "All Day Meeting", allDayFields[0]);
      assertEquals("All Day Meeting should be marked as all-day", "True", allDayFields[5]);
      assertEquals("All Day Meeting should be private by default", "True", allDayFields[8]);

      // Verify Doctor Appointment properties
      String[] doctorFields = doctorAppointmentLine.split(",");
      assertEquals("Doctor Appointment subject should match",
              "Doctor Appointment", doctorFields[0]);
      assertEquals("Doctor Appointment should NOT be marked as private (since it's public)",
              "False", doctorFields[8]);
    } catch (IOException e) {
      fail("Exception should not occur: " + e.getMessage());
    }
  }

  @Test
  public void testProcessCommand_ExportEmptyCalendar() {
    // Create a new command processor with an empty calendar
    Calendar emptyCalendar = new Calendar.Builder().build();
    Consumer<ICalendar> updateCalendarConsumer = null;
    CommandProcessor emptyProcessor = new CommandProcessor(calendarManger,
            updateCalendarConsumer, controller, emptyCalendar,
            view, "");

    // Test file path for export
    String testFilePath = "empty_export.csv";
    File testFile = new File(testFilePath);

    try {
      // Export the empty calendar to CSV
      String command = "export cal " + testFilePath;
      String result = emptyProcessor.processCommand(command);

      // Verify export was successful
      assertTrue("Export should succeed even with empty calendar",
              result.contains("successfully"));
      assertTrue("Export file should exist", testFile.exists());

      // Read the CSV file and verify it only contains the header
      try (BufferedReader reader = new BufferedReader(new FileReader(testFilePath))) {
        // Verify header
        String header = reader.readLine();
        assertEquals("CSV header should match expected format",
                "Subject,Start Date,Start Time,End Date,End Time," +
                        "All Day Event,Description,Location,Private",
                header);

        // Verify no events
        assertNull("There should be no events", reader.readLine());
      }
    } catch (Exception e) {
      fail("Exception should not occur: " + e.getMessage());
    } finally {
      // Clean up by deleting the test file
      if (testFile.exists()) {
        testFile.delete();
      }
    }
  }

  @Test
  public void testProcessCommand_ExportCalendarInvalidPath() {
    // Try to export to an invalid path
    String command = "export cal/invalid/path/test.csv";
    String result = commandProcessor.processCommand(command);

    // Verify export fails with appropriate error message
    assertTrue("Export should fail with invalid path", result.contains("Error"));
  }

  @Test
  public void testProcessCommand_ExportCalendarWithSpecialCharacters() {
    // Create an event with special characters in name and description
    commandProcessor.processCommand("create event \"Meeting, with quotes\" " +
            "from 2025-03-25T10:00 to 2025-03-25T11:00 " +
            "description \"Discussion about project, status\" " +
            "location \"Room, 101\"");

    // Test file path for export
    String testFilePath = "special_chars_export.csv";
    File testFile = new File(testFilePath);

    try {
      // Export the calendar to CSV
      String command = "export cal " + testFilePath;
      String result = commandProcessor.processCommand(command);

      // Verify export was successful
      assertTrue("Export should succeed", result.contains("successfully"));

      // Read the CSV file and verify special characters are properly escaped
      String fileContent = new String(Files.readAllBytes(testFile.toPath()));
      assertTrue("CSV should properly escape commas in event name",
              fileContent.contains("\"Meeting, with quotes\""));
      assertTrue("CSV should properly escape commas in description",
              fileContent.contains("\"Discussion about project, status\""));
      assertTrue("CSV should properly escape commas in location",
              fileContent.contains("\"Room, 101\""));

    } catch (Exception e) {
      fail("Exception should not occur: " + e.getMessage());
    } finally {
      // Clean up by deleting the test file
      if (testFile.exists()) {
        testFile.delete();
      }
    }
  }

  @Test
  public void testProcessCommand_ExportCalendarNullFilename() {
    // Try to export with null filename
    String command = "export cal";
    String result = commandProcessor.processCommand(command);

    // Verify export fails with appropriate error message
    assertTrue("Export should fail with null/missing filename", result.contains("Error"));
  }

  @Test
  public void testProcessCommand_ExportCalendarEmptyFilename() {
    // Try to export with empty filename
    String command = "export cal \"\"";
    String result = commandProcessor.processCommand(command);

    // Verify export fails with appropriate error message
    assertTrue("Export should fail with empty filename",
            result.contains("filename is null or empty"));
  }

  @Test
  public void testProcessCommand_ExportCalendarNonexistentDirectory() {
    // Try to export to a nonexistent directory
    String command = "export cal /nonexistent/directory/file.csv";
    String result = commandProcessor.processCommand(command);

    // Verify export fails with appropriate error message
    assertTrue("Export should fail with nonexistent directory",
            result.contains("Error") && result.contains("Could not create file"));
  }

  @Test
  public void testProcessCommand_ExportCalendarReadOnlyFile() {
    // Create a test file
    String testFilePath = "readonly_test.csv";
    File testFile = new File(testFilePath);

    try {
      // Create the file
      testFile.createNewFile();

      // Make the file read-only
      testFile.setReadOnly();

      // Try to export to the read-only file
      String command = "export cal " + testFilePath;
      String result = commandProcessor.processCommand(command);

      // Verify export fails with appropriate error message
      assertTrue("Export should fail with read-only file",
              result.contains("Error") && result.contains("Could not create file"));
    } catch (Exception e) {
      fail("Exception should not occur during test setup: " + e.getMessage());
    } finally {
      // Make the file writable again so it can be deleted
      if (testFile.exists()) {
        testFile.setWritable(true);
        testFile.delete();
      }
    }
  }

  @Test
  public void testProcessCommand_ExportCalendarInvalidFileExtension() {
    // Try to export to a file with an invalid extension
    String testFilePath = "test_export.invalid";

    // Try to export to the file with invalid extension
    String command = "export cal " + testFilePath;
    String result = commandProcessor.processCommand(command);

    // The command should still execute, but we should verify the file exists
    // and then check if it has the correct CSV format
    assertTrue("Export should succeed even with invalid extension",
            result.contains("successfully"));

    // Clean up the test file
    File testFile = new File(testFilePath);
    if (testFile.exists()) {
      testFile.delete();
    }
  }

  @Test
  public void testProcessCommand_ExportCalendarWithInvalidCommand() {
    // Try to export with an invalid command format
    String command = "export calendar test_export.csv"; // Using "calendar" instead of "cal"
    String result = commandProcessor.processCommand(command);

    // Verify command fails with the exact expected error message
    assertTrue("Export should fail with the specific error message",
            result.contains("Error processing command: Invalid Create Command after: export"));
  }

  @Test
  public void testProcessCommand_ExportCalendarWithQuotedFilename() {
    // Test exporting with a quoted filename
    String testFilePath = "\"quoted_filename.csv\"";
    String command = "export cal " + testFilePath;
    String result = commandProcessor.processCommand(command);

    // Verify export was successful (quotes should be properly handled)
    assertTrue("Export should succeed with quoted filename",
            result.contains("successfully"));

    // Clean up the test file (without quotes)
    File testFile = new File("quoted_filename.csv");
    if (testFile.exists()) {
      testFile.delete();
    }
  }

  @Test
  public void testProcessCommand_ExportCalendarWithAllDayEvent() {
    // Create an all-day event (explicitly set to midnight start and 23:59 end)
    commandProcessor.processCommand("create event \"All Day Test\" on 2025-03-15");

    // Export the calendar
    String testFilePath = "all_day_test.csv";
    String command = "export cal " + testFilePath;
    String result = commandProcessor.processCommand(command);

    try {
      // Verify export was successful
      assertTrue("Export should succeed", result.contains("successfully"));

      // Read the file and verify the all-day event is marked correctly
      String fileContent = new String(Files.readAllBytes(new File(testFilePath).toPath()));
      System.out.println(fileContent);
      assertTrue("All day event should be marked as True",
              fileContent.contains("All Day Test") &&
                      fileContent.contains(",True,"));
    } catch (Exception e) {
      fail("Exception should not occur: " + e.getMessage());
    } finally {
      // Clean up the test file
      File testFile = new File(testFilePath);
      if (testFile.exists()) {
        testFile.delete();
      }
    }
  }

  @Test
  public void testProcessCommand_ExportCalendarWithNonAllDayEvent() {
    // Create a non-all-day event (not starting at midnight and not ending at 23:59)
    commandProcessor.processCommand("create event \"Regular Event\" from " +
            "2025-03-15T10:30 to 2025-03-15T11:45");

    // Export the calendar
    String testFilePath = "regular_event_test.csv";
    String command = "export cal " + testFilePath;
    String result = commandProcessor.processCommand(command);

    try {
      // Verify export was successful
      assertTrue("Export should succeed", result.contains("successfully"));

      // Read the file and verify the event is not marked as all-day
      String fileContent = new String(Files.readAllBytes(new File(testFilePath).toPath()));
      assertTrue("Regular event should not be marked as all-day",
              fileContent.contains("Regular Event") && fileContent.contains(",False,"));

      // Also verify the time is included
      assertTrue("Regular event should include time", fileContent.
              contains("10:30") &&
              fileContent.contains("11:45"));
    } catch (Exception e) {
      fail("Exception should not occur: " + e.getMessage());
    } finally {
      // Clean up the test file
      File testFile = new File(testFilePath);
      if (testFile.exists()) {
        testFile.delete();
      }
    }
  }

  @Test
  public void testProcessCommand_ExportCalendarWithNullDescription() {
    // Create an event with null description (by not specifying it)
    commandProcessor.processCommand("create event \"No Description Event\" " +
            "from 2025-03-15T10:00 to 2025-03-15T11:00");

    // Export the calendar
    String testFilePath = "null_description_test.csv";
    String command = "export cal " + testFilePath;
    String result = commandProcessor.processCommand(command);

    try {
      // Verify export was successful
      assertTrue("Export should succeed", result.contains("successfully"));

      // Read the file and verify the null description is handled correctly
      String fileContent = new String(Files.readAllBytes(new File(testFilePath).toPath()));
      assertTrue("Event with null description should be exported correctly",
              fileContent.contains("No Description Event"));

      // The CSV should have empty fields for description
      assertTrue("CSV should handle null description correctly",
              fileContent.contains(",,"));
    } catch (Exception e) {
      fail("Exception should not occur: " + e.getMessage());
    } finally {
      // Clean up the test file
      File testFile = new File(testFilePath);
      if (testFile.exists()) {
        testFile.delete();
      }
    }
  }

  @Test
  public void testProcessCommand_ExportCalendarWithNewlineInDescription() {
    // Create an event with newlines in the description
    commandProcessor.processCommand("create event \"Newline Event\" from " +
            "2025-03-15T10:00 to 2025-03-15T11:00 " +
            "description \"Line 1\\nLine 2\"");

    // Export the calendar
    String testFilePath = "newline_description_test.csv";
    String command = "export cal " + testFilePath;
    String result = commandProcessor.processCommand(command);

    try {
      // Verify export was successful
      assertTrue("Export should succeed", result.contains("successfully"));

      // Read the file and verify the newline in description is properly escaped
      String fileContent = new String(Files.readAllBytes(new File(testFilePath).toPath()));
      assertTrue("Event with newline in description should be exported correctly",
              fileContent.contains("Newline Event"));

      // The description should be quoted in the CSV
      assertTrue("CSV should properly quote description with newlines",
              fileContent.contains("\"Line 1"));
    } catch (Exception e) {
      fail("Exception should not occur: " + e.getMessage());
    } finally {
      // Clean up the test file
      File testFile = new File(testFilePath);
      if (testFile.exists()) {
        testFile.delete();
      }
    }
  }
}