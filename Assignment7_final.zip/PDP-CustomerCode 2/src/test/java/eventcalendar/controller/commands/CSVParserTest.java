package eventcalendar.controller.commands;

import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

/**
 * This class tests the CSVParser clas used in the controller.
 */
public class CSVParserTest {
  @Test
  public void testParseLine() {
    // Parsing the header line
    String headerLine = "\"Test\",\"Test1\",\"Test2\"";
    String[] expected = {"Test", "Test1", "Test2"};
    assertArrayEquals(expected, CSVParser.parseLine(headerLine));

    // Parsing a header line with commas inside quotes
    headerLine = "\"Test\",\"Test, 1\",\"Test2\"";
    expected = new String[]{"Test", "Test, 1", "Test2"};
    assertArrayEquals(expected, CSVParser.parseLine(headerLine));
  }

  @Test
  public void testMapColumns() {
    String[] headers = {"Test", "Test1", "Test2"};
    Map<String, Integer> columnMap = CSVParser.mapColumns(headers);

    assertEquals(0, (int) columnMap.get("Test"));
    assertEquals(1, (int) columnMap.get("Test1"));
    assertEquals(2, (int) columnMap.get("Test2"));
  }

  @Test
  public void testGetData() {
    String[] row = {"TestValue", "TestValue1", "TestValue2"};
    Map<String, Integer> columnMap = CSVParser.mapColumns(new String[]{"Test", "Test1", "Test2"});

    // Check data retrieval
    assertEquals("TestValue", CSVParser.getData(row, columnMap, "Test"));
    assertEquals("TestValue1", CSVParser.getData(row, columnMap, "Test1"));
    assertEquals("TestValue2", CSVParser.getData(row, columnMap, "Test2"));
  }

  @Test
  public void testParseCSV() throws Exception {
    // Temporary CSV file to test
    File tempFile = File.createTempFile("testCSVParser", ".csv");
    tempFile.deleteOnExit();

    // Adding data to teh test file
    try (java.io.FileWriter writer = new java.io.FileWriter(tempFile)) {
      writer.write("\"Test\",\"Test1\",\"Test2\"\n");
      writer.write("\"TestValue\",\"TestValue1\",\"TestValue2\"\n");
      writer.write("\"TestV\",\"TestV1\",\"TestV2\"\n");
    }

    Map<String, List<String[]>> csvData = CSVParser.parseCSV(tempFile);

    // Check headers
    String[] expectedHeaders = {"Test", "Test1", "Test2"};
    assertArrayEquals(expectedHeaders, csvData.get("headers").get(0));

    // Check rows
    List<String[]> rows = csvData.get("rows");
    assertArrayEquals(new String[]{"TestValue", "TestValue1", "TestValue2"}, rows.get(0));
    assertArrayEquals(new String[]{"TestV", "TestV1", "TestV2"}, rows.get(1));
  }

  @Test(expected = IOException.class)
  public void testParseCSVEmptyFile() throws Exception {
    // Temporary CSV file to test
    File tempFile = File.createTempFile("testCSVParser", ".csv");
    tempFile.deleteOnExit();

    Map<String, List<String[]>> csvData = CSVParser.parseCSV(tempFile);
  }
}