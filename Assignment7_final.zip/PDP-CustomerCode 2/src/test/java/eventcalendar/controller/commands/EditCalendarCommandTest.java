package eventcalendar.controller.commands;

import org.junit.Before;
import org.junit.Test;

import java.time.ZoneId;
import java.util.HashMap;
import java.util.Map;

import eventcalendar.controller.MockCalendar;
import eventcalendar.controller.MockCalendarManager;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * This is a class to test the EditCalendarCommand class.
 */
public class EditCalendarCommandTest {
  private StringBuilder log;
  private MockCalendarManager mockCalendarManager;
  private MockCalendar mockCalendar;
  private EditCalendarCommand editCalendarCommand;

  @Before
  public void setup() {
    log = new StringBuilder();
    mockCalendarManager = new MockCalendarManager(log);

    // Create a mock calendar and add it to the manager
    mockCalendar = new MockCalendar("Mock Calendar", log);
    mockCalendarManager.addMockCalendar(mockCalendar);

    // Create command to test
    editCalendarCommand = new EditCalendarCommand(mockCalendarManager);
  }

  @Test
  public void testEmptyCalendarName() {
    Map<String, String> args = new HashMap<>();
    args.put("calendarName", "");
    args.put("property", "name");
    args.put("newValue", "NewName");

    String result = editCalendarCommand.execute(args);
    assertEquals("Calendar name cannot be empty (EditCalendarCommand class)", result);
  }


  @Test
  public void testCalendarNotFound() {
    Map<String, String> args = new HashMap<>();
    args.put("calendarName", "NoCalendar");
    args.put("property", "name");
    args.put("newValue", "NewName");

    String result = editCalendarCommand.execute(args);
    assertEquals("NoCalendar is not present in the Calendar Manger, " +
            "choose another calendar.", result);
  }

  @Test
  public void testEmptyProperty() {

    Map<String, String> args = new HashMap<>();
    args.put("calendarName", mockCalendar.getName());
    args.put("property", "");
    args.put("newValue", "SomeValue");

    String result = editCalendarCommand.execute(args);
    assertEquals("Property to change cannot be empty", result);
  }

  @Test
  public void testEmptyNewValue() {
    Map<String, String> args = new HashMap<>();
    args.put("calendarName", "Mock Calendar");
    args.put("property", "name");
    args.put("newValue", "");

    String result = editCalendarCommand.execute(args);
    assertEquals("newValue cannot be empty", result);
  }


  @Test
  public void testInvalidProperty() {
    Map<String, String> args = new HashMap<>();
    args.put("calendarName", "Mock Calendar");
    args.put("property", "invalidProperty");
    args.put("newValue", "SomeValue");

    String result = editCalendarCommand.execute(args);
    assertEquals("Invalid property provided: calender cannot be edited.", result);
  }


  @Test
  public void testChangeName() {
    // Prepare command arguments
    Map<String, String> args = new HashMap<>();
    args.put("calendarName", "Mock Calendar");
    args.put("property", "name");
    args.put("newValue", "Updated Calendar");

    // Execute command
    String result = editCalendarCommand.execute(args);

    // Verify results
    assertEquals("Successfully changed the calendar name to Updated Calendar", result);
    assertTrue(log.toString().contains("hasCalendarName:Mock Calendar"));
    assertTrue(log.toString().contains("updateCalendarName:Mock Calendar:Updated Calendar"));
    assertFalse(mockCalendarManager.hasCalendarName("Original Calendar"));
    assertTrue(mockCalendarManager.hasCalendarName("Updated Calendar"));
  }

  @Test
  public void testChangeNameFailure() {
    // Add two calendars so that "NewCalendar" already exists.
    MockCalendar calendar = new MockCalendar("Calendar", new StringBuilder("UTC"));
    mockCalendarManager.addMockCalendar(calendar);

    Map<String, String> args = new HashMap<>();
    args.put("calendarName", "Calendar");
    args.put("property", "name");
    args.put("newValue", "Mock Calendar");

    String result = editCalendarCommand.execute(args);
    assertEquals("Failed to update calendar name. " +
            "A calendar with name 'Mock Calendar' might already exist.", result);
  }


  @Test
  public void testChangeTimezone() {
    // Prepare command arguments
    Map<String, String> args = new HashMap<>();
    args.put("calendarName", "Mock Calendar");
    args.put("property", "timezone");
    args.put("newValue", "Asia/Kolkata");

    // Execute command
    String result = editCalendarCommand.execute(args);

    // Verify results
    assertEquals("Successfully changed the calendar timezone to Asia/Kolkata", result);
    assertEquals(ZoneId.of("Asia/Kolkata"), mockCalendar.getTimeZone());
  }


  @Test
  public void testQuotesRemoval() {
    Map<String, String> args = new HashMap<>();
    args.put("calendarName", "\"Mock Calendar\"");
    args.put("property", "\"timezone\"");
    args.put("newValue", "\"Asia/Kolkata\"");

    String result = editCalendarCommand.execute(args);

    assertEquals("Successfully changed the calendar timezone to Asia/Kolkata",
            result);
    assertEquals(ZoneId.of("Asia/Kolkata"), mockCalendar.getTimeZone());
  }

}