package eventcalendar.model;

import org.junit.Before;
import org.junit.Test;

import java.time.LocalDateTime;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Test class for Calendar.
 */
public class CalendarTest {

  // Test Data
  private static final String TEST_EVENT_NAME = "Test Event";
  private static final LocalDateTime TEST_START_TIME =
          LocalDateTime.of(2025, 03, 15, 10, 0);
  private static final LocalDateTime TEST_END_TIME =
          LocalDateTime.of(2025, 03, 15, 11, 0);

  // Test objects
  private Calendar calendar;
  private SingleEvent.Builder singleEventBuilder;

  @Before
  public void setup() {
    // Create a calendar with default values
    calendar = new Calendar.Builder().build();

    //create event builder
    singleEventBuilder = new SingleEvent.Builder(
            TEST_EVENT_NAME,
            TEST_START_TIME)
            .eventEndDateTime(TEST_END_TIME)
            .isPublic(true);
  }

  @Test
  public void testAddSingleEventWithoutAutoDecline() {
    boolean result = calendar.addEvent(singleEventBuilder, false);

    // Get the event
    Event addedEvent = calendar.getEvents().get(0);
    System.out.println(addedEvent);

    // Should successfully add event without auto-decline
    assertTrue(result);
  }

  @Test
  public void testAddSingleEventWithAutoDecline() {
    // Create a calendar with default values
    calendar = new Calendar.Builder().build();

    boolean result = calendar.addEvent(singleEventBuilder, false);

    // Get the event
    Event addedEvent = calendar.getEvents().get(0);
    System.out.println(addedEvent);

    // Should successfully add event without auto-decline
    assertTrue(result);

    result = calendar.addEvent(singleEventBuilder, true);

    // Get the event
    addedEvent = calendar.getEvents().get(0);
    System.out.println(addedEvent);

    // Should successfully add event without auto-decline
    assertFalse(result);
  }

  @Test
  public void testRemoveEvent() {
    // Add an event to the calendar
    boolean addResult = calendar.addEvent(singleEventBuilder, false);
    assertTrue("Event should be added successfully", addResult);
    assertEquals("Calendar should have 1 event", 1, calendar.getEvents().size());

    // Get the event
    Event addedEvent = calendar.getEvents().get(0);

    // Remove the event
    boolean removeResult = calendar.removeEvent(addedEvent);
    assertTrue("Event should be removed successfully", removeResult);
    assertEquals("Calendar should have 0 events after removal", 0,
            calendar.getEvents().size());
  }

  @Test
  public void testRemoveNonExistentEvent() {
    // Create an event but don't add it to the calendar
    Event event = singleEventBuilder.build();

    // Try to remove the non-existent event
    boolean removeResult = calendar.removeEvent(event);
    assertFalse("Removing non-existent event should return false", removeResult);
    assertEquals("Calendar should still have 0 events", 0,
            calendar.getEvents().size());
  }

  @Test
  public void testCheckConflictWithOverlappingEvents() {
    // Add first event
    boolean addResult = calendar.addEvent(singleEventBuilder, false);
    assertTrue("First event should be added successfully", addResult);

    // Create a second event that overlaps with the first
    LocalDateTime conflictingStartTime = TEST_START_TIME.plusMinutes(30);
    LocalDateTime conflictingEndTime = TEST_END_TIME.plusMinutes(30);

    SingleEvent.Builder conflictingEventBuilder = new SingleEvent.Builder(
            "Conflicting Event",
            conflictingStartTime)
            .eventEndDateTime(conflictingEndTime)
            .isPublic(true);

    // Try to add with auto-decline enabled
    boolean addConflictResult = calendar.addEvent(conflictingEventBuilder, true);
    assertFalse("Conflicting event should be declined", addConflictResult);
    assertEquals("Calendar should still have only 1 event", 1,
            calendar.getEvents().size());

    // Try to add with auto-decline disabled
    addConflictResult = calendar.addEvent(conflictingEventBuilder, false);
    assertTrue("Conflicting event should be added when auto-decline is false",
            addConflictResult);
    assertEquals("Calendar should now have 2 events", 2,
            calendar.getEvents().size());
  }

  @Test
  public void testCheckConflictWithAdjacentEvents() {
    // Add first event
    boolean addResult = calendar.addEvent(singleEventBuilder, false);
    assertTrue("First event should be added successfully", addResult);

    // Create a second event that ends exactly when the first starts
    LocalDateTime adjacentStartTime = TEST_START_TIME.minusHours(1);
    LocalDateTime adjacentEndTime = TEST_START_TIME;

    SingleEvent.Builder adjacentEventBuilder = new SingleEvent.Builder(
            "Adjacent Event",
            adjacentStartTime)
            .eventEndDateTime(adjacentEndTime)
            .isPublic(true);

    // Try to add with auto-decline enabled
    boolean addAdjacentResult = calendar.addEvent(adjacentEventBuilder, true);
    assertTrue("Adjacent event should not be declined", addAdjacentResult);
    assertEquals("Calendar should now have 2 events", 2,
            calendar.getEvents().size());

    // Create a third event that starts exactly when the first ends
    LocalDateTime adjacentStartTime2 = TEST_END_TIME;
    LocalDateTime adjacentEndTime2 = TEST_END_TIME.plusHours(1);

    SingleEvent.Builder adjacentEventBuilder2 = new SingleEvent.Builder(
            "Adjacent Event 2",
            adjacentStartTime2)
            .eventEndDateTime(adjacentEndTime2)
            .isPublic(true);

    // Try to add with auto-decline enabled
    boolean addAdjacentResult2 = calendar.addEvent(adjacentEventBuilder2, true);
    assertTrue("Adjacent event 2 should not be declined", addAdjacentResult2);
    assertEquals("Calendar should now have 3 events", 3,
            calendar.getEvents().size());
  }

  @Test
  public void testCalendarBuilderWithCustomName() {
    // Create a calendar with a custom name
    Calendar customCalendar = new Calendar.Builder()
            .name("Custom Calendar")
            .build();

    // Add an event to verify the calendar works
    SingleEvent.Builder eventBuilder = new SingleEvent.Builder(
            TEST_EVENT_NAME,
            TEST_START_TIME)
            .eventEndDateTime(TEST_END_TIME)
            .isPublic(true);

    boolean addResult = customCalendar.addEvent(eventBuilder, false);
    assertTrue("Event should be added successfully to custom calendar", addResult);
    assertEquals("Custom calendar should have 1 event", 1,
            customCalendar.getEvents().size());
  }

  @Test
  public void testIsValidProperty() {
    // Add an event first
    boolean addResult = calendar.addEvent(singleEventBuilder, false);
    assertTrue("Event should be added successfully", addResult);

    // Test valid properties
    assertTrue(calendar.editSingleEvent(TEST_EVENT_NAME, TEST_START_TIME, TEST_END_TIME,
            "name", "New Name"));
    assertTrue(calendar.editSingleEvent("New Name", TEST_START_TIME, TEST_END_TIME,
            "description", "New Description"));
    assertTrue(calendar.editSingleEvent("New Name", TEST_START_TIME, TEST_END_TIME,
            "location", "New Location"));
    assertTrue(calendar.editSingleEvent("New Name", TEST_START_TIME, TEST_END_TIME,
            "isPublic", "false"));

    // Test invalid property
    assertFalse(calendar.editSingleEvent("New Name", TEST_START_TIME, TEST_END_TIME,
            "startDateTime", "2025-04-01T10:00"));
  }

  @Test
  public void testGetAndSetName() {
    assertEquals("Default name should be 'My Calendar'", "My Calendar", calendar.getName());

    calendar.setName("New Calendar Name");
    assertEquals("Name should be updated", "New Calendar Name", calendar.getName());
  }

  @Test
  public void testGetAndSetTimeZone() {
    assertEquals("Default timezone should be EST",
            java.time.ZoneId.of(java.time.ZoneId.SHORT_IDS.get("EST")), calendar.getTimeZone());

    calendar.setTimeZone("Europe/Paris");
    assertEquals("Timezone should be updated",
            java.time.ZoneId.of("Europe/Paris"), calendar.getTimeZone());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSetInvalidTimeZone() {
    calendar.setTimeZone("Invalid/Timezone");
  }

  @Test
  public void testEditEventsByNameAndStartTime() {
    calendar.createEvent(TEST_EVENT_NAME, TEST_START_TIME, TEST_END_TIME,
            "Description 1", "Location 1", true, false);

    calendar.createEvent(
            TEST_EVENT_NAME, TEST_START_TIME.plusDays(1), TEST_END_TIME.plusDays(1),
            "Description 2", "Location 2", true, false);

    calendar.createEvent(TEST_EVENT_NAME, TEST_START_TIME.plusDays(2), TEST_END_TIME.plusDays(2),
            "Description 3", "Location 3", true, false);

    assertEquals("Calendar should have 3 events", 3, calendar.getEvents().size());

    int editCount = calendar.editEventsByNameAndStartTime(
            TEST_EVENT_NAME, TEST_START_TIME.plusDays(1), "description",
            "Updated Description");

    assertEquals("Should update 2 events", 2, editCount);
    for (Event event : calendar.getEvents()) {
      if (event.getEventStartDateTime().isEqual(TEST_START_TIME)) {
        assertEquals("First event description should not be updated",
                "Description 1", event.getEventDescription());
      } else {
        assertEquals("Later events description should be updated",
                "Updated Description", event.getEventDescription());
      }
    }
  }
}