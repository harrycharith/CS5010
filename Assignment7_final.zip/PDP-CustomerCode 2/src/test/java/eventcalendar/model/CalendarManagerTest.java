package eventcalendar.model;


import org.junit.Before;
import org.junit.Test;

import eventcalendar.controller.MockCalendar;
import eventcalendar.controller.MockEvent;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * This is a class to test calendarManager model class.
 */
public class CalendarManagerTest {
  private CalendarManager calendarManager;
  private MockEvent mockEvent;
  private Calendar.Builder calendar1;
  private Calendar.Builder calendar2;

  @Before
  public void setup() {
    // Setup test logging
    StringBuilder log = new StringBuilder();

    // Create mock calendar1 manager
    calendarManager = new CalendarManager();

    // Create mock calendar1 with test event
    MockCalendar mockCalendar1 = new MockCalendar("Mock Calendar 1", log);
    MockCalendar mockCalendar2 = new MockCalendar("Mock Calendar 2", log);

    calendar1 = new Calendar.Builder().name("Calendar1");
    calendar2 = new Calendar.Builder().name("Calendar2");

    // Add both calendars to the manager
    calendarManager.addCalendar(calendar1);
  }

  @Test
  public void testAddCalendar() {
    assertFalse(calendarManager.addCalendar(calendar1));
    assertTrue(calendarManager.addCalendar(calendar2));
  }

  @Test
  public void testHasCalendar() {
    assertTrue(calendarManager.hasCalendarName("Calendar1"));
    assertFalse(calendarManager.hasCalendarName("Not Present"));
  }

  @Test
  public void testUpdateCalendarName() {
    calendarManager.addCalendar(calendar2);

    assertFalse(calendarManager.updateCalendarName("Calendar2", "Calendar1"));
    assertTrue(calendarManager.updateCalendarName("Calendar2", "NewCalendar2"));
    assertFalse(calendarManager.updateCalendarName("Not Present", "Present"));
    assertEquals("NewCalendar2",
            calendarManager.getCalendar("NewCalendar2").getName());
    assertFalse(calendarManager.hasCalendarName("Calendar2"));
  }
}