package eventcalendar.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

import eventcalendar.controller.commands.Command;
import eventcalendar.controller.commands.CopyEventCommand;
import eventcalendar.controller.commands.CreateCalendarCommand;
import eventcalendar.controller.commands.CreateEventCommand;
import eventcalendar.controller.commands.EditCalendarCommand;
import eventcalendar.controller.commands.EditEventCommand;
import eventcalendar.controller.commands.ExportEventsCommand;
import eventcalendar.controller.commands.PrintEventsCommand;
import eventcalendar.controller.commands.ShowDashboardCommand;
import eventcalendar.controller.commands.ShowStatusCommand;
import eventcalendar.controller.commands.UseCalendarCommand;
import eventcalendar.model.ICalendar;
import eventcalendar.model.ICalendarManager;
import eventcalendar.view.View;

/**
 * Processes and executes user commands for the calendar application.
 * Parses command strings and delegates execution to the appropriate command objects.
 */
public class CommandProcessor {
  private final ICalendarManager calendarManager;
  private final CommandParser parser;
  private final Consumer<ICalendar> updateCalendarConsumer;
  private final ICalendar calendar;
  private final View view;
  private final Map<String, Command> commands;

  /**
   * Constructs a CommandProcessor with the specified dependencies.
   *
   * @param calendarManager manages calendar instances
   * @param updateCalendarConsumer updates the active calendar
   * @param controller the main application controller
   * @param calendar the current calendar instance
   * @param view displays command results
   * @param command the command string to process
   */
  public CommandProcessor(ICalendarManager calendarManager,
                          Consumer<ICalendar> updateCalendarConsumer, Controller controller,
                          ICalendar calendar, View view, String command) {
    this.updateCalendarConsumer = updateCalendarConsumer;
    this.calendar = calendar;
    this.view = view;
    this.calendarManager = calendarManager;
    this.commands = initializeCommands();
    this.parser = new CommandParser();
  }

  /**
   * Initializes the command mapping for the application.
   *
   * @return a map of command keys to their corresponding Command implementations
   */
  private Map<String, Command> initializeCommands() {
    Map<String, Command> cmds = new HashMap<>();
    cmds.put("create event", new CreateEventCommand(calendar));
    cmds.put("edit event", new EditEventCommand(calendar));
    cmds.put("print event", new PrintEventsCommand(calendar, view));
    cmds.put("copy event", new CopyEventCommand(calendarManager, calendar));
    cmds.put("show", new ShowStatusCommand(calendar, view));
    cmds.put("show dashboard", new ShowDashboardCommand(calendar, view));
    cmds.put("create calendar", new CreateCalendarCommand(calendarManager));
    cmds.put("edit calendar", new EditCalendarCommand(calendarManager));
    cmds.put("use calendar", new UseCalendarCommand(calendarManager, updateCalendarConsumer));
    cmds.put("export", new ExportEventsCommand(calendar, view));
    return cmds;
  }

  /**
   * Retrieves the command handler for the given command and object.
   *
   * @param commandName the name of the command
   * @param objectName the object of the command (e.g., event, calendar)
   * @return the corresponding Command instance
   */
  private Command getCommand(String commandName, String objectName) {
    String key = (objectName != null) ? commandName + " " + objectName : commandName;
    Command command = commands.get(key);

    if (command == null && objectName != null && objectName.endsWith("s")) {
      String singularObject = objectName.substring(0, objectName.length() - 1);
      command = commands.get(commandName + " " + singularObject);
    }

    return command;
  }

  /**
   * Processes a command string and executes the corresponding command.
   *
   * @param commandString the input command string
   * @return the result of the command execution or an error message
   */
  public String processCommand(String commandString) {
    try {
      if (commandString == null || commandString.trim().isEmpty()) {
        return "Please enter a command";
      }

      Map<String, String> commandMap = parser.parseCommand(commandString);
      String commandName = commandMap.get("command");
      String objectName = commandMap.get("object");
      Command command = getCommand(commandName, objectName);
      return command.execute(commandMap);
    } catch (Exception e) {
      return "Error processing command: " + e.getMessage();
    }
  }
}