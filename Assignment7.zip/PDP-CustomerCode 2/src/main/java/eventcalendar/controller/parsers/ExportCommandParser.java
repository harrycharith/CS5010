package eventcalendar.controller.parsers;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import eventcalendar.controller.CommandParserStrategy;

/**
 * A parser implementation for handling export commands in the event calendar system.
 */
public class ExportCommandParser implements CommandParserStrategy {
  @Override
  public Map<String, String> parse(String[] commandParts) throws IllegalArgumentException {
    Map<String, String> resultMap = new HashMap<>();
    resultMap.put("command", "export");

    // make sure the command is correct

    if (!Objects.equals(commandParts[1], "cal")) {
      throw new IllegalArgumentException("Invalid Create Command after: " + commandParts[0]);
    }

    resultMap.put("action", "cal");

    // start the idx after the second word.
    int idx = 2;

    if (commandParts.length > idx) {
      resultMap.put("fileName", commandParts[idx]);
    } else {
      throw new IllegalArgumentException("Invalid Create Command after: " + commandParts[idx - 1]);
    }

    return resultMap;
  }

  @Override
  public boolean canHandle(String command) {
    return "export".equals(command);
  }
}
