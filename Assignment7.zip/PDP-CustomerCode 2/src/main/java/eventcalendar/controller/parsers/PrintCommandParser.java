package eventcalendar.controller.parsers;

import java.util.HashMap;
import java.util.Map;

import eventcalendar.controller.CommandParserStrategy;

/**
 * A parser implementation for handling print commands in the event calendar system.
 */
public class PrintCommandParser implements CommandParserStrategy {

  @Override
  public Map<String, String> parse(String[] commandParts) throws IllegalArgumentException {
    Map<String, String> resultMap = new HashMap<>();
    resultMap.put("command", "print");

    // start the idx after the first word.
    int idx = 1;

    if (commandParts.length > idx && commandParts[idx].equals("events")) {
      resultMap.put("object", "events");
      idx++;

      if (idx < commandParts.length) {
        // Print 'on' date.
        if (commandParts[idx].equals("on")) {
          resultMap.put("printType", "date");
          idx++;

          if (idx < commandParts.length) {
            resultMap.put("date", commandParts[idx]);
          }
        } else if (commandParts[idx].equals("from")) {
          resultMap.put("printType", "interval");
          idx++;

          if (idx < commandParts.length) {
            resultMap.put("startTime", commandParts[idx]);
            idx++;

            if (idx + 1 < commandParts.length && commandParts[idx].equals("to")) {
              idx++;
              resultMap.put("endTime", commandParts[idx]);
            }
          }
        }
      }
    }
    return resultMap;
  }

  @Override
  public boolean canHandle(String command) {
    return "print".equals(command);
  }
}
