package eventcalendar.controller.parsers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import eventcalendar.controller.CommandParserStrategy;

/**
 * A parser implementation for handling edit commands in the event calendar system.
 */
public class EditCommandParser implements CommandParserStrategy {
  @Override
  public Map<String, String> parse(String[] commandParts) throws IllegalArgumentException {
    Map<String, String> resultMap = new HashMap<>();
    resultMap.put("command", "edit");

    // start the idx after the first word.
    int idx = 1;

    // check the object value from second word.
    if (idx < commandParts.length) {
      // check if we need to edit a single event
      if (commandParts[idx].equals("event")) {
        return parseEditEvent(commandParts, idx, resultMap);
      } else if (commandParts[idx].equals("events")) {
        return parseEditEvents(commandParts, idx, resultMap);
      } else if (commandParts[idx].equals("calendar")) {
        return parseEditCalendar(commandParts, idx, resultMap);
      }
    }

    throw new IllegalArgumentException("Invalid command");
  }

  private Map<String, String> parseEditCalendar(String[] commandParts, int idx,
                                                Map<String, String> resultMap) {
    resultMap.put("object", "calendar");
    idx++;

    // process calendar params
    while (idx < commandParts.length) {
      if (commandParts[idx].equals("--name")) {
        idx = ParserUtils.extractCalendarName(commandParts, resultMap, idx);
      } else if (commandParts[idx].equals("--property")) {
        idx++;
        if (idx >= commandParts.length) {
          throw new IllegalArgumentException("Missing property name after --property parameter");
        }
        resultMap.put("property", commandParts[idx]);
        idx++;

        // collect the remaining as newValue
        if (idx < commandParts.length) {
          StringBuilder newValue = new StringBuilder();
          while (idx < commandParts.length) {
            newValue.append(commandParts[idx]).append(" ");
            idx++;
          }
          resultMap.put("newValue", newValue.toString().trim());
        } else {
          throw new IllegalArgumentException("Missing new value after property name");
        }
      } else {
        idx++;
      }
    }

    // Check if calendar name was provided
    if (!resultMap.containsKey("calendarName")) {
      throw new IllegalArgumentException("Calendar name must be provided with --name parameter");
    }

    if (!resultMap.containsKey("property")) {
      throw new IllegalArgumentException("Property must be provided with --property parameter");
    }

    if (!resultMap.containsKey("newValue")) {
      throw new IllegalArgumentException("NewValue must be provided with --property parameter");
    }

    return resultMap;
  }

  private Map<String, String> parseEditEvents(String[] commandParts, int idx,
                                              Map<String, String> resultMap) {
    resultMap.put("object", "events");
    idx++;


    // get the property to edit.
    if (idx < commandParts.length) {
      resultMap.put("property", commandParts[idx]);
      idx++;

      // Check for quoted strings
      if (idx < commandParts.length && commandParts[idx].startsWith("\"")) {
        // Get the quoted strings
        List<String> quotedParts = ParserUtils.extractQuotedStrings(commandParts, idx);
        // get the eventName and newValue.
        if (quotedParts.size() >= 2) {
          resultMap.put("eventName", quotedParts.get(0));
          resultMap.put("newValue", quotedParts.get(1));
          return resultMap;
        }
      }

      // Get the event name
      StringBuilder eventName = new StringBuilder();
      while (idx < commandParts.length && !commandParts[idx].equals("from")
              && !commandParts[idx].equals("with")) {
        eventName.append(commandParts[idx]).append(" ");
        idx++;
      }
      resultMap.put("eventName", eventName.toString().trim());

      // get the startTime if present
      if (idx + 1 < commandParts.length && commandParts[idx].equals("from")) {
        idx++;
        resultMap.put("startTime", commandParts[idx]);
        idx++;
      }

      // get the new value
      getNewValueForProperties(commandParts, resultMap, idx);

    }
    return resultMap;
  }

  private Map<String, String> parseEditEvent(String[] commandParts, int idx,
                                             Map<String, String> resultMap) {
    resultMap.put("object", "event");
    idx++;
    // get the property to edit.
    if (idx < commandParts.length) {
      resultMap.put("property", commandParts[idx]);
      idx++;

      // get eventname if present
      StringBuilder eventName = new StringBuilder();
      while (idx < commandParts.length && !commandParts[idx].equals("from")) {
        eventName.append(commandParts[idx]).append(" ");
        idx++;
      }
      resultMap.put("eventName", eventName.toString().trim());

      // get startTime if present
      if (idx + 1 < commandParts.length && commandParts[idx].equals("from")) {
        idx++;
        resultMap.put("startTime", commandParts[idx]);
        idx++;
      }

      // get endTime if present
      if (idx + 1 < commandParts.length && commandParts[idx].equals("to")) {
        idx++;
        resultMap.put("endTime", commandParts[idx]);
        idx++;
      }

      // get the new value
      getNewValueForProperties(commandParts, resultMap, idx);
    }
    return resultMap;
  }

  private void getNewValueForProperties(String[] commandParts,
                                        Map<String, String> resultMap, int idx) {
    if (idx + 1 < commandParts.length && commandParts[idx].equals("with")) {
      idx++;

      // get the all the remaining elements in the array as the newValue.
      StringBuilder newValue = new StringBuilder();
      while (idx < commandParts.length) {
        newValue.append(commandParts[idx]).append(" ");
        idx++;
      }
      resultMap.put("newValue", newValue.toString().trim());
    }
  }

  @Override
  public boolean canHandle(String command) {
    return "edit".equals(command);
  }
}
