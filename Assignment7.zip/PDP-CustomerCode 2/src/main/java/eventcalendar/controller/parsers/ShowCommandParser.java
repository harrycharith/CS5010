package eventcalendar.controller.parsers;

import java.util.HashMap;
import java.util.Map;

import eventcalendar.controller.CommandParserStrategy;

/**
 * A parser implementation for handling show commands in the event calendar system.
 */
public class ShowCommandParser implements CommandParserStrategy {

  @Override
  public Map<String, String> parse(String[] commandParts) throws IllegalArgumentException {
    Map<String, String> resultMap = new HashMap<>();
    resultMap.put("command", "show");

    // check if we have a word at index 1.
    resultMap.put("action", "status");

    // Start the index after the second word "command".
    int idx = 2;

    if (commandParts.length > idx + 1 && commandParts[idx].equals("on")) {
      idx++;
      resultMap.put("time", commandParts[idx]);
    } else {
      throw new IllegalArgumentException("Invalid Create Command after: " + commandParts[idx - 1]);
    }

    return resultMap;
  }

  @Override
  public boolean canHandle(String command) {
    return "show".equals(command);
  }
}
