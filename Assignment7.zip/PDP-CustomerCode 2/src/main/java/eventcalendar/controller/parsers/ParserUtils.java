package eventcalendar.controller.parsers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * A utils file for storing common Parser logic.
 */
public class ParserUtils {

  /**
   * Common utils method to extract Calendar name from commandParts.
   */
  public static int extractCalendarName(String[] commandParts,
                                        Map<String, String> resultMap, int idx) {
    idx++;
    if (idx >= commandParts.length) {
      throw new IllegalArgumentException("Missing value after --name parameter");
    }

    StringBuilder calendarName = new StringBuilder();
    while (idx < commandParts.length && !commandParts[idx].startsWith("--")) {
      calendarName.append(commandParts[idx]).append(" ");
      idx++;
    }

    String name = calendarName.toString().trim();
    if (name.isEmpty()) {
      throw new IllegalArgumentException("Calendar name cannot be empty (CommandParser)");
    }

    resultMap.put("calendarName", name);
    return idx;
  }

  /**
   * Common utils method to clear Quoted strings from commandParts.
   */
  public static List<String> extractQuotedStrings(String[] commandParts, int idx) {
    List<String> quotedParts = new ArrayList<>();
    StringBuilder current = null;

    for (int i = idx; i < commandParts.length; i++) {
      String part = commandParts[i];

      if (part.startsWith("\"")) {
        // Single quoted part.
        if (part.endsWith("\"") && part.length() > 1) {
          quotedParts.add(part.substring(1, part.length() - 1));
        }
        // Start of the quoted part.
        else {
          current = new StringBuilder();
          current.append(part.substring(1)).append(" ");
        }
      }
      // End of the quoted part
      else if (part.endsWith("\"") && current != null) {
        current.append(part, 0, part.length() - 1);
        quotedParts.add(current.toString());
        current = null;
      }
      // continued quoted middle part.
      else if (current != null) {
        current.append(part).append(" ");
      }
    }

    return quotedParts;
  }

  /**
   * Parses the common pattern from commandParts.
   */
  public static int parseOnTargetToPattern(String[] commandParts, int idx,
                                           Map<String, String> resultMap, boolean isEvent) {
    // Parse date/time information
    if (idx < commandParts.length) {
      if (commandParts[idx].equals("on")) {
        idx++;
        if (idx < commandParts.length) {
          // For single events we expect dateTime, for multiple events just date
          String sourceKey = isEvent ? "sourceDateTime" : "sourceDate";
          resultMap.put(sourceKey, commandParts[idx]);
          idx++;
        } else {
          throw new IllegalArgumentException("Invalid Command: Missing date after 'on'");
        }
      } else {
        throw new IllegalArgumentException("Expected 'on' keyword for specifying event date");
      }
    } else {
      throw new IllegalArgumentException("Date and time information is not provided.");
    }

    // Parse target calendar
    if (idx < commandParts.length && commandParts[idx].equals("--target")) {
      idx++;
      if (idx >= commandParts.length) {
        throw new IllegalArgumentException("Missing calendar name after --target parameter");
      }

      // Extract the target calendar name (it might contain spaces)
      StringBuilder targetCalendar = new StringBuilder();
      while (idx < commandParts.length && !commandParts[idx].equals("to")) {
        targetCalendar.append(commandParts[idx]).append(" ");
        idx++;
      }
      resultMap.put("targetCalendar", targetCalendar.toString().trim());
    } else {
      throw new IllegalArgumentException("Target calendar must be specified with " +
              "--target parameter");
    }

    // Parse the destination date/time (after "to")
    if (idx < commandParts.length && commandParts[idx].equals("to")) {
      idx++;
      if (idx < commandParts.length) {
        // For single events we expect dateTime, for multiple events just date
        String targetKey = isEvent ? "targetDateTime" : "targetDate";
        resultMap.put(targetKey, commandParts[idx]);
        idx++;
      } else {
        throw new IllegalArgumentException("Missing target date after 'to' keyword");
      }
    } else {
      throw new IllegalArgumentException("Target date must be specified with 'to' parameter");
    }

    return idx;
  }

}
