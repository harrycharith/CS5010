package eventcalendar.controller.parsers;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import eventcalendar.controller.CommandParserStrategy;

/**
 * Parses the "show calendar dashboard" command for the calendar analytics feature.
 * Expects the format: "show calendar dashboard from <date> to <date>" with dates in YYYY-MM-DD.
 */
public class DashboardCommandParser implements CommandParserStrategy {
  private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

  /**
   * Parses the command parts into a map of parameters.
   *
   * @param commandParts the array of command tokens
   * @return a map containing the command, object, startDate, and endDate
   * @throws IllegalArgumentException if the command format or dates are invalid
   */
  @Override
  public Map<String, String> parse(String[] commandParts) throws IllegalArgumentException {
    if (commandParts.length != 7
            || !commandParts[1].equalsIgnoreCase("calendar")
            || !commandParts[2].equalsIgnoreCase("dashboard")
            || !commandParts[3].equalsIgnoreCase("from")
            || !commandParts[5].equalsIgnoreCase("to")) {
      throw new IllegalArgumentException(
              "Invalid dashboard command format. Expected: show calendar dashboard from <date> to <date>");
    }

    try {
      LocalDate startDate = LocalDate.parse(commandParts[4], DATE_FORMATTER);
      LocalDate endDate = LocalDate.parse(commandParts[6], DATE_FORMATTER);
      if (endDate.isBefore(startDate)) {
        throw new IllegalArgumentException("End date cannot be before start date.");
      }

      Map<String, String> params = new HashMap<>();
      params.put("command", "show");
      params.put("object", "dashboard");
      params.put("startDate", commandParts[4]);
      params.put("endDate", commandParts[6]);
      return params;
    } catch (Exception e) {
      throw new IllegalArgumentException("Invalid date format. Use YYYY-MM-DD.");
    }
  }

  /**
   * Checks if this parser can handle the given command.
   *
   * @param command the command string to check
   * @return true if the command starts with "show calendar dashboard", false otherwise
   */
  @Override
  public boolean canHandle(String command) {
    return command.toLowerCase().startsWith("show calendar dashboard");
  }
}