package eventcalendar.controller;

import java.util.Map;

/**
 * Strategy interface for parsing different types of commands in the event calendar system.
 */
public interface CommandParserStrategy {

  /**
   * Parses the given command parts into a map of command parameters.
   *
   * @param commandParts Array of strings representing the parts of a command.
   * @return Map containing the parsed command parameters where key is the parameter name
   *         and value is the parameter value.
   * @throws IllegalArgumentException if the command format is invalid or cannot be parsed.
   */
  Map<String, String> parse(String[] commandParts) throws IllegalArgumentException;

  /**
   * Checks if this parser implementation can handle the specified command.
   *
   * @param command The command string to check.
   * @return true if this parser can handle the command, false otherwise.
   */
  boolean canHandle(String command);
}
