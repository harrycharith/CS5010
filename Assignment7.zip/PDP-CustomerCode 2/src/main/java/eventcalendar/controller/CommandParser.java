package eventcalendar.controller;

import java.util.Map;

/**
 * This is a command Parser class that parses and validates
 * the given command.
 */
public class CommandParser {
  private final CommandParserFactory parserFactory;

  public CommandParser() {
    this.parserFactory = new CommandParserFactory();
  }

  /**
   * Parses and validates the given command.
   *
   * @param command The command string to be parsed.
   * @return Map containing details of the parsed command.
   */
  public Map<String, String> parseCommand(String command) throws IllegalArgumentException {
    // Remove extra whitespaces
    command = command.trim().replaceAll("\\s+", " ");

    // Split into tokens
    String[] commandParts = command.split(" ");

    if (commandParts.length < 1) {
      throw new IllegalArgumentException("Invalid command: " + command);
    }

    // Get the command to act on.
    String action = commandParts[0];

    // Get the appropriate parser and delegate the parsing
    CommandParserStrategy parser = parserFactory.getParser(action);
    return parser.parse(commandParts);
  }

}