package eventcalendar.controller;

import java.awt.GraphicsEnvironment;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.function.Consumer;

import javax.swing.SwingUtilities;

import eventcalendar.model.ICalendar;
import eventcalendar.model.ICalendarManager;
import eventcalendar.view.CalendarFrame;
import eventcalendar.view.View;

import static eventcalendar.Main.CHECK_CALENDAR_COMMAND;
import static eventcalendar.Main.EXIT_COMMAND;

/**
 * Represents a controller class that handles command processing and control flow.
 * it handles the interactive and headless mode separately in distinct methods.
 */
public class Controller {
  private ICalendar calendar;

  /**
   * This controller initializes the calendar attribute with a calendar object.
   *
   * @param calendar object to be used initially.
   */
  public Controller(ICalendar calendar) {
    this.calendar = calendar;
  }

  /**
   * This method runs the application in interactive mode.
   * The user can type commands and see the results on the screen.
   *
   * @param calendarManager CalendarManager object to manage all the calendars.
   * @param view            The view instance to be used for a particular session.
   */
  public void runInteractiveMode(ICalendarManager calendarManager, View view) throws IOException {
    // Print the details.
    System.out.println("Calendar - Interactive Mode");
    System.out.println("Type 'exit' to quit the application");
    System.out.println("\"" + calendar.getName() + "\"" + " Calender is being used");
    System.out.println("Enter command:");

    // try block for the entered commands and to close the scanner automatically.
    // Initialize the scanner.
    try (Scanner scanner = new Scanner(System.in)) {
      // to store the entered command.
      String commandInput;

      while (true) {
        System.out.print("> ");
        commandInput = scanner.nextLine().trim();

        // Check if the 'exit' command was entered and exit if needed.
        if (EXIT_COMMAND.equalsIgnoreCase(commandInput)) {
          System.out.println("Exit command entered, closing the application");
          break;
        }

        // Check if the 'check calendar' command was entered and exit if needed.
        if (CHECK_CALENDAR_COMMAND.equalsIgnoreCase(commandInput)) {
          System.out.println(calendar.getName() + " is being used.");
          continue;
        }

        String result = getString(calendarManager, view, commandInput);

        // Display the result using the view
        view.displayMessage(result);
      }
    }
  }

  private String getString(ICalendarManager calendarManager, View view, String commandInput) {
    Consumer<ICalendar> updateCalendarConsumer = null;
    if (commandInput.startsWith("use")) {
      updateCalendarConsumer = newCalendar -> {
        calendar = newCalendar;
      };
    }
    // Processing the input command using the commandProcessor and the view
    // define a CommandProcessor instance to process the command.
    CommandProcessor commandProcessor = new CommandProcessor(calendarManager,
            updateCalendarConsumer, this, calendar, view, commandInput);
    // Send the input command to the commandProcessor and get the string result.
    return commandProcessor.processCommand(commandInput);
  }

  /**
   * This method runs the application in headless mode where commands
   * are fed and read from a file and executed.
   *
   * @param calendarManager CalendarManager object to manage all the calendars.
   * @param view            The view instance to be used for a particular session.
   * @param commandsFile    The file containing commands to execute all together.
   */
  public void runHeadlessMode(ICalendarManager calendarManager, View view, String commandsFile)
          throws Exception {
    // Print the details.
    System.out.println("Calendar - Headless Mode");
    System.out.println("Executing commands from file: " + commandsFile);

    // try catch block to read the file and use controller, model and view
    // to do their work.
    try (BufferedReader reader = new BufferedReader(new FileReader(commandsFile))) {
      // To store each command.
      String commandInput;
      // initialize the starting line number to read from the txt file.
      // boolean to check if the 'exit' command is found.
      boolean exitCommandFound = false;

      // Traverse the file till a new command is detected
      while ((commandInput = reader.readLine()) != null) {
        // Fetch the current line containing a command.
        commandInput = commandInput.trim();

        // continue if the line does not have a command.
        if (commandInput.isEmpty()) {
          continue;
        }

        // send the display message to the view instance.
        view.displayMessage("Executing: " + commandInput);

        // stop processing if 'exit' command is found.
        if (EXIT_COMMAND.equalsIgnoreCase(commandInput)) {
          view.displayMessage("Exit command found. Remaining commands not executed. " +
                  "\nSayo-Nara!");
          exitCommandFound = true;
          break;
        }

        // Get the response from execution of the command entered.
        String result = getString(calendarManager, view, commandInput);

        // Display the result using the view
        view.displayMessage(result);
      }

      // Check if the last command was exit
      if (!exitCommandFound) {
        view.displayMessage("Error: The last command in the file must be 'exit'");
      }
    } catch (IOException e) {
      throw new IOException("Error reading commands file: " + e.getMessage());
    }
  }

  /**
   * This method runs the application in GUI mode.
   * The user can interactively create,edit, and view events in a digital calendar.
   *
   * @param calendarManager CalendarManager object to manage all the calendars.
   */
  public void runGUIMode(ICalendarManager calendarManager, View view) {
    view.displayMessage("Running GUI mode.");
    SwingUtilities.invokeLater(() -> {
      // Skipping gui for headless env.
      if (GraphicsEnvironment.isHeadless()) {
        System.err.println("Headless environment detected. Skipping GUI.");
        return;
      }
      CalendarFrame calendarFrame = new CalendarFrame(calendar, calendarManager);
      calendarFrame.setVisible(true);
    });
  }

}
