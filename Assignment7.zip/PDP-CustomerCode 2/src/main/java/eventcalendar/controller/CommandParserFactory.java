package eventcalendar.controller;

import java.util.ArrayList;
import java.util.List;

import eventcalendar.controller.parsers.CopyCommandParser;
import eventcalendar.controller.parsers.CreateCommandParser;
import eventcalendar.controller.parsers.DashboardCommandParser;
import eventcalendar.controller.parsers.EditCommandParser;
import eventcalendar.controller.parsers.ExportCommandParser;
import eventcalendar.controller.parsers.PrintCommandParser;
import eventcalendar.controller.parsers.ShowCommandParser;
import eventcalendar.controller.parsers.UseCommandParser;

/**
 * Creates and manages command parser strategies for the calendar application.
 */
public class CommandParserFactory {
  private final List<CommandParserStrategy> parsers = new ArrayList<>();

  /**
   * Initializes the factory with all available command parsers.
   */
  public CommandParserFactory() {
    parsers.add(new CreateCommandParser());
    parsers.add(new EditCommandParser());
    parsers.add(new PrintCommandParser());
    parsers.add(new ExportCommandParser());
    parsers.add(new ShowCommandParser());
    parsers.add(new UseCommandParser());
    parsers.add(new CopyCommandParser());
    parsers.add(new DashboardCommandParser());
  }

  /**
   * Retrieves the appropriate parser strategy for the given command.
   *
   * @param command the command string to parse
   * @return the matching CommandParserStrategy
   * @throws IllegalArgumentException if no parser can handle the command
   */
  public CommandParserStrategy getParser(String command) {
    for (CommandParserStrategy parser : parsers) {
      if (parser.canHandle(command)) {
        return parser;
      }
    }
    throw new IllegalArgumentException("Unknown command: " + command);
  }
}