package eventcalendar.controller.commands;

import java.util.Map;

/**
 * The Command interface represents an executable command in the event calendar system.
 */
public interface Command {
  String execute(Map<String, String> args);
}
