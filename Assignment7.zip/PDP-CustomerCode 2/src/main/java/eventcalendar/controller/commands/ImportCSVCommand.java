package eventcalendar.controller.commands;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import eventcalendar.model.ICalendar;

/**
 * A command class that imports calendar events from a CSV file
 * to the selected calendar.
 * The CSV file format follows a standard calendar import/export,
 * format compatible with most calendar applications.
 */
public class ImportCSVCommand extends AbstractCommand {
  // Format date as MM/dd/yyyy
  private static final DateTimeFormatter DATE_FORMATTER =
          DateTimeFormatter.ofPattern("yyyy-MM-dd");
  // Format time as h:mm a (for example, 10:00 AM)
  private static final DateTimeFormatter TIME_FORMATTER =
          DateTimeFormatter.ofPattern("h:mm a", Locale.US);
  // Format time as HH:mm
  private static final DateTimeFormatter TIME_FORMATTER_HHmm =
          DateTimeFormatter.ofPattern("HH:mm");
  // Format DateTime as MM/dd/yyyy'T'HH:mm
  private static final DateTimeFormatter DATE_TIME_FORMATTER =
          DateTimeFormatter.ofPattern("MM/dd/yyyy'T'HH:mm");

  // Format DateTime as yyyy-MM-dd'T'HH:mm
  private static final DateTimeFormatter DATE_TIME_FORMATTER_HYPHEN =
          DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");

  /**
   * This method converts the time format from 'h:mm a' to 'HH:mm'.
   */
  private static String convertTimeFormat(String googleCalendarTime) {
    try {
      // Parse the 'h:mm a' time string
      LocalTime gcTime = LocalTime.parse(googleCalendarTime.trim().toUpperCase(), TIME_FORMATTER);
      // Format the time to 24-hour format
      return gcTime.format(TIME_FORMATTER_HHmm);
    } catch (Exception e) {
      return "Invalid time format: " + e.getMessage();
    }
  }

  /**
   * This method converts the date time string with '/' to a date time string with '-'.
   */
  private static String convertDateTimeFormat(String dateTimeStr) {
    // Parse the dateTimeStr to a LocalDateTime object
    LocalDateTime oldDateTime = LocalDateTime.parse(dateTimeStr, DATE_TIME_FORMATTER);

    // Format the parsed LocalDateTime object into the desired format and return it.
    return oldDateTime.format(DATE_TIME_FORMATTER_HYPHEN);
  }


  @Override
  public String execute(Map<String, String> args) {
    return "";
  }

  /**
   * This method overrides the execute method and takes in a calendar object
   * and a file object.
   *
   * @param calendar calendar object to import the events into.
   * @param file csv file to import the events from.
   * @return a string indicating the result of this operation.
   * @throws IOException when csv file is invalid.
   */
  public String execute(ICalendar calendar, File file) throws IOException {
    if (calendar == null) {
      return "Error: Please choose a Calendar.";
    }

    if (file == null || !file.exists()) {
      return "Error: File not found.";
    }

    try {
      // Using CSVParser to parse the file and get the hashmap with key value pairs.
      Map<String, List<String[]>> csvData = CSVParser.parseCSV(file);

      // Get the headers and data rows.
      List<String[]> rows = csvData.get("rows");
      String[] headers = csvData.get("headers").get(0);

      // Map column names to indices.
      Map<String, Integer> columnToIndxMap = CSVParser.mapColumns(headers);

      // Track the imported events
      int importedEventsCount = 0;
      StringBuilder errors = new StringBuilder();

      // traverse through the rows for each row data.
      int numberOfEvents = 0;
      for (String[] row : rows) {
        numberOfEvents++;
        try {
          boolean added = addEvent(row, columnToIndxMap, calendar);
          if (added) {
            importedEventsCount++;
          }
        } catch (Exception e) {
          errors.append("Row Error: ").append(e.getMessage()).append("\n");
        }
      }

      if (importedEventsCount != numberOfEvents) {
        return "Number of conflicted events: " + (numberOfEvents - importedEventsCount);
      }
      String result = importedEventsCount + " events were imported successfully";
      if (errors.length() > 0) {
        result += "\nThe below errors occrued:\n" + errors;
      }

      return result;
    } catch (IOException e) {
      throw new IOException("Error reading CSV file: " + e.getMessage());
    } catch (Exception e) {
      return "Error importing events: " + e.getMessage();
    }
  }

  /**
   * Create and add an event to the specified calendar.
   */
  private boolean addEvent(String[] row, Map<String, Integer> columnToIndxMap,
                           ICalendar calendar) throws DateTimeParseException {
    // Extract the fields using the google calendar format.
    // // Get "Subject"
    String subject = CSVParser.getData(row, columnToIndxMap, "Subject");
    if (subject.isEmpty()) {
      subject = "No Name event";
    }
    // // Get the remaining fields.
    String startDateStr = CSVParser.getData(row, columnToIndxMap, "Start Date");
    String startTimeStr = CSVParser.getData(row, columnToIndxMap, "Start Time");
    String endDateStr = CSVParser.getData(row, columnToIndxMap, "End Date");
    String endTimeStr = CSVParser.getData(row, columnToIndxMap, "End Time");
    String allDayStr = CSVParser.getData(row, columnToIndxMap, "All Day Event");
    String description = CSVParser.getData(row, columnToIndxMap, "Description");
    String location = CSVParser.getData(row, columnToIndxMap, "Location");

    //    // debug
    //    System.out.println("Start Date: " + startDateStr);
    //    System.out.println("Start Time: " + startTimeStr);
    //    System.out.println("End Date: " + endDateStr);
    //    System.out.println("Start Time: " + endTimeStr);
    //    System.out.println("All Day Event: " + allDayStr);
    //    System.out.println("Description: " + description);
    //    System.out.println("Location: " + location);


    // Get the dates and times
    // Get is all day boolean value
    boolean isAllDay = allDayStr.equalsIgnoreCase("true")
            || allDayStr.equalsIgnoreCase("yes");

    // Get the start date time
    if (isAllDay || startTimeStr.isEmpty()) {
      startTimeStr = "00:00";
    } else {
      startTimeStr = convertTimeFormat(startTimeStr);
    }
    String startDateTimeStr = convertDateTimeFormat(startDateStr + 'T' + startTimeStr);


    if (isAllDay || endTimeStr.isEmpty()) {
      endTimeStr = "23:59";
    } else {
      endTimeStr = convertTimeFormat(endTimeStr);
    }

    String endDateTimeStr = convertDateTimeFormat(endDateStr + 'T' + endTimeStr);


    //    // debug
    //    System.out.println("Start Date Time: " + startDateTimeStr);
    //    System.out.println("End Date Time: " + endDateStr + 'T' + endTimeStr);


    // Create event
    CreateEventCommand command = new CreateEventCommand(calendar);
    boolean autoDecline = true;
    Map<String, String> args = new HashMap<>();
    args.put("eventName", subject);
    args.put("startTime", startDateTimeStr);
    args.put("endTime", endDateTimeStr);
    args.put("autoDecline", "True");

    // This will now be displayed anywhere.
    String response = command.execute(args);

    return response.contains("Event created successfully:");
  }

}
