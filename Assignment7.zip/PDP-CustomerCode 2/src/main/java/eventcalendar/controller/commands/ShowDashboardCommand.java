package eventcalendar.controller.commands;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Map;

import eventcalendar.model.CalendarAnalytics;
import eventcalendar.model.ICalendar;
import eventcalendar.view.View;

/**
 * Executes the "show calendar dashboard" command to display analytics metrics.
 * Generates a dashboard for the specified date range and displays it via the view.
 */
public class ShowDashboardCommand implements Command {
  private final ICalendar calendar;
  private final View view;
  private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

  /**
   * Constructs a ShowDashboardCommand with the specified calendar and view.
   *
   * @param calendar the calendar to analyze
   * @param view the view to display the dashboard
   */
  public ShowDashboardCommand(ICalendar calendar, View view) {
    this.calendar = calendar;
    this.view = view;
  }

  /**
   * Executes the command to generate and display the analytics dashboard.
   *
   * @param params a map containing startDate and endDate in YYYY-MM-DD format
   * @return the dashboard string or an error message if execution fails
   */
  @Override
  public String execute(Map<String, String> params) {
    try {
      LocalDate startDate = LocalDate.parse(params.get("startDate"), DATE_FORMATTER);
      LocalDate endDate = LocalDate.parse(params.get("endDate"), DATE_FORMATTER);
      CalendarAnalytics analytics = new CalendarAnalytics(calendar);
      String dashboard = analytics.generateDashboard(startDate, endDate);
      view.displayMessage(dashboard);
      return dashboard;
    } catch (Exception e) {
      return "Error generating dashboard: " + e.getMessage();
    }
  }
}