package eventcalendar.controller.commands;

import java.time.ZoneId;
import java.util.Map;

import eventcalendar.model.Calendar;
import eventcalendar.model.ICalendarManager;
import eventcalendar.model.ModelUtils;

/**
 * Command class responsible for creating calendars in the calendar manager.
 * It creates a new calendar with a unique name and timezone as specified by the user.
 * The expected timezone format is the IANA Time Zone Database format Links to an
 * external site. . In this format the timezone is specified as "area/location".
 * Few examples include "America/New_York", "Europe/Paris", "Asia/Kolkata",
 * "Australia/Sydney", "Africa/Cairo", etc.
 *
 * <p>The command is invalid if the user provides a non-unique calendar name or
 * an unsupported timezone.
 */
public class CreateCalendarCommand implements Command {
  private final ICalendarManager calendarManager;

  /**
   * This is the constructor for the CreateCalenderCommand class.
   *
   * @param calendarManager obj to orchestrate calendars.
   */
  public CreateCalendarCommand(ICalendarManager calendarManager) {
    this.calendarManager = calendarManager;
  }

  @Override
  public String execute(Map<String, String> args) {
    String calendarName = ModelUtils.getValue(args, "calendarName");
    if (calendarName == null || calendarName.isEmpty()) {
      return "Calendar name cannot be empty";
    }
    // Check is the Calendar name is already present
    if (calendarManager.hasCalendarName(calendarName)) {
      return calendarName + " is already present, choose another name.";
    }

    String calendarTimeZone = args.get("calendarTimeZone");
    // Remove quotes if they exist
    if (calendarTimeZone != null && calendarTimeZone.startsWith("\"")
            && calendarTimeZone.endsWith("\"")) {
      calendarTimeZone = calendarTimeZone.substring(1, calendarTimeZone.length() - 1);
    }
    if (calendarTimeZone == null || calendarTimeZone.isEmpty()) {
      return "Calendar TimeZone cannot be empty";
    }

    // Check if the Timezone is correct in format is correct
    ZoneId calendarZoneId;
    try {
      // Get the ZoneId from String CalendarTimezone.
      ZoneId.of(calendarTimeZone);
    } catch (Exception e) {
      return "Error: Invalid timezone '" + calendarTimeZone +
              "'. Please use IANA Time Zone Database format (area/location).\n" +
              "Examples: America/New_York, Europe/Paris, Asia/Kolkata";
    }

    // Create the Calendar using builder.
    Calendar.Builder calendar = new Calendar.Builder()
            .name(calendarName)
            .timeZone(calendarTimeZone);

    // Add the calendar to the Calendar manager.
    calendarManager.addCalendar(calendar);

    return "Calendar created successfully: " + calendarName;
  }
}
