package eventcalendar.controller.commands;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import eventcalendar.model.Calendar;
import eventcalendar.model.ICalendar;
import eventcalendar.model.ModelUtils;
import eventcalendar.model.SingleEvent;
import eventcalendar.model.WeekDays;
import eventcalendar.view.View;

/**
 * Command class responsible for creating events in the calendar system.
 * This class handles the creation of three types of events:
 * 1. All-day events
 * 2. Time-specific events
 * 3. Recurring events (both all-day and time-specific)
 *
 * <p>Date formats supported:
 * - Date only: "yyyy-MM-dd"
 * - Date and time: "yyyy-MM-dd'T'HH:mm"
 *
 * <p>For recurring events, weekdays are specified using the following format:
 * - M (Monday), T (Tuesday), W (Wednesday), R (Thursday),
 * - F (Friday), S (Saturday), U (Sunday)
 * Example: "MWF" for Monday-Wednesday-Friday
 *
 * @see Command
 * @see Calendar
 * @see View
 * @see SingleEvent
 * @see WeekDays
 */
public class CreateEventCommand implements Command {

  private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
  private static final DateTimeFormatter DATE_TIME_FORMATTER =
          DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");
  private final ICalendar calendar;

  /**
   * Constructs a new CreateEventCommand with the specified calendar and view.
   *
   * @param calendar the calendar where events will be created
   */
  public CreateEventCommand(ICalendar calendar) {
    this.calendar = calendar;
  }

  /**
   * The Command interface represents an executable command in the event calendar system.
   */
  @Override
  public String execute(Map<String, String> args) {
    String eventName = ModelUtils.getValue(args, "eventName");
    if (eventName == null) {
      return "Event name cannot be empty";
    }

    boolean autoDecline = Boolean.parseBoolean(args.get("autoDecline"));

    // check if its an all day event
    boolean isAllDay = args.containsKey("date");

    try {
      if (isAllDay) {
        return createAllDayEvent(args, eventName, autoDecline);
      } else {
        return createTimeSpecificEvent(args, eventName, autoDecline);
      }
    } catch (DateTimeParseException e) {
      return "Incorrect date format for creating event" + e.getMessage();
    } catch (Exception e) {
      return "Error while creating event " + e.getMessage();
    }
  }

  /**
   * Creates an all-day event in the calendar.
   * The event can be either a single occurrence or recurring.
   *
   * @param args        A map containing event parameters
   * @param eventName   The name/title of the event
   * @param autoDecline If true, automatically declines conflicting events when adding this event
   * @return A string message indicating success or failure of event creation
   */
  private String createAllDayEvent(Map<String, String> args, String eventName,
                                   boolean autoDecline) {
    LocalDate date = LocalDate.parse(args.get("date"), DATE_FORMATTER);

    if (args.containsKey("repeatDays")) {
      LocalDateTime startDateTime = date.atStartOfDay();
      LocalDateTime endDateTime = date.atTime(23, 59, 59);
      return createRecurringEvent(args, eventName, startDateTime, endDateTime, autoDecline);
    }

    // Get optional parameters
    String description = args.getOrDefault("description", null);
    String location = args.getOrDefault("location", null);
    boolean isPublic = Objects.equals(args.getOrDefault("isPublic", "true"), "true");

    // Parse end date if provided
    LocalDate endDate = null;
    if (args.containsKey("endDate")) {
      endDate = LocalDate.parse(args.get("endDate"), DATE_FORMATTER);
    }

    // Use the model's method to create the all-day event
    boolean added = calendar.createAllDayEvent(eventName, date, endDate, description, location,
            isPublic, autoDecline);

    if (added) {
      return "All-day event created successfully: " + eventName;
    } else {
      return "Could not create event due to conflicts.";
    }
  }

  /**
   * Creates a time-specific event in the calendar based on provided arguments.
   * If repeatDays is specified in the arguments, creates a recurring event instead.
   *
   * @param args        A map containing event details with possible keys
   * @param eventName   The name of the event to be created
   * @param autoDecline Whether to automatically decline conflicting events
   * @return A string message indicating success or failure of event creation
   * @throws DateTimeParseException if startTime or endTime cannot be parsed
   */
  private String createTimeSpecificEvent(Map<String, String> args,
                                         String eventName, boolean autoDecline) {
    LocalDateTime startDateTime = LocalDateTime.parse(args.get("startTime"), DATE_TIME_FORMATTER);
    LocalDateTime endDateTime = LocalDateTime.parse(args.get("endTime"), DATE_TIME_FORMATTER);

    // Check if this should be a recurring event
    if (args.containsKey("repeatDays")) {
      return createRecurringEvent(args, eventName, startDateTime, endDateTime, autoDecline);
    }

    // Get optional parameters
    String description = args.getOrDefault("description", null);
    String location = args.getOrDefault("location", null);
    boolean isPublic = Objects.equals(args.getOrDefault("isPublic", "true"), "true");

    // Use the model's method to create the event
    boolean added = calendar.createEvent(eventName, startDateTime, endDateTime, description,
            location, isPublic, autoDecline);

    if (added) {
      return "Event created successfully: " + eventName;
    } else {
      return "Could not create event due to conflicts.";
    }
  }

  /**
   * Creates recurring events based on specified parameters and pattern.
   *
   * @param args          Map containing event parameters including
   * @param eventName     Name of the event
   * @param startDateTime Start date and time of the event
   * @param endDateTime   End date and time of the event
   * @param autoDecline   Whether to automatically decline conflicting events
   * @return A string message
   * @throws DateTimeParseException If date/time values cannot be parsed
   */
  private String createRecurringEvent(Map<String, String> args, String eventName,
                                      LocalDateTime startDateTime, LocalDateTime endDateTime,
                                      boolean autoDecline) {
    // check if the event is an all day event
    boolean isAllDay = args.containsKey("date");

    try {
      if (isAllDay) {
        LocalDate date = LocalDate.parse(args.get("date"), DATE_FORMATTER);
        startDateTime = date.atStartOfDay();
        endDateTime = date.atTime(23, 59, 59);
      }

      // parse weekday pattern
      String weekdaysPattern = args.get("repeatDays");
      // Remove quotes if they exist
      if (weekdaysPattern != null && weekdaysPattern.startsWith("\"")
              && weekdaysPattern.endsWith("\"")) {
        weekdaysPattern = weekdaysPattern.substring(1, weekdaysPattern.length() - 1);
      }
      if (weekdaysPattern == null || weekdaysPattern.isEmpty()) {
        return "Recurring event must specify weekdays pattern (e.g., MWF)";
      }

      // Add logic to check if the start date specified is part of the recurrence pattern.
      String startDay = String.valueOf(convertDayOfWeekToWeekDays(startDateTime.getDayOfWeek()));
      if (!weekdaysPattern.contains(startDay)) {
        return "Event start day should be part of the recurrence pattern";
      }

      // convert from the string to list as needed
      List<WeekDays> repeatDays = parseWeekdays(weekdaysPattern);
      if (repeatDays.isEmpty()) {
        return "Invalid weekdays pattern: " + weekdaysPattern;
      }

      // Common event properties
      String description = args.getOrDefault("description", null);
      String location = args.getOrDefault("location", null);
      boolean isPublic = Objects.equals(args.getOrDefault("isPublic", "true"), "true");

      int successCount;

      // Determine if we're creating based on count or until date
      if (args.containsKey("repeatTimes")) {
        int occurrences = Integer.parseInt(args.get("repeatTimes"));
        if (occurrences <= 0) {
          return "Invalid repeatTimes value: " + occurrences;
        }

        // Use the model's method to create recurring events by occurrences
        successCount = calendar.createRecurringEventOccurrences(eventName, startDateTime,
                endDateTime, repeatDays, occurrences, description, location, isPublic, autoDecline);

      } else if (args.containsKey("repeatUntil")) {
        LocalDateTime untilDateTime;

        if (isAllDay) {
          LocalDate untilDate = LocalDate.parse(args.get("repeatUntil"), DATE_FORMATTER);
          untilDateTime = untilDate.atTime(23, 59, 59);
        } else {
          untilDateTime = LocalDateTime.parse(args.get("repeatUntil"), DATE_TIME_FORMATTER);
          if (untilDateTime.isBefore(startDateTime)) {
            return "Invalid until date value; it is before event start date";
          }
        }

        // Use the model's method to create recurring events until a date
        successCount = calendar.createRecurringEventUntil(eventName, startDateTime, endDateTime,
                repeatDays, untilDateTime, description, location, isPublic, autoDecline);

      } else {
        return "Recurring event must specify either repeat count or end date";
      }

      if (successCount > 0) {
        return "Created " + successCount + " recurring events successfully for: " + eventName;
      } else {
        return "Could not create any events due to conflicts.";
      }
    } catch (DateTimeParseException e) {
      return "Invalid date format: " + e.getMessage();
    }
  }

  /**
   * Parses a string of weekday characters (e.g., "MWF") into a list of WeekDays enum values.
   * M = Monday, T = Tuesday, W = Wednesday, R = Thursday, F = Friday, S = Saturday, U = Sunday
   *
   * @param weekdaysPattern A string containing the weekday characters
   * @return A list of WeekDays enum values
   */
  private List<WeekDays> parseWeekdays(String weekdaysPattern) {
    List<WeekDays> weekDays = new ArrayList<>();
    for (char c : weekdaysPattern.toCharArray()) {
      switch (c) {
        case 'M':
          weekDays.add(WeekDays.M);
          break;
        case 'T':
          weekDays.add(WeekDays.T);
          break;
        case 'W':
          weekDays.add(WeekDays.W);
          break;
        case 'R':
          weekDays.add(WeekDays.R);
          break;
        case 'F':
          weekDays.add(WeekDays.F);
          break;
        case 'S':
          weekDays.add(WeekDays.S);
          break;
        case 'U':
          weekDays.add(WeekDays.U);
          break;
        default:
          // invalid weekday character just ignore it
          break;
      }
    }
    return weekDays;
  }

  /**
   * Converts java.time.DayOfWeek to WeekDays enum
   */
  private WeekDays convertDayOfWeekToWeekDays(java.time.DayOfWeek dayOfWeek) {
    switch (dayOfWeek) {
      case MONDAY:
        return WeekDays.M;
      case TUESDAY:
        return WeekDays.T;
      case WEDNESDAY:
        return WeekDays.W;
      case THURSDAY:
        return WeekDays.R;
      case FRIDAY:
        return WeekDays.F;
      case SATURDAY:
        return WeekDays.S;
      case SUNDAY:
        return WeekDays.U;
      default:
        throw new IllegalArgumentException("Unknown day of week: " + dayOfWeek);
    }
  }
}
