package eventcalendar.controller.commands;

/**
 * This abstract class holds the common methods used in all the other classes.
 */
public abstract class AbstractCommand implements Command {
  /**
   * This method removes the quotes if present from a string
   * as gives back the string without quotes.
   *
   * @param str the string to be checked for quotes.
   * @return string object without quotes.
   */
  protected String removeQuotes(String str) {
    if (str != null && str.startsWith("\"") && str.endsWith("\"")) {
      str = str.substring(1, str.length() - 1);
    }
    return str;
  }
}
