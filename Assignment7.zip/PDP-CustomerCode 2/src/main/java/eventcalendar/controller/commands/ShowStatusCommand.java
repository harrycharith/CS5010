package eventcalendar.controller.commands;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import eventcalendar.model.Calendar;
import eventcalendar.model.Event;
import eventcalendar.model.ICalendar;
import eventcalendar.view.View;

/**
 * A command implementation that checks and displays user's availability status at a specific time.
 *
 * <p>The command requires a "time" parameter in the format "yyyy-MM-dd'T'HH:mm"
 *
 * @see Command
 * @see Calendar
 * @see View
 */
public class ShowStatusCommand implements Command {
  private static final DateTimeFormatter DATE_TIME_FORMATTER =
          DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");

  private final ICalendar calendar;

  /**
   * Constructs a new ShowStatusCommand with the specified calendar and view.
   * This command is responsible for displaying the status of events in the calendar.
   *
   * @param calendar the calendar containing events to show status for
   * @param view     the view used to display the calendar status
   */
  public ShowStatusCommand(ICalendar calendar, View view) {
    this.calendar = calendar;
  }

  /**
   * The Command interface represents an executable command in the event calendar system.
   */
  @Override
  public String execute(Map<String, String> args) {
    if (args.containsKey("time")) {
      return showStatus(args);
    } else {
      return "Date Time not specified";
    }
  }

  /**
   * Checks and returns the status of user's availability at a given time.
   * This method determines if there are any events scheduled during the specified time.
   *
   * @param args A Map containing command arguments where the key "time" maps to
   *             a datetime string in the format specified by DATE_TIME_FORMATTER
   * @return A String message
   */
  private String showStatus(Map<String, String> args) {
    String eventTimeStr = args.get("time");
    LocalDateTime givenTime = LocalDateTime.parse(eventTimeStr, DATE_TIME_FORMATTER);

    List<Event> events = calendar.getEvents();

    // Find all events that contain the given time (time is between start and end)
    List<Event> matchingEvents = events.stream()
            .filter(e -> !e.getEventStartDateTime().isAfter(givenTime) &&
                    !e.getEventEndDateTime().isBefore(givenTime))
            .collect(Collectors.toList());

    if (!matchingEvents.isEmpty()) {
      // Format the list of events for better readability
      String eventsList = matchingEvents.stream()
              .map(e -> e.getEventName() + " (" +
                      e.getEventStartDateTime().format(DATE_TIME_FORMATTER) + " to " +
                      e.getEventEndDateTime().format(DATE_TIME_FORMATTER) + ")")
              .collect(Collectors.joining("\n- ", "\n- ", ""));

      return "User is currently busy in the following meeting(s):" + eventsList;
    }

    return "User is available";
  }
}
