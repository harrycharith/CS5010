package eventcalendar.controller.commands;

import java.util.Map;
import java.util.function.Consumer;

import eventcalendar.model.ICalendar;
import eventcalendar.model.ICalendarManager;
import eventcalendar.model.ModelUtils;


/**
 * This class handles the use calendar command functionality.
 *
 * <p>A user can create/edit/print/export events in the context of a calendar.
 * They can use this command to set the calendar context.
 * Note this means that the commands in the previous iteration only make sense
 * when a calendar is in use (i.e. some calendar must be in use for them to work).
 * Otherwise, they are invalid.
 */
public class UseCalendarCommand implements Command {
  private final ICalendarManager calendarManager;
  private final Consumer<ICalendar> updateCalendarConsumer;

  /**
   * This is the constructor for the UseCalenderCommand class.
   *
   * @param calendarManager obj to orchestrate calendars.
   */
  public UseCalendarCommand(ICalendarManager calendarManager,
                            Consumer<ICalendar> updateCalendarConsumer) {
    this.calendarManager = calendarManager;
    this.updateCalendarConsumer = updateCalendarConsumer;
  }

  @Override
  public String execute(Map<String, String> args) {
    // get the calendar name
    String calendarName = ModelUtils.getValue(args, "calendarName");
    if (calendarName == null || calendarName.isEmpty()) {
      return "Calendar name cannot be empty";
    }
    // Check is the Calendar name is present
    if (!calendarManager.hasCalendarName(calendarName)) {
      return calendarName + " is not present in the Calendar Manger, choose another calendar.";
    }

    // Get the calendar and set it as the current calendar
    ICalendar calendar = calendarManager.getCalendar(calendarName);

    // Update the calendar in the Main class
    if (updateCalendarConsumer != null) {
      updateCalendarConsumer.accept(calendar);
      return "Now using calendar: \"" + calendarName + "\"";
    }

    return "Calendar cannot be changed due to null Consumer";
  }
}
