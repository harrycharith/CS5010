package eventcalendar;

import java.io.IOException;

import eventcalendar.controller.Controller;
import eventcalendar.model.Calendar;
import eventcalendar.model.CalendarManager;
import eventcalendar.model.ICalendar;
import eventcalendar.model.ICalendarManager;
import eventcalendar.view.View;

/**
 * Main entry point for the Calendar.
 * This class Supports two modes of operation:
 * 1. Interactive mode: In this mode the user can enter commands one by one and
 * has to type 'exit' command to stop entering commands.
 * 2. Headless mode: In this case the commands are sent to the application and
 * read from a file and executed.
 */
public class Main {
  public static final String EXIT_COMMAND = "exit";
  public static final String CHECK_CALENDAR_COMMAND = "check calendar";
  private static ICalendar calendar;

  /**
   * This the main method that processes command line arguments and
   * decides to run the application in either interactive or headless mode.
   *
   * @param args Command line arguments
   */
  public static void main(String[] args) throws IOException {
    // Initialize the model and view objects for the calendar instance.
    ICalendarManager calendarManager = new CalendarManager();
    // Create the Calendar using builder.
    Calendar.Builder calendarBuilder = new Calendar.Builder();
    calendarManager.addCalendar(calendarBuilder);
    calendar = calendarManager.getCalendar("My Calendar");

    Controller controller = new Controller(calendar);
    View view = new View();

    // check if 'gui' mode is required and run it.
    if (args.length == 0) {
      controller.runGUIMode(calendarManager, view);
      return;
    }

    if (args.length < 2 || !args[0].equalsIgnoreCase("--mode")) {
      printCorrectUsage();
      return;
    }

    // Get the mode in which we have to run the application
    String mode = args[1].toLowerCase();

    // try catch block to check for interactive or headless mode.
    try {
      // check if 'interactive' mode is required and run it.
      if (mode.equals("interactive")) {
        controller.runInteractiveMode(calendarManager, view);
      }
      // check if 'headless' mode is required and run it.
      else if (mode.equals("headless") && args.length >= 3) {
        String commandsFile = args[2];
        controller.runHeadlessMode(calendarManager, view, commandsFile);
      }
      // print this if incorrect mode is entered.
      else {
        printCorrectUsage();
      }
    } catch (Exception e) {
      throw new IOException("Error: " + e.getMessage());
    }
  }

  /**
   * Prints how to use the application.
   * Mostly because the entered command was incorrect.
   */
  private static void printCorrectUsage() {
    String usage = "Usage:\n" +
            "  For interactive mode: --mode interactive\n" +
            "  For headless mode: --mode headless <commands-file>\n" +
            "  For gui mode: --mode gui\n" +
            "  To check the current calendar in interactive mode: \"check calendar\"\n" +
            "Note: In headless mode, the commands file must end with an 'exit' command.\n";

    View view = new View();
    view.displayMessage(usage);
  }
}
