package eventcalendar.model;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * This is an Abstract class for Events.
 * Contains event id, eventName, eventStartDate, eventEndDate,
 * eventLocation and isPublic attributes.
 */
public abstract class Event {
  private final String eventName;
  private final LocalDateTime eventStartDateTime;
  private final LocalDateTime eventEndDateTime;
  private final String eventDescription;
  private final String eventLocation;
  private final boolean isPublic;

  /**
   * This is the constructor for the Event Class
   * that initializes the class attributes with the parameters
   * sent to it.
   *
   * @param id                 uuid representing the event id.
   * @param eventName          string representing the event name.
   * @param eventStartDateTime representing the start date.
   * @param eventEndDateTime   representing the end date.
   * @param eventDescription   long description (optional param).
   * @param eventLocation      string representing the event location (optional).
   * @param isPublic           boolean denoting the event access.
   */
  public Event(UUID id, String eventName, LocalDateTime eventStartDateTime,
               LocalDateTime eventEndDateTime, String eventDescription,
               String eventLocation, boolean isPublic) throws IllegalArgumentException {

    // validate eventName is passed
    if (eventName.trim().isEmpty()) {
      throw new IllegalArgumentException("Event name cannot be empty");
    }

    // validate eventStartDateTime
    if (eventStartDateTime == null) {
      throw new IllegalArgumentException("Event start date or time cannot be null");
    }

    // validate that if endDate is provided it is not before startDate
    if (eventEndDateTime != null && eventEndDateTime.isBefore(eventStartDateTime)) {
      throw new IllegalArgumentException("Event end date cannot be before event start date");
    }

    // uuid - id has added for future usecases
    this.eventName = eventName;
    this.eventStartDateTime = eventStartDateTime;
    this.eventEndDateTime = eventEndDateTime;
    this.eventDescription = eventDescription;
    this.eventLocation = eventLocation;
    this.isPublic = isPublic;
  }

  /**
   * Return the name of the event.
   *
   * @return the event name as a string
   */
  public String getEventName() {
    return eventName;
  }

  /**
   * Returns the start date and time of the event.
   *
   * @return LocalDateTime representing when the event starts
   */
  public LocalDateTime getEventStartDateTime() {
    return eventStartDateTime;
  }

  /**
   * Returns the end date and time of the event.
   *
   * @return LocalDateTime representing when the event ends
   */
  public LocalDateTime getEventEndDateTime() {
    return eventEndDateTime;
  }

  /**
   * Returns the description of the event.
   *
   * @return A string containing the event description
   */
  public String getEventDescription() {
    return eventDescription;
  }

  /**
   * Returns the location where the event takes place.
   *
   * @return the location of the event as a String
   */
  public String getEventLocation() {
    return eventLocation;
  }

  /**
   * Returns whether the event is public or private.
   *
   * @return true if the event is public, false if private
   */
  public boolean isPublic() {
    return isPublic;
  }
}
