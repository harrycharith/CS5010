package eventcalendar.model;

/**
 * Represents the days of the week using single character representation.
 * M - Monday
 * T - Tuesday
 * W - Wednesday
 * R - Thursday
 * F - Friday
 * S - Saturday
 * U - Sunday
 *
 * <p>This enum provides a compact way to represent days of the week in the event calendar system.
 */
public enum WeekDays {
  M,
  T,
  W,
  R,
  F,
  S,
  U
}
