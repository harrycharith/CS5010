package eventcalendar.model;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Computes analytics metrics for a calendar over a specified date range.
 * Metrics include total events, events by weekday and name, average events per day,
 * busiest and least busy days, and online vs. non-online event percentages.
 */
public class CalendarAnalytics {
  private final ICalendar calendar;

  /**
   * Constructs a CalendarAnalytics instance for the specified calendar.
   *
   * @param calendar the calendar to analyze
   */
  public CalendarAnalytics(ICalendar calendar) {
    this.calendar = calendar;
  }

  /**
   * Generates a dashboard with analytics metrics for the specified date range.
   * Metrics are computed for events between the start and end dates (inclusive).
   *
   * @param startDate the start date of the range (YYYY-MM-DD)
   * @param endDate the end date of the range (YYYY-MM-DD)
   * @return a string containing the formatted dashboard
   */
  public String generateDashboard(LocalDate startDate, LocalDate endDate) {
    // Collect events in the date range
    List<Event> events = new ArrayList<>();
    for (LocalDate date = startDate; !date.isAfter(endDate); date = date.plusDays(1)) {
      events.addAll(calendar.getEventByDate(date));
    }

    StringBuilder dashboard = new StringBuilder();
    dashboard.append(String.format("Analytics Dashboard for %s from %s to %s%n",
            calendar.getName(), startDate, endDate));

    // Total number of events
    int totalEvents = events.size();
    dashboard.append(String.format("Total number of events: %d%n", totalEvents));

    // Events by weekday
    Map<DayOfWeek, Long> eventsByWeekday = events.stream()
            .collect(Collectors.groupingBy(
                    event -> event.getEventStartDateTime().toLocalDate().getDayOfWeek(),
                    Collectors.counting()));
    dashboard.append("Events by weekday:%n");
    for (DayOfWeek day : DayOfWeek.values()) {
      long count = eventsByWeekday.getOrDefault(day, 0L);
      dashboard.append(String.format("  %s: %d%n", day, count));
    }

    // Events by name
    Map<String, Long> eventsByName = events.stream()
            .collect(Collectors.groupingBy(Event::getEventName, Collectors.counting()));
    dashboard.append("Events by name:%n");
    eventsByName.forEach((name, count) ->
            dashboard.append(String.format("  %s: %d%n", name, count)));

    // Average events per day
    long days = startDate.datesUntil(endDate.plusDays(1)).count();
    double avgEventsPerDay = days > 0 ? (double) totalEvents / days : 0.0;
    dashboard.append(String.format("Average events per day: %.2f%n", avgEventsPerDay));

    // Busiest and least busy days
    Map<LocalDate, Long> eventsByDay = new HashMap<>();
    for (LocalDate date = startDate; !date.isAfter(endDate); date = date.plusDays(1)) {
      long count = calendar.getEventByDate(date).size();
      eventsByDay.put(date, count);
    }
    LocalDate busiestDay = null;
    LocalDate leastBusyDay = null;
    long maxEvents = -1;
    long minEvents = Long.MAX_VALUE;
    for (Map.Entry<LocalDate, Long> entry : eventsByDay.entrySet()) {
      long count = entry.getValue();
      LocalDate date = entry.getKey();
      if (count > maxEvents) {
        maxEvents = count;
        busiestDay = date;
      }
      if (count < minEvents) {
        minEvents = count;
        leastBusyDay = date;
      }
    }
    dashboard.append(String.format("Busiest day: %s (%d events)%n",
            busiestDay != null ? busiestDay : "None", maxEvents >= 0 ? maxEvents : 0));
    dashboard.append(String.format("Least busy day: %s (%d events)%n",
            leastBusyDay != null ? leastBusyDay : "None", minEvents != Long.MAX_VALUE ? minEvents : 0));

    // Online vs non-online events
    long onlineEvents = events.stream()
            .filter(event -> event.getEventLocation() != null
                    && "online".equalsIgnoreCase(event.getEventLocation()))
            .count();
    double onlinePercentage = totalEvents > 0 ? (onlineEvents * 100.0 / totalEvents) : 0.0;
    double nonOnlinePercentage = totalEvents > 0 ? ((totalEvents - onlineEvents) * 100.0
            / totalEvents) : 0.0;
    dashboard.append(String.format("Online events: %.2f%%%n", onlinePercentage));
    dashboard.append(String.format("Non-online events: %.2f%%%n", nonOnlinePercentage));

    return dashboard.toString();
  }
}