package eventcalendar.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * Represents a Calendar that contains events and calendar-specific information.
 * This class is implemented using the Builder pattern to create Calendar instances.
 *
 * @see Event
 */
public class Calendar implements ICalendar {
  private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
  private final List<Event> events;
  private String name;
  private ZoneId timeZone;

  /**
   * This constructor initializes the name and timeZone of the instance.
   *
   * @param name     String representing the name of the calendar.
   * @param timeZone ZoneId representing the timeZone of the calendar.
   */
  public Calendar(String name, ZoneId timeZone) {
    this.name = name;
    this.timeZone = timeZone;
    this.events = new ArrayList<>();
  }

  /**
   * Add a single event to the calendar.
   *
   * @param eventBuilder the builder for single event to add
   * @param autoDecline  where to auto-decline if there is a conflict
   * @return true if the event was added, false if declined due to conflict
   */
  @Override
  public boolean addEvent(SingleEvent.Builder eventBuilder, boolean autoDecline) {
    SingleEvent event = eventBuilder.build();
    return addEventInternal(event, autoDecline);
  }

  /**
   * Create and add a single event with specific start and end date/time.
   *
   * @param eventName     The name/title of the event
   * @param startDateTime The start date and time of the event
   * @param endDateTime   The end date and time of the event
   * @param description   Optional description for the event (can be null)
   * @param location      Optional location for the event (can be null)
   * @param isPublic      Whether the event is public
   * @param autoDecline   Whether to auto-decline if there is a conflict
   * @return true if the event was added, false if declined due to conflict
   */
  @Override
  public boolean createEvent(String eventName, LocalDateTime startDateTime,
                             LocalDateTime endDateTime, String description, String location,
                             boolean isPublic, boolean autoDecline) {
    return singleEventBuildWithAll(eventName, startDateTime, endDateTime,
            description, location, isPublic, autoDecline);
  }

  /**
   * Helper method to build and add a single event with all parameters.
   */
  private boolean singleEventBuildWithAll(String eventName, LocalDateTime startDateTime,
                                          LocalDateTime endDateTime, String description,
                                          String location, boolean isPublic,
                                          boolean autoDecline) {
    SingleEvent.Builder builder = createEventBuilder(eventName, startDateTime, endDateTime,
            description, location, isPublic);
    return addEvent(builder, autoDecline);
  }

  /**
   * Helper method to create a SingleEvent.Builder with common parameters.
   */
  private SingleEvent.Builder createEventBuilder(String eventName, LocalDateTime startDateTime,
                                                 LocalDateTime endDateTime, String description,
                                                 String location, boolean isPublic) {
    SingleEvent.Builder builder = new SingleEvent.Builder(eventName, startDateTime)
            .eventEndDateTime(endDateTime);

    if (description != null) {
      builder.eventDescription(description);
    }

    if (location != null) {
      builder.eventLocation(location);
    }

    builder.isPublic(isPublic);

    return builder;
  }

  /**
   * Create and add an all-day event on a specific date.
   *
   * @param eventName   The name/title of the event
   * @param date        The date of the all-day event
   * @param endDate     Optional end date for multi-day events (can be null)
   * @param description Optional description for the event (can be null)
   * @param location    Optional location for the event (can be null)
   * @param isPublic    Whether the event is public
   * @param autoDecline Whether to auto-decline if there is a conflict
   * @return true if the event was added, false if declined due to conflict
   */
  @Override
  public boolean createAllDayEvent(String eventName, LocalDate date, LocalDate endDate,
                                   String description, String location,
                                   boolean isPublic, boolean autoDecline) {
    LocalDateTime startDateTime = date.atStartOfDay();
    LocalDateTime endDateTime;

    if (endDate != null) {
      // this is for when we can have a alDay event which span multiple days
      // i almost confused myself here
      // End time is end of the day on the end date
      endDateTime = endDate.atTime(23, 59, 59);
    } else {
      // Default end time is end of the same day
      endDateTime = date.atTime(23, 59, 59);
    }

    return singleEventBuildWithAll(eventName, startDateTime, endDateTime,
            description, location, isPublic, autoDecline);
  }

  /**
   * Create and add recurring events repeating on specified days until a given end date.
   *
   * @param eventName     The name/title of the event
   * @param startDateTime The start date and time of the first event
   * @param endDateTime   The end date and time of the first event
   * @param repeatDays    List of days on which the event repeats
   * @param repeatUntil   The date until which the event repeats
   * @param description   Optional description for the event (can be null)
   * @param location      Optional location for the event (can be null)
   * @param isPublic      Whether the event is public
   * @param autoDecline   Whether to auto-decline if there is a conflict
   * @return the number of event occurrences successfully created
   */
  @Override
  public int createRecurringEventUntil(String eventName, LocalDateTime startDateTime,
                                       LocalDateTime endDateTime, List<WeekDays> repeatDays,
                                       LocalDateTime repeatUntil, String description,
                                       String location,
                                       boolean isPublic, boolean autoDecline) {
    if (repeatDays == null || repeatDays.isEmpty()) {
      return 0;
    }

    if (repeatUntil.isBefore(startDateTime)) {
      return 0;
    }

    // Calculate the event duration in minutes
    long durationMinutes = java.time.Duration.between(startDateTime, endDateTime).toMinutes();

    // Create individual events for each occurrence
    int successCount = 0;
    LocalDateTime currentDate = startDateTime;

    while (!currentDate.isAfter(repeatUntil)) {
      WeekDays currentDay = convertDayOfWeekToWeekDays(currentDate.getDayOfWeek());

      if (repeatDays.contains(currentDay)) {
        // Create a new single event for this occurrence
        successCount = getSuccessCount(eventName, description, location, isPublic,
                autoDecline, durationMinutes, successCount, currentDate);
      }

      // Move to the next day
      currentDate = currentDate.plusDays(1);
    }

    return successCount;
  }

  private int getSuccessCount(String eventName, String description, String location,
                              boolean isPublic, boolean autoDecline, long durationMinutes,
                              int successCount, LocalDateTime currentDate) {
    LocalDateTime eventEnd = currentDate.plusMinutes(durationMinutes);

    SingleEvent.Builder builder = createEventBuilder(eventName, currentDate, eventEnd,
            description, location, isPublic);

    boolean added = addEvent(builder, autoDecline);
    if (added) {
      successCount++;
    }
    return successCount;
  }

  /**
   * Create and add recurring events repeating on specified days for a given number of occurrences.
   *
   * @param eventName     The name/title of the event
   * @param startDateTime The start date and time of the first event
   * @param endDateTime   The end date and time of the first event
   * @param repeatDays    List of days on which the event repeats
   * @param occurrences   The number of occurrences to create
   * @param description   Optional description for the event (can be null)
   * @param location      Optional location for the event (can be null)
   * @param isPublic      Whether the event is public
   * @param autoDecline   Whether to auto-decline if there is a conflict
   * @return the number of event occurrences successfully created
   */
  @Override
  public int createRecurringEventOccurrences(String eventName, LocalDateTime startDateTime,
                                             LocalDateTime endDateTime, List<WeekDays> repeatDays,
                                             int occurrences, String description, String location,
                                             boolean isPublic, boolean autoDecline) {
    if (repeatDays == null || repeatDays.isEmpty() || occurrences <= 0) {
      return 0;
    }

    // Calculate the event duration in minutes
    long durationMinutes = java.time.Duration.between(startDateTime, endDateTime).toMinutes();

    // Create individual events for each occurrence
    int successCount = 0;
    LocalDateTime currentDate = startDateTime;
    int remainingOccurrences = occurrences;

    while (remainingOccurrences > 0) {
      WeekDays currentDay = convertDayOfWeekToWeekDays(currentDate.getDayOfWeek());

      if (repeatDays.contains(currentDay)) {
        // Create a new single event for this occurrence
        successCount = getSuccessCount(eventName, description, location, isPublic,
                autoDecline, durationMinutes, successCount, currentDate);

        remainingOccurrences--;
      }

      // Move to the next day
      currentDate = currentDate.plusDays(1);
    }

    return successCount;
  }

  /**
   * Converts java.time.DayOfWeek to WeekDays enum
   */
  private WeekDays convertDayOfWeekToWeekDays(java.time.DayOfWeek dayOfWeek) {
    switch (dayOfWeek) {
      case MONDAY:
        return WeekDays.M;
      case TUESDAY:
        return WeekDays.T;
      case WEDNESDAY:
        return WeekDays.W;
      case THURSDAY:
        return WeekDays.R;
      case FRIDAY:
        return WeekDays.F;
      case SATURDAY:
        return WeekDays.S;
      case SUNDAY:
        return WeekDays.U;
      default:
        throw new IllegalArgumentException("Unknown day of week: " + dayOfWeek);
    }
  }

  // internal method to add events to list of event aka calendar.
  private boolean addEventInternal(Event event, boolean autoDecline) {
    if (autoDecline && checkConflict(event)) {
      return false;
    }
    events.add(event);
    return true;
  }

  /**
   * This method checks for conflicts with the events
   * present in the calendar.
   *
   * @param event an event object to check for conflicts.
   * @return a boolean value which is true if conflicts are found and false if not.
   */
  private boolean checkConflict(Event event) {
    LocalDateTime newStart = event.getEventStartDateTime();
    LocalDateTime newEnd = event.getEventEndDateTime();

    // Two intervals [start1, end1] and [start2, end2] overlap if and only if:
    // start1 < end2 AND start2 < end1
    //
    // For calendar events, we consider adjacent events (where one ends exactly when
    // another starts) as non-conflicting
    List<Event> conflictingEvents = events.stream()
            .filter(existingEvent -> {
              LocalDateTime existingStart = existingEvent.getEventStartDateTime();
              LocalDateTime existingEnd = existingEvent.getEventEndDateTime();

              // Check if events are adjacent (one ends exactly when the other starts)
              boolean adjacent = existingEnd.isEqual(newStart) || newEnd.isEqual(existingStart);

              // If they're adjacent, they don't conflict
              if (adjacent) {
                return false;
              }

              // Check for overlap
              return (existingStart.isBefore(newEnd) && newStart.isBefore(existingEnd));
            })
            .collect(Collectors.toList());

    return !conflictingEvents.isEmpty();
  }

  /**
   * Get the list of events in this calendar.
   *
   * @return a list of events
   */
  @Override
  public List<Event> getEvents() {
    return new ArrayList<>(events);
  }

  @Override
  public List<Event> getEventsByName(String eventName) {
    return getEvents().stream()
            .filter(event -> event.getEventName().equals(eventName))
            .collect(Collectors.toList());
  }

  @Override
  public List<Event> getEventByDate(LocalDate date) {
    return getEvents().stream()
            .filter(event -> event.getEventStartDateTime().toLocalDate().equals(date))
            .collect(Collectors.toList());
  }

  /**
   * Removes an event from the calendar.
   *
   * @param event The event to remove
   * @return true if the event was successfully removed, false otherwise
   */
  @Override
  public boolean removeEvent(Event event) {
    return events.remove(event);
  }

  /**
   * This method gets the name of the Calendar.
   *
   * @return Name of the Calendar.
   */
  @Override
  public String getName() {
    return name;
  }

  /**
   * This method sets the name of the Calendar.
   */
  @Override
  public void setName(String name) {
    this.name = name;
  }

  /**
   * This method gets the timeZone of the Calendar.
   *
   * @return timZone of the Calendar.
   */
  @Override
  public ZoneId getTimeZone() {
    return timeZone;
  }

  /**
   * This method sets the timeZone of the Calendar and the contained events.
   */
  @Override
  public void setTimeZone(String timeZone) throws IllegalArgumentException {
    ZoneId oldTimeZone = this.timeZone;
    ZoneId zoneId;
    try {
      // Get the ZoneId from String CalendarTimezone.
      zoneId = ZoneId.of(timeZone);
    } catch (Exception e) {
      throw new IllegalArgumentException("Error: Invalid timezone '" + timeZone +
              "'. Please use IANA Time Zone Database format (area/location).\n" +
              "Examples: America/New_York, Europe/Paris, Asia/Kolkata");
    }
    this.timeZone = zoneId;

    for (Event event : events) {
      LocalDate eventDate = LocalDate.parse(event.getEventStartDateTime().toString(),
              DATE_FORMATTER);

      ModelUtils.changeEventTime(event, this, oldTimeZone,
              this.timeZone, eventDate, eventDate);
    }
  }

  /**
   * Edits a specific property of a single event identified by name, start time, and end time.
   *
   * @param eventName     The name of the event to edit
   * @param startDateTime The start date and time of the event
   * @param endDateTime   The end date and time of the event
   * @param property      The property to edit (name, description, location, or isPublic)
   * @param newValue      The new value for the property
   * @return true if the update was successful, false otherwise
   */
  @Override
  public boolean editSingleEvent(String eventName, LocalDateTime startDateTime,
                                 LocalDateTime endDateTime, String property, String newValue) {
    // Validate property
    if (!isValidProperty(property)) {
      return false;
    }

    // Find the specific event that matches name, start time, and end time
    Event eventToEdit = null;
    for (Event event : events) {
      if (event.getEventName().equals(eventName) &&
              event.getEventStartDateTime().equals(startDateTime) &&
              event.getEventEndDateTime().equals(endDateTime)) {
        eventToEdit = event;
        break;
      }
    }

    if (eventToEdit == null) {
      return false; // Event not found
    }

    // Since events are immutable, we need to remove the old event and add a new one
    return updateEvent(eventToEdit, property, newValue);
  }

  /**
   * Edits a specific property of all events with a given name that start at or after
   * a specified time.
   *
   * @param eventName     The name of the events to edit
   * @param startDateTime The start date and time threshold for events to edit
   * @param property      The property to edit (name, description, location, or isPublic)
   * @param newValue      The new value for the property
   * @return The number of events successfully updated
   */
  @Override
  public int editEventsByNameAndStartTime(String eventName, LocalDateTime startDateTime,
                                          String property, String newValue) {
    // Create a predicate for events that match the name and start at or after the given time
    Predicate<Event> predicate = e -> e.getEventName().equals(eventName) &&
            (e.getEventStartDateTime().equals(startDateTime) ||
                    e.getEventStartDateTime().isAfter(startDateTime));

    return editEventsByPredicate(predicate, property, newValue);
  }

  /**
   * Edits a specific property of all events with a specific name.
   *
   * @param eventName The name of the events to edit
   * @param property  The property to edit (name, description, location, or isPublic)
   * @param newValue  The new value for the property
   * @return The number of events successfully updated
   */
  @Override
  public int editAllEventsByName(String eventName, String property, String newValue) {
    // Create a predicate for events that match the name
    Predicate<Event> predicate = e -> e.getEventName().equals(eventName);

    return editEventsByPredicate(predicate, property, newValue);
  }

  /**
   * Helper method to edit events that match a specific predicate.
   *
   * @param predicate The predicate to filter events
   * @param property  The property to edit
   * @param newValue  The new value for the property
   * @return The number of events successfully updated
   */
  private int editEventsByPredicate(Predicate<Event> predicate, String property, String newValue) {
    // Validate property
    if (!isValidProperty(property)) {
      return 0;
    }

    // Find all events that match the predicate
    List<Event> matchingEvents = events.stream()
            .filter(predicate)
            .collect(Collectors.toList());

    if (matchingEvents.isEmpty()) {
      return 0; // No events found
    }

    // Edit the property of all matching events
    int successCount = 0;
    for (Event event : matchingEvents) {
      boolean success = updateEvent(event, property, newValue);
      if (success) {
        successCount++;
      }
    }

    return successCount;
  }

  /**
   * Updates a single event by creating a new one with the updated
   * property and replacing the old one.
   *
   * @param event    The event to update
   * @param property The property to update
   * @param newValue The new value for the property
   * @return true if the update was successful, false otherwise
   */
  private boolean updateEvent(Event event, String property, String newValue) {
    // Remove the old event
    boolean removed = removeEvent(event);
    if (!removed) {
      return false;
    }

    // Create a new event with the updated property
    SingleEvent.Builder builder = new SingleEvent.Builder(
            property.equals("name") ? newValue : event.getEventName(),
            event.getEventStartDateTime())
            .eventEndDateTime(event.getEventEndDateTime())
            .eventDescription(property.equals("description") ? newValue :
                    event.getEventDescription())
            .eventLocation(property.equals("location") ? newValue : event.getEventLocation());

    if (property.equals("isPublic")) {
      builder.isPublic(Boolean.parseBoolean(newValue));
    } else {
      builder.isPublic(event.isPublic());
    }

    // Add the new event (don't auto-decline since we're updating an existing event slot)
    return addEvent(builder, false);
  }

  /**
   * Checks if the provided property is valid for editing.
   * Based on the Event class properties that can be modified.
   *
   * @param property The property to validate
   * @return true if the property is valid, false otherwise
   */
  private boolean isValidProperty(String property) {
    return "name".equals(property) || "description".equals(property) ||
            "location".equals(property) || "isPublic".equals(property);
  }

  /**
   * Builder class for creating Calendar instances.
   * This class implements the Builder pattern to construct Calendar objects step by step.
   * The Builder maintains a mutable state of a calendar under construction,
   * allowing for optional setting of calendar properties before building.
   */
  public static class Builder {
    private String name = "My Calendar";
    private ZoneId timeZone = ZoneId.of(ZoneId.SHORT_IDS.get("EST"));

    /**
     * Sets the name of the calendar.
     *
     * @param name The name to be set for the calendar
     * @return The Builder instance for method chaining
     */
    public Builder name(String name) {
      this.name = name;
      return this;
    }

    /**
     * Sets the timeZone of the calendar.
     *
     * @param timeZone The timeZone to be set for the calendar
     * @return The Builder instance for method chaining
     */
    public Builder timeZone(String timeZone) throws IllegalArgumentException {
      ZoneId zoneId;
      try {
        // Get the ZoneId from String CalendarTimezone.
        zoneId = ZoneId.of(timeZone);
      } catch (Exception e) {
        throw new IllegalArgumentException("Error: Invalid timezone '" + timeZone +
                "'. Please use IANA Time Zone Database format (area/location).\n" +
                "Examples: America/New_York, Europe/Paris, Asia/Kolkata");
      }
      this.timeZone = zoneId;
      return this;
    }

    /**
     * Builds and returns a new Calendar instance with the current builder's properties.
     *
     * @return a new Calendar object
     */
    public Calendar build() {
      return new Calendar(name, timeZone);
    }
  }
}
