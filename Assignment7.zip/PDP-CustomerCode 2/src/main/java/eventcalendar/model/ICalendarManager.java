package eventcalendar.model;

import java.util.List;

/**
 * Interface for managing multiple calendars.
 */
public interface ICalendarManager {
  /**
   * Add a calendar to the manager.
   *
   * @param calendarBuilder The builder for the calendar to add
   * @return true if the calendar was added successfully
   */
  boolean addCalendar(Calendar.Builder calendarBuilder);

  /**
   * Check if a calendar with the given name exists.
   *
   * @param name The name to check
   * @return true if a calendar with this name exists
   */
  boolean hasCalendarName(String name);

  /**
   * Get a calendar by name.
   *
   * @param name The name of the calendar to get
   * @return The calendar, or null if no calendar with the given name exists
   */
  ICalendar getCalendar(String name);

  /**
   * Update the name of a calendar.
   *
   * @param oldName The current name of the calendar
   * @param newName The new name for the calendar
   * @return true if the calendar was successfully updated
   */
  boolean updateCalendarName(String oldName, String newName);

  List<ICalendar> getCalendars();
}