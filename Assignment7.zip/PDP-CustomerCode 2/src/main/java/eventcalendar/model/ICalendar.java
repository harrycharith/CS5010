package eventcalendar.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;

/**
 * Interface representing a Calendar that contains events and calendar-specific information.
 */
public interface ICalendar {
  /**
   * Add a single event to the calendar.
   *
   * @param eventBuilder the builder for single event to add
   * @param autoDecline  whether to auto-decline if there is a conflict
   * @return true if the event was added, false if declined due to conflict
   */
  boolean addEvent(SingleEvent.Builder eventBuilder, boolean autoDecline);

  /**
   * Create and add a single event with specific start and end date/time.
   *
   * @param eventName     The name/title of the event
   * @param startDateTime The start date and time of the event
   * @param endDateTime   The end date and time of the event
   * @param description   Optional description for the event (can be null)
   * @param location      Optional location for the event (can be null)
   * @param isPublic      Whether the event is public
   * @param autoDecline   Whether to auto-decline if there is a conflict
   * @return true if the event was added, false if declined due to conflict
   */
  boolean createEvent(String eventName, LocalDateTime startDateTime, LocalDateTime endDateTime,
                      String description, String location, boolean isPublic, boolean autoDecline);

  /**
   * Create and add an all-day event on a specific date.
   *
   * @param eventName   The name/title of the event
   * @param date        The date of the all-day event
   * @param endDate     Optional end date for multi-day events (can be null)
   * @param description Optional description for the event (can be null)
   * @param location    Optional location for the event (can be null)
   * @param isPublic    Whether the event is public
   * @param autoDecline Whether to auto-decline if there is a conflict
   * @return true if the event was added, false if declined due to conflict
   */
  boolean createAllDayEvent(String eventName, LocalDate date, LocalDate endDate,
                            String description, String location, boolean isPublic,
                            boolean autoDecline);

  /**
   * Create and add recurring events repeating on specified days until a given end date.
   *
   * @param eventName     The name/title of the event
   * @param startDateTime The start date and time of the first event
   * @param endDateTime   The end date and time of the first event
   * @param repeatDays    List of days on which the event repeats
   * @param repeatUntil   The date until which the event repeats
   * @param description   Optional description for the event (can be null)
   * @param location      Optional location for the event (can be null)
   * @param isPublic      Whether the event is public
   * @param autoDecline   Whether to auto-decline if there is a conflict
   * @return the number of event occurrences successfully created
   */
  int createRecurringEventUntil(String eventName, LocalDateTime startDateTime,
                                LocalDateTime endDateTime, List<WeekDays> repeatDays,
                                LocalDateTime repeatUntil,
                                String description, String location, boolean isPublic,
                                boolean autoDecline);

  /**
   * Create and add recurring events repeating on specified days for a given number of occurrences.
   *
   * @param eventName     The name/title of the event
   * @param startDateTime The start date and time of the first event
   * @param endDateTime   The end date and time of the first event
   * @param repeatDays    List of days on which the event repeats
   * @param occurrences   The number of occurrences to create
   * @param description   Optional description for the event (can be null)
   * @param location      Optional location for the event (can be null)
   * @param isPublic      Whether the event is public
   * @param autoDecline   Whether to auto-decline if there is a conflict
   * @return the number of event occurrences successfully created
   */
  int createRecurringEventOccurrences(String eventName, LocalDateTime startDateTime,
                                      LocalDateTime endDateTime,
                                      List<WeekDays> repeatDays, int occurrences,
                                      String description, String location, boolean isPublic,
                                      boolean autoDecline);

  /**
   * Edits a specific property of a single event identified by name, start time, and end time.
   *
   * @param eventName     The name of the event to edit
   * @param startDateTime The start date and time of the event
   * @param endDateTime   The end date and time of the event
   * @param property      The property to edit (name, description, location, or isPublic)
   * @param newValue      The new value for the property
   * @return true if the update was successful, false otherwise
   */
  boolean editSingleEvent(String eventName, LocalDateTime startDateTime,
                          LocalDateTime endDateTime, String property, String newValue);

  /**
   * Edits a specific property of all events with a given name that start at or after
   * a specified time.
   *
   * @param eventName     The name of the events to edit
   * @param startDateTime The start date and time of the events (or after)
   * @param property      The property to edit (name, description, location, or isPublic)
   * @param newValue      The new value for the property
   * @return The number of events successfully updated
   */
  int editEventsByNameAndStartTime(String eventName, LocalDateTime startDateTime,
                                   String property, String newValue);

  /**
   * Edits a specific property of all events with a specific name.
   *
   * @param eventName The name of the events to edit
   * @param property  The property to edit (name, description, location, or isPublic)
   * @param newValue  The new value for the property
   * @return The number of events successfully updated
   */
  int editAllEventsByName(String eventName, String property, String newValue);

  /**
   * Get the list of events in this calendar.
   *
   * @return a list of events
   */
  List<Event> getEvents();

  List<Event> getEventsByName(String eventName);

  List<Event> getEventByDate(LocalDate date);

  /**
   * Removes an event from the calendar.
   *
   * @param event The event to remove
   * @return true if the event was successfully removed, false otherwise
   */
  boolean removeEvent(Event event);

  /**
   * Gets the name of the Calendar.
   */
  String getName();

  /**
   * Sets the name of the Calendar.
   */
  void setName(String name);

  /**
   * Gets the timeZone of the Calendar.
   */
  ZoneId getTimeZone();

  /**
   * Sets the timeZone of the Calendar.
   */
  void setTimeZone(String timeZone) throws IllegalArgumentException;
}