package eventcalendar.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Default implementation of ICalendarManager.
 * This has a list of calendars to store, retrieve, edit and delete them.
 */
public class CalendarManager implements ICalendarManager {
  private final Map<String, ICalendar> calendars;

  /**
   * This is a constructor for the CalendarManger Class.
   */
  public CalendarManager() {
    this.calendars = new HashMap<>();
  }

  @Override
  public boolean addCalendar(Calendar.Builder calendarBuilder) {
    ICalendar calendar = calendarBuilder.build();
    if (calendars.containsKey(calendar.getName())) {
      return false;
    }
    calendars.put(calendar.getName(), calendar);
    return true;
  }

  @Override
  public boolean hasCalendarName(String name) {
    return calendars.containsKey(name);
  }

  @Override
  public ICalendar getCalendar(String name) {
    return calendars.get(name);
  }

  /**
   * Removes a calendar from the manager by its name.
   *
   * @param name The name of the calendar to remove
   * @return The removed calendar, or null if no calendar with the given name exists
   */
  private ICalendar removeCalendar(String name) {
    return calendars.remove(name);
  }

  @Override
  public boolean updateCalendarName(String oldName, String newName) {
    // Check if a calendar with the new name already exists
    if (hasCalendarName(newName)) {
      return false;
    }
    // Get the calendar with the old name
    ICalendar calendar = getCalendar(oldName);
    if (calendar == null) {
      return false;
    }
    // Remove the calendar with the old name
    removeCalendar(oldName);
    // Update the name in the calendar object
    calendar.setName(newName);
    // Put the calendar back with the new name as the key
    calendars.put(newName, calendar);
    return true;
  }

  @Override
  public List<ICalendar> getCalendars() {
    return new ArrayList<>(calendars.values());
  }
}