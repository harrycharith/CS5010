package eventcalendar.model;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Represents a singleEvent in a calendar.
 * This class is implemented using the Builder pattern to create singleEvent instances.
 *
 * @see Event
 */
public class SingleEvent extends Event {
  /**
   * This is the constructor for the Event Class
   * that initializes the class attributes with the parameters
   * sent to it.
   *
   * @param id                 uuid representing the event id.
   * @param eventName          string representing the event name.
   * @param eventStartDateTime representing the start date.
   * @param eventEndDateTime   representing the end date.
   * @param eventDescription   long description (optional param).
   * @param eventLocation      string representing the event location (optional).
   * @param isPublic           boolean denoting the event access.
   */
  private SingleEvent(UUID id, String eventName, LocalDateTime eventStartDateTime,
                      LocalDateTime eventEndDateTime, String eventDescription,
                      String eventLocation, boolean isPublic) {
    super(id, eventName, eventStartDateTime, eventEndDateTime,
            eventDescription, eventLocation, isPublic);
  }

  /**
   * Builder class for creating SingleEvent objects using the Builder pattern.
   * Provides a fluent interface for constructing SingleEvent instances with optional parameters.
   */
  public static class Builder {
    // needed params
    private final UUID id = UUID.randomUUID();
    private final String eventName;
    private final LocalDateTime eventStartDateTime;
    // optional params
    private LocalDateTime eventEndDateTime = null;
    private String eventDescription = "";
    private String eventLocation = "";
    private boolean isPublic = true;

    /**
     * Constructor for Builder that requires the mandatory parameters.
     *
     * @param eventName          The name of the event (required)
     * @param eventStartDateTime The start date and time of the event (required)
     */
    public Builder(String eventName, LocalDateTime eventStartDateTime) {
      this.eventName = eventName;
      this.eventStartDateTime = eventStartDateTime;
    }

    /**
     * Sets the end date and time for the event.
     *
     * @param eventEndDateTime The end date and time of the event
     * @return The Builder instance for method chaining
     */
    public Builder eventEndDateTime(LocalDateTime eventEndDateTime) {
      this.eventEndDateTime = eventEndDateTime;
      return this;
    }

    /**
     * Sets the description for the event.
     *
     * @param eventDescription The description of the event
     * @return The Builder instance for method chaining
     */
    public Builder eventDescription(String eventDescription) {
      this.eventDescription = eventDescription;
      return this;
    }

    /**
     * Sets the location for the event.
     *
     * @param eventLocation The location where the event will take place
     * @return The Builder instance for method chaining
     */
    public Builder eventLocation(String eventLocation) {
      this.eventLocation = eventLocation;
      return this;
    }

    /**
     * Sets the visibility of the event.
     *
     * @param isPublic True if the event is public, false if private
     * @return The Builder instance for method chaining
     */
    public Builder isPublic(boolean isPublic) {
      this.isPublic = isPublic;
      return this;
    }

    /**
     * Builds and returns a new SingleEvent instance with the configured parameters.
     *
     * @return A new SingleEvent instance
     */
    public SingleEvent build() {
      return new SingleEvent(id, eventName, eventStartDateTime, eventEndDateTime,
              eventDescription, eventLocation, isPublic);
    }
  }
}
