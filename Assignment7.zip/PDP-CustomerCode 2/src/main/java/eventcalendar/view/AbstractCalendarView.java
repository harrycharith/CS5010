package eventcalendar.view;

import java.time.LocalDate;

import javax.swing.JPanel;

import eventcalendar.model.ICalendar;
import eventcalendar.model.ICalendarManager;

/**
 * An abstract base class for calendar view components that extends JPanel.
 */
public abstract class AbstractCalendarView extends JPanel {
  protected final ICalendar calendarModel;
  protected final ICalendarManager calendarManager;
  protected LocalDate currentDate;

  /**
   * Constructs an abstract calendar view with the specified calendar model and manager.
   */
  public AbstractCalendarView(ICalendar calendarModel, ICalendarManager calendarManager) {
    this.calendarModel = calendarModel;
    this.calendarManager = calendarManager;
    this.currentDate = LocalDate.now();
    initializeUI();
  }

  /**
   * Initializes the user interface components and layouts for the calendar view.
   */
  protected abstract void initializeUI();

  /**
   * Sets the current date for the calendar view and updates the display.
   */
  public void setDate(LocalDate date) {
    this.currentDate = date;
    updateView();
  }

  /**
   * Updates the visual representation of the calendar view.
   */
  protected abstract void updateView();
}
