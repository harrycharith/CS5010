package eventcalendar.view.dialogs;

import java.awt.Component;
import java.awt.GridLayout;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;

import eventcalendar.controller.commands.CreateEventCommand;
import eventcalendar.controller.commands.EditEventCommand;
import eventcalendar.model.Event;
import eventcalendar.model.ICalendar;

/**
 * Manages Event windows for calendar-related operations in the application.
 */
public class EventDialogManager {

  private final Component parentComponent;
  private final ICalendar calendarModel;

  /**
   * Constructor for EventDialogManager.
   */
  public EventDialogManager(Component parentComponent, ICalendar calendarModel) {
    this.parentComponent = parentComponent;
    this.calendarModel = calendarModel;
  }

  /**
   * Show dialog for adding a new event on a specific date.
   *
   * @param date The date to add the event to
   */
  public void showAddEventDialog(LocalDate date) {
    JPanel panel = new JPanel(new GridLayout(0, 1));

    JTextField nameField = new JTextField(20);
    JTextField startTimeField = new JTextField(20);
    JTextField endTimeField = new JTextField(20);

    panel.add(new JLabel("Event Name:"));
    panel.add(nameField);
    panel.add(new JLabel("Start Time (HH:mm):"));
    panel.add(startTimeField);
    panel.add(new JLabel("End Time (HH:mm):"));
    panel.add(endTimeField);

    int result = JOptionPane.showConfirmDialog(
            parentComponent, panel, "Create New Event",
            JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

    if (result == JOptionPane.OK_OPTION) {
      String name = nameField.getText().trim();
      String startInput = startTimeField.getText().trim();
      String endInput = endTimeField.getText().trim();

      if (name.isEmpty() || startInput.isEmpty() || endInput.isEmpty()) {
        JOptionPane.showMessageDialog(parentComponent,
                "Event name, start time, and end time are required.",
                "Invalid Input", JOptionPane.ERROR_MESSAGE);
        return;
      }

      try {
        LocalTime startTime = LocalTime.parse(startInput);
        LocalTime endTime = LocalTime.parse(endInput);

        String startDateTime = date.atTime(startTime).toString();
        String endDateTime = date.atTime(endTime).toString();

        // Create event
        CreateEventCommand command = new CreateEventCommand(calendarModel);
        Map<String, String> args = new HashMap<>();
        args.put("eventName", name);
        args.put("startTime", startDateTime);
        args.put("endTime", endDateTime);
        args.put("autoDecline", "True");

        String response = command.execute(args);
        JOptionPane.showMessageDialog(parentComponent, response);

      } catch (DateTimeParseException e) {
        JOptionPane.showMessageDialog(parentComponent,
                "Please enter time in HH:mm format (e.g. 14:30; 24hrs format.)",
                "Invalid Time Format", JOptionPane.ERROR_MESSAGE);
      }
    }
  }

  /**
   * Show dialog for editing an existing event.
   *
   * @param event   The event to edit
   * @param editAll Whether to edit all occurrences of a recurring event
   */
  public void showEditEventForm(Event event, boolean editAll) {
    String[] editableProps = {"name", "description", "location", "isPublic"};
    JComboBox<String> propertyComboBox = new JComboBox<>(editableProps);

    JTextField valueField = new JTextField();
    JCheckBox publicCheckBox = new JCheckBox("Public Event");

    JPanel panel = new JPanel(new GridLayout(0, 1));
    panel.add(new JLabel("Select property to edit:"));
    panel.add(propertyComboBox);
    panel.add(new JLabel("New value:"));
    panel.add(valueField);
    panel.add(publicCheckBox);

    // Toggle field visibility based on selected property
    // Only for isPublic
    propertyComboBox.addActionListener(e -> {
      String selected = (String) propertyComboBox.getSelectedItem();
      if ("isPublic".equals(selected)) {
        valueField.setEnabled(false);
        publicCheckBox.setEnabled(true);
      } else {
        valueField.setEnabled(true);
        publicCheckBox.setEnabled(false);
      }
    });

    // Set default states
    valueField.setEnabled(true);
    publicCheckBox.setEnabled(false);

    int result = JOptionPane.showConfirmDialog(
            parentComponent, panel, editAll ? "Edit All Matching Events" : "Edit This Event",
            JOptionPane.OK_CANCEL_OPTION);

    if (result == JOptionPane.OK_OPTION) {
      String property = (String) propertyComboBox.getSelectedItem();
      String newValue;

      if ("isPublic".equals(property)) {
        newValue = publicCheckBox.isSelected() ? "true" : "false";
      } else {
        newValue = valueField.getText().trim();
        if (newValue.isEmpty()) {
          JOptionPane.showMessageDialog(parentComponent, "New value cannot be empty.",
                  "Invalid Input", JOptionPane.ERROR_MESSAGE);
          return;
        }
      }

      EditEventCommand command = new EditEventCommand(calendarModel);
      Map<String, String> args = new HashMap<>();
      // Depending on user input, use event/events
      args.put("object", editAll ? "events" : "event");
      args.put("eventName", event.getEventName());
      args.put("property", property);
      args.put("newValue", newValue);

      if (!editAll) {
        args.put("startTime", event.getEventStartDateTime().toString());
        args.put("endTime", event.getEventEndDateTime().toString());
      }

      String response = command.execute(args);
      JOptionPane.showMessageDialog(parentComponent, response);
    }
  }

  /**
   * Show dialog for creating a recurring event.
   *
   * @param date The start date for the recurring event
   */
  public void showRecurringEventDialog(LocalDate date) {
    JPanel panel = new JPanel(new GridLayout(0, 1, 5, 5));

    JTextField nameField = new JTextField(20);
    JTextField startTimeField = new JTextField(20);
    JTextField endTimeField = new JTextField(20);
    JTextField frequencyField = new JTextField(20);

    // Options for "end"
    JRadioButton countRadio = new JRadioButton("Repeat for N times");
    JRadioButton untilRadio = new JRadioButton("Repeat until date " +
            "(YYYY-MM-DD or YYYY-MM-DDTHH:MM)");
    ButtonGroup group = new ButtonGroup();
    group.add(countRadio);
    group.add(untilRadio);

    JTextField countField = new JTextField(10);
    JTextField untilField = new JTextField(20);
    countField.setEnabled(false);
    untilField.setEnabled(false);

    // Add listeners to enable/disable fields
    countRadio.addActionListener(e -> {
      countField.setEnabled(true);
      untilField.setEnabled(false);
    });

    untilRadio.addActionListener(e -> {
      untilField.setEnabled(true);
      countField.setEnabled(false);
    });

    // Preselect one
    countRadio.setSelected(true);
    countField.setEnabled(true);

    // Add UI components
    panel.add(new JLabel("Event Name:"));
    panel.add(nameField);
    panel.add(new JLabel("Start Time (HH:mm):"));
    panel.add(startTimeField);
    panel.add(new JLabel("End Time (HH:mm):"));
    panel.add(endTimeField);
    panel.add(new JLabel("Repeat on Days (e.g., MTWRFSU):"));
    panel.add(frequencyField);

    panel.add(countRadio);
    panel.add(countField);
    panel.add(untilRadio);
    panel.add(untilField);

    int result = JOptionPane.showConfirmDialog(
            parentComponent, panel, "Create Recurring Event",
            JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

    if (result == JOptionPane.OK_OPTION) {
      String name = nameField.getText().trim();
      String start = startTimeField.getText().trim();
      String end = endTimeField.getText().trim();
      String days = frequencyField.getText().trim();
      boolean isCount = countRadio.isSelected();

      if (name.isEmpty() || start.isEmpty() || days.isEmpty()) {
        JOptionPane.showMessageDialog(parentComponent, "Please fill out name, " +
                        "start time, and repeat days.",
                "Invalid Input", JOptionPane.ERROR_MESSAGE);
        return;
      }

      Map<String, String> args = new HashMap<>();
      args.put("eventName", name);
      args.put("repeatDays", days);

      try {
        LocalTime startTime = LocalTime.parse(start);
        LocalTime endTime = LocalTime.parse(end);

        String startDateTime = date.atTime(startTime).toString();
        String endDateTime = date.atTime(endTime).toString();

        args.put("startTime", startDateTime);
        args.put("endTime", endDateTime);
        args.put("autoDecline", "True");

      } catch (DateTimeParseException ex) {
        JOptionPane.showMessageDialog(parentComponent,
                "Please enter time in HH:mm format (e.g. 09:30)",
                "Invalid Time Format", JOptionPane.ERROR_MESSAGE);
        return;
      }

      if (isCount) {
        String countStr = countField.getText().trim();
        if (countStr.isEmpty()) {
          JOptionPane.showMessageDialog(parentComponent, "Please specify " +
                          "number of repetitions.",
                  "Invalid Input", JOptionPane.ERROR_MESSAGE);
          return;
        }
        args.put("repeatTimes", countStr);
      } else {
        String untilStr = untilField.getText().trim();
        if (untilStr.isEmpty()) {
          JOptionPane.showMessageDialog(parentComponent, "Please specify an end date.",
                  "Invalid Input", JOptionPane.ERROR_MESSAGE);
          return;
        }
        args.put("repeatUntil", untilStr);
      }

      CreateEventCommand command = new CreateEventCommand(calendarModel);
      String response = command.execute(args);
      JOptionPane.showMessageDialog(parentComponent, response);
    }
  }

  /**
   * Ask user whether to edit a single occurrence or all occurrences of a recurring event.
   *
   * @param event The event to edit
   */
  public void askEditScope(Event event) {
    JRadioButton singleEdit = new JRadioButton("Edit only this event");
    JRadioButton allEdit = new JRadioButton("Edit all events with this name");
    ButtonGroup group = new ButtonGroup();
    group.add(singleEdit);
    group.add(allEdit);

    singleEdit.setSelected(true);

    JPanel panel = new JPanel(new GridLayout(0, 1));
    panel.add(new JLabel("How would you like to edit the event?"));
    panel.add(singleEdit);
    panel.add(allEdit);

    int result = JOptionPane.showConfirmDialog(parentComponent, panel, "Edit Scope",
            JOptionPane.OK_CANCEL_OPTION);

    if (result == JOptionPane.OK_OPTION) {
      showEditEventForm(event, !singleEdit.isSelected());
    }
  }

}
