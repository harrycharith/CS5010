package eventcalendar.view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import eventcalendar.model.CalendarAnalytics;
import eventcalendar.model.ICalendar;

/**
 * Displays a GUI dialog for viewing calendar analytics metrics.
 * Allows users to input a date range and view the resulting dashboard.
 */
public class AnalyticsDashboardView extends JDialog {
  private final ICalendar calendar;
  private final JTextArea dashboardArea;
  private final JTextField startDateField;
  private final JTextField endDateField;
  private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

  /**
   * Constructs an AnalyticsDashboardView dialog for the specified calendar.
   *
   * @param parent the parent JFrame
   * @param calendar the calendar to analyze
   */
  public AnalyticsDashboardView(JFrame parent, ICalendar calendar) {
    super(parent, "Analytics Dashboard - " + calendar.getName(), true);
    this.calendar = calendar;
    this.dashboardArea = new JTextArea(20, 50);
    this.startDateField = new JTextField(10);
    this.endDateField = new JTextField(10);

    initializeUI();
    setSize(600, 400);
    setLocationRelativeTo(parent);
  }

  /**
   * Initializes the UI components and layout of the dialog.
   */
  private void initializeUI() {
    setLayout(new BorderLayout(10, 10));

    // Input panel for date range
    JPanel inputPanel = new JPanel(new GridLayout(2, 2, 5, 5));
    inputPanel.add(new JLabel("Start Date (YYYY-MM-DD):"));
    inputPanel.add(startDateField);
    inputPanel.add(new JLabel("End Date (YYYY-MM-DD):"));
    inputPanel.add(endDateField);

    // Button to generate dashboard
    JButton generateButton = new JButton("Generate Dashboard");
    generateButton.addActionListener(e -> generateDashboard());

    // Dashboard display area
    dashboardArea.setEditable(false);
    dashboardArea.setLineWrap(true);
    dashboardArea.setWrapStyleWord(true);

    // Layout
    JPanel topPanel = new JPanel(new BorderLayout());
    topPanel.add(inputPanel, BorderLayout.CENTER);
    topPanel.add(generateButton, BorderLayout.SOUTH);

    add(topPanel, BorderLayout.NORTH);
    add(dashboardArea, BorderLayout.CENTER);
  }

  /**
   * Generates and displays the analytics dashboard based on user input.
   * Validates the date inputs and updates the dashboard area with the results or an error message.
   */
  private void generateDashboard() {
    try {
      LocalDate startDate = LocalDate.parse(startDateField.getText(), DATE_FORMATTER);
      LocalDate endDate = LocalDate.parse(endDateField.getText(), DATE_FORMATTER);
      if (endDate.isBefore(startDate)) {
        dashboardArea.setText("Error: End date cannot be before start date.");
        return;
      }
      CalendarAnalytics analytics = new CalendarAnalytics(calendar);
      String dashboard = analytics.generateDashboard(startDate, endDate);
      dashboardArea.setText(dashboard);
    } catch (DateTimeParseException e) {
      dashboardArea.setText("Error: Invalid date format. Use YYYY-MM-DD.");
    } catch (Exception e) {
      dashboardArea.setText("Error generating dashboard: " + e.getMessage());
    }
  }
}