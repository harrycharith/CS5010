package eventcalendar;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Path;

import eventcalendar.view.View;

import static org.junit.Assert.assertEquals;

/**
 * Test class for Main.
 */
public class MainTest {
  String message;
  View view;
  ByteArrayOutputStream outContent;
  PrintStream originalOut;

  @Before
  public void setup() {
    view = new View();
    outContent = new ByteArrayOutputStream();
    originalOut = System.out;
    System.setOut(new PrintStream(outContent));
  }

  @After
  public void restoreStreams() {
    System.setOut(originalOut);
  }

  @Test
  public void testInteractiveMode() throws IOException {
    String userInput = "create event --autoDecline test event " +
            "from 2025-03-15T10:00 to 2025-03-15T11:00\nexit\n";
    System.setIn(new ByteArrayInputStream(userInput.getBytes()));

    String[] args = {"--mode", "interactive"};
    Main.main(args);

    String expectedOutput = "Calendar - Interactive Mode" + System.lineSeparator() +
            "Type 'exit' to quit the application" + System.lineSeparator() +
            "\"My Calendar\" Calender is being used" + System.lineSeparator() +
            "Enter command:" + System.lineSeparator() +
            "> Event created successfully: test event" + System.lineSeparator() +
            "> Exit command entered, closing the application" + System.lineSeparator();

    assertEquals(expectedOutput, outContent.toString());
  }

  @Test
  public void testHeadlessMode() throws IOException {
    Path tempFile = Files.createTempFile("commands", ".txt");
    try (FileWriter writer = new FileWriter(tempFile.toFile())) {
      writer.write("create event --autoDecline test event " +
              "from 2025-03-15T10:00 to 2025-03-15T11:00\nexit\n");
    }

    String[] args = {"--mode", "headless", tempFile.toString()};
    Main.main(args);

    String expectedOutput = "Calendar - Headless Mode" + System.lineSeparator() +
            "Executing commands from file: " + tempFile + System.lineSeparator() +
            "Executing: create event --autoDecline test event from " +
            "2025-03-15T10:00 to 2025-03-15T11:00" + System.lineSeparator() +
            "Event created successfully: test event" + System.lineSeparator() +
            "Executing: exit" + System.lineSeparator() +
            "Exit command found. Remaining commands not executed. \n" +
            "Sayo-Nara!" + System.lineSeparator();

    assertEquals(expectedOutput.trim(), outContent.toString().trim());

    Files.deleteIfExists(tempFile);
  }

  @Test
  public void testIncorrectArgs1() throws IOException {
    String[] args = {"interactive"};
    Main.main(args);

    String expectedOutput = "Usage:\n" +
            "  For interactive mode: --mode interactive\n" +
            "  For headless mode: --mode headless <commands-file>\n" +
            "  For gui mode: --mode gui\n" +
            "  To check the current calendar in interactive mode: \"check calendar\"\n" +
            "Note: In headless mode, the commands file must end with an 'exit' command.\n" +
            System.lineSeparator();

    assertEquals(expectedOutput, outContent.toString());
  }

  @Test
  public void testIncorrectArgs2() throws IOException {
    String[] args = {"--mode"};
    Main.main(args);

    String expectedOutput = "Usage:\n" +
            "  For interactive mode: --mode interactive\n" +
            "  For headless mode: --mode headless <commands-file>\n" +
            "  For gui mode: --mode gui\n" +
            "  To check the current calendar in interactive mode: \"check calendar\"\n" +
            "Note: In headless mode, the commands file must end with an 'exit' command.\n" +
            System.lineSeparator();

    assertEquals(expectedOutput, outContent.toString());
  }

  @Test
  public void testIncorrectArgs3() throws IOException {
    String[] args = {"--mode", "incorrect argument"};
    Main.main(args);

    String expectedOutput = "Usage:\n" +
            "  For interactive mode: --mode interactive\n" +
            "  For headless mode: --mode headless <commands-file>\n" +
            "  For gui mode: --mode gui\n" +
            "  To check the current calendar in interactive mode: \"check calendar\"\n" +
            "Note: In headless mode, the commands file must end with an 'exit' command.\n" +
            System.lineSeparator();

    assertEquals(expectedOutput, outContent.toString());
  }

  @Test(expected = IOException.class)
  public void testHeadlessModeNoFile() throws IOException {
    String[] args = {"--mode", "headless", ""};
    Main.main(args);
  }

  @Test(expected = IOException.class)
  public void testInteractiveModeException() throws IOException {
    String[] args = {"--mode", "interactive"};
    Main.main(args);
  }

  @Test
  public void testHeadlessModeFileWithAnEmptyLine() throws IOException {
    Path tempFile = Files.createTempFile("commands", ".txt");
    try (FileWriter writer = new FileWriter(tempFile.toFile())) {
      writer.write("create event --autoDecline test event from " +
              "2025-03-15T10:00 to 2025-03-15T11:00\n\nexit\n");
    }

    String[] args = {"--mode", "headless", tempFile.toString()};
    Main.main(args);

    String expectedOutput = "Calendar - Headless Mode" + System.lineSeparator() +
            "Executing commands from file: " + tempFile + System.lineSeparator() +
            "Executing: create event --autoDecline test event from " +
            "2025-03-15T10:00 to 2025-03-15T11:00" + System.lineSeparator() +
            "Event created successfully: test event" + System.lineSeparator() +
            "Executing: exit" + System.lineSeparator() +
            "Exit command found. Remaining commands not executed. \n" +
            "Sayo-Nara!" + System.lineSeparator();

    assertEquals(expectedOutput.trim(), outContent.toString().trim());

    Files.deleteIfExists(tempFile);
  }

  @Test
  public void testHeadlessModeFileWithNoExit() throws IOException {
    Path tempFile = Files.createTempFile("commands", ".txt");
    try (FileWriter writer = new FileWriter(tempFile.toFile())) {
      writer.write("create event --autoDecline test event from " +
              "2025-03-15T10:00 to 2025-03-15T11:00\n");
    }

    String[] args = {"--mode", "headless", tempFile.toString()};
    Main.main(args);

    String expectedOutput = "Calendar - Headless Mode" + System.lineSeparator() +
            "Executing commands from file: " + tempFile + System.lineSeparator() +
            "Executing: create event --autoDecline test event from " +
            "2025-03-15T10:00 to 2025-03-15T11:00" + System.lineSeparator() +
            "Event created successfully: test event" + System.lineSeparator() +
            "Error: The last command in the file must be 'exit'" + System.lineSeparator();

    assertEquals(expectedOutput.trim(), outContent.toString().trim());

    Files.deleteIfExists(tempFile);
  }

  @Test
  public void testCheckCalendarCommand() throws IOException {
    String userInput = "check calendar\nCheck Calendar\nexit\n";
    System.setIn(new ByteArrayInputStream(userInput.getBytes()));

    String[] args = {"--mode", "interactive"};
    Main.main(args);

    String expectedOutput = "Calendar - Interactive Mode" + System.lineSeparator() +
            "Type 'exit' to quit the application" + System.lineSeparator() +
            "\"My Calendar\" Calender is being used" + System.lineSeparator() +
            "Enter command:" + System.lineSeparator() +
            "> My Calendar is being used." + System.lineSeparator() +
            "> My Calendar is being used." + System.lineSeparator() +
            "> Exit command entered, closing the application" + System.lineSeparator();

    assertEquals(expectedOutput, outContent.toString());
  }

  @Test
  public void testUseCalendarCommand() throws IOException {
    String userInput = "use calendar --name My Calendar\nexit\n";
    System.setIn(new ByteArrayInputStream(userInput.getBytes()));

    String[] args = {"--mode", "interactive"};
    Main.main(args);

    String expectedOutput = "Calendar - Interactive Mode" + System.lineSeparator() +
            "Type 'exit' to quit the application" + System.lineSeparator() +
            "\"My Calendar\" Calender is being used" + System.lineSeparator() +
            "Enter command:" + System.lineSeparator() +
            "> Now using calendar: \"My Calendar\"" + System.lineSeparator() +
            "> Exit command entered, closing the application" + System.lineSeparator();

    assertEquals(expectedOutput, outContent.toString());
  }

  @Test
  public void testGUIMode() throws IOException {
    String[] args = {};
    Main.main(args);

    String expectedOutput = "Running GUI mode." + System.lineSeparator();

    assertEquals(expectedOutput, outContent.toString());
  }

}