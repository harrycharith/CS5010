package eventcalendar.view;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.Assert.assertEquals;

/**
 * Test class for View.
 */
public class ViewTest {
  String message;
  View view;
  ByteArrayOutputStream outContent;
  PrintStream originalOut;

  @Before
  public void setup() {
    view = new View();
    outContent = new ByteArrayOutputStream();
    originalOut = System.out;
    System.setOut(new PrintStream(outContent));
  }

  @After
  public void restoreStreams() {
    System.setOut(originalOut);
  }

  @Test
  public void testDisplayMessage() {
    message = "Test view";
    view.displayMessage(message);

    assertEquals(message + System.lineSeparator(), outContent.toString());
  }

  @Test
  public void testDisplayMessageMultipleLines() {
    message = "Test \nview";
    view.displayMessage(message);

    assertEquals(message + System.lineSeparator(), outContent.toString());
  }
}