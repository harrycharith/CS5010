package eventcalendar.view;

import org.junit.Before;
import org.junit.Test;

import java.time.LocalDate;


import javax.swing.JPanel;

import eventcalendar.controller.MockCalendar;
import eventcalendar.controller.MockCalendarManager;
import eventcalendar.model.ICalendar;
import eventcalendar.model.ICalendarManager;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * This is a test class to test the AbstractCalendarView.
 */
public class AbstractCalendarViewTest {

  private TestCalendarView calendarView;

  @Before
  public void setUp() {
    StringBuilder log = new StringBuilder();

    // Create mock calendar manager
    ICalendarManager testCalendarManager = new MockCalendarManager(log);

    // Create source calendar with test event
    ICalendar testCalendar = new MockCalendar("Source Calendar", log);

    calendarView = new TestCalendarView(testCalendar, testCalendarManager);
  }

  @Test
  public void testSetDateUpdatesCurrentDate() {
    LocalDate newDate = LocalDate.of(2025, 5, 15);
    calendarView.setDate(newDate);

    // Verify the date was updated
    assertEquals("Current date should be updated", newDate, calendarView.getCurrentDate());

    // Verify updateView was called
    assertTrue("updateView should be called when setting date", calendarView.wasUpdateViewCalled());
  }

  @Test
  public void testCalendarViewIsJPanel() {
    assertTrue(calendarView instanceof JPanel);
  }

  private static class TestCalendarView extends AbstractCalendarView {
    private int initializeUICallCount = 0;
    private boolean updateViewCalled = false;

    public TestCalendarView(ICalendar calendarModel, ICalendarManager calendarManager) {
      super(calendarModel, calendarManager);
    }

    @Override
    protected void initializeUI() {
      initializeUICallCount++;
    }

    public boolean wasInitializeUICalled() {
      return initializeUICallCount > 0;
    }

    @Override
    protected void updateView() {
      updateViewCalled = true;
    }

    public boolean wasUpdateViewCalled() {
      return updateViewCalled;
    }

    public LocalDate getCurrentDate() {
      return currentDate;
    }
  }
}