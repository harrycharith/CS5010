package eventcalendar.controller;

import java.time.LocalDateTime;
import java.util.UUID;

import eventcalendar.model.Event;

/**
 * Mock Class of Event used to test the controller in isolation.
 */
public class MockEvent extends Event {
  private final String name;
  private final LocalDateTime startTime;
  private final LocalDateTime endTime;
  private String description;
  private String location;
  private boolean isPublic;

  /**
   * Default constructor for MockEvent.
   */
  public MockEvent(String name, LocalDateTime startTime, LocalDateTime endTime) {
    super(UUID.randomUUID(), "Test Event", startTime, endTime,
            "Test Description", "Test Location", true);
    this.name = name;
    this.startTime = startTime;
    this.endTime = endTime;
    this.description = "";
    this.location = "";
    this.isPublic = false;
  }

  @Override
  public String getEventName() {
    return name;
  }

  @Override
  public String getEventDescription() {
    return description;
  }

  @Override
  public String getEventLocation() {
    return location;
  }

  @Override
  public boolean isPublic() {
    return isPublic;
  }

  @Override
  public LocalDateTime getEventStartDateTime() {
    return startTime;
  }

  @Override
  public LocalDateTime getEventEndDateTime() {
    return endTime;
  }

  // Builder methods for fluent setup
  public MockEvent withDescription(String description) {
    this.description = description;
    return this;
  }

  public MockEvent withLocation(String location) {
    this.location = location;
    return this;
  }

  public MockEvent withIsPublic(boolean isPublic) {
    this.isPublic = isPublic;
    return this;
  }
}
