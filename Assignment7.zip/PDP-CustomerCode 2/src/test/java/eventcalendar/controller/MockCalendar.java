package eventcalendar.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import eventcalendar.model.Event;
import eventcalendar.model.ICalendar;
import eventcalendar.model.SingleEvent;
import eventcalendar.model.WeekDays;

/**
 * Mock Class of Calendar implementing the Calendar interface, used to test the controller in
 * isolation.
 */
public class MockCalendar implements ICalendar {
  private final StringBuilder log;
  private final List<Event> mockEvents = new ArrayList<>();
  private String mockName;
  private ZoneId mockTimeZone;

  /**
   * Default values constructor.
   */
  public MockCalendar(String name, StringBuilder log) {
    this.mockName = name;
    this.mockTimeZone = ZoneId.of("America/New_York");
    this.log = log;
  }

  public void addMockEvent(Event event) {
    mockEvents.add(event);
  }

  @Override
  public String getName() {
    log.append("getName\n");
    return mockName;
  }

  @Override
  public void setName(String name) {
    log.append("setName:").append(name).append("\n");
    this.mockName = name;
  }

  @Override
  public ZoneId getTimeZone() {
    log.append("getTimeZone\n");
    return mockTimeZone;
  }

  @Override
  public void setTimeZone(String timeZone) {
    log.append("setTimeZone:").append(timeZone).append("\n");
    this.mockTimeZone = ZoneId.of(timeZone);
  }

  @Override
  public List<Event> getEvents() {
    log.append("getEvents\n");
    return new ArrayList<>(mockEvents);
  }

  @Override
  public List<Event> getEventsByName(String eventName) {
    return List.of();
  }

  @Override
  public List<Event> getEventByDate(LocalDate date) {
    return List.of();
  }

  @Override
  public boolean addEvent(SingleEvent.Builder eventBuilder, boolean autoDecline) {
    log.append("addEvent:").append(eventBuilder.toString())
            .append(":autoDecline=").append(autoDecline).append("\n");
    SingleEvent event = eventBuilder.build();

    // Check for conflicts if autoDecline is true
    if (autoDecline && checkConflict(event)) {
      log.append("eventDeclined:conflict\n");
      return false;
    }

    mockEvents.add(event);
    return true;
  }

  @Override
  public boolean createEvent(String eventName, LocalDateTime startDateTime,
                             LocalDateTime endDateTime,
                             String description, String location, boolean isPublic,
                             boolean autoDecline) {
    log.append("createEvent:eventName=").append(eventName)
            .append(":startDateTime=").append(startDateTime)
            .append(":endDateTime=").append(endDateTime)
            .append(":description=").append(description)
            .append(":location=").append(location)
            .append(":isPublic=").append(isPublic)
            .append(":autoDecline=").append(autoDecline).append("\n");

    SingleEvent.Builder builder = new SingleEvent.Builder(eventName, startDateTime)
            .eventEndDateTime(endDateTime);

    if (description != null) {
      builder.eventDescription(description);
    }

    if (location != null) {
      builder.eventLocation(location);
    }

    builder.isPublic(isPublic);

    return addEvent(builder, autoDecline);
  }

  @Override
  public boolean createAllDayEvent(String eventName, LocalDate date, LocalDate endDate,
                                   String description, String location, boolean isPublic,
                                   boolean autoDecline) {
    log.append("createAllDayEvent:eventName=").append(eventName)
            .append(":date=").append(date)
            .append(":endDate=").append(endDate)
            .append(":description=").append(description)
            .append(":location=").append(location)
            .append(":isPublic=").append(isPublic)
            .append(":autoDecline=").append(autoDecline).append("\n");

    LocalDateTime startDateTime = date.atStartOfDay();
    LocalDateTime endDateTime;

    if (endDate != null) {
      // End time is end of the day on the end date
      endDateTime = endDate.atTime(23, 59, 59);
    } else {
      // Default end time is end of the same day
      endDateTime = date.atTime(23, 59, 59);
    }

    SingleEvent.Builder builder = new SingleEvent.Builder(eventName, startDateTime)
            .eventEndDateTime(endDateTime);

    if (description != null) {
      builder.eventDescription(description);
    }

    if (location != null) {
      builder.eventLocation(location);
    }

    builder.isPublic(isPublic);

    return addEvent(builder, autoDecline);
  }

  @Override
  public int createRecurringEventUntil(String eventName, LocalDateTime startDateTime,
                                       LocalDateTime endDateTime,
                                       List<WeekDays> repeatDays, LocalDateTime repeatUntil,
                                       String description, String location, boolean isPublic,
                                       boolean autoDecline) {
    log.append("createRecurringEventUntil:eventName=").append(eventName)
            .append(":startDateTime=").append(startDateTime)
            .append(":endDateTime=").append(endDateTime)
            .append(":repeatDays=").append(repeatDays)
            .append(":repeatUntil=").append(repeatUntil)
            .append(":description=").append(description)
            .append(":location=").append(location)
            .append(":isPublic=").append(isPublic)
            .append(":autoDecline=").append(autoDecline).append("\n");

    if (repeatDays == null || repeatDays.isEmpty()) {
      return 0;
    }

    if (repeatUntil.isBefore(startDateTime)) {
      return 0;
    }

    // Calculate the event duration in minutes
    long durationMinutes = java.time.Duration.between(startDateTime, endDateTime).toMinutes();

    // Create individual events for each occurrence
    int successCount = 0;
    LocalDateTime currentDate = startDateTime;

    while (!currentDate.isAfter(repeatUntil)) {
      WeekDays currentDay = convertDayOfWeekToWeekDays(currentDate.getDayOfWeek());

      if (repeatDays.contains(currentDay)) {
        // Create a new single event for this occurrence
        LocalDateTime eventStart = currentDate;
        LocalDateTime eventEnd = eventStart.plusMinutes(durationMinutes);

        SingleEvent.Builder builder = new SingleEvent.Builder(eventName, eventStart)
                .eventEndDateTime(eventEnd);

        if (description != null) {
          builder.eventDescription(description);
        }

        if (location != null) {
          builder.eventLocation(location);
        }

        builder.isPublic(isPublic);

        boolean added = addEvent(builder, autoDecline);
        if (added) {
          successCount++;
        }
      }

      // Move to the next day
      currentDate = currentDate.plusDays(1);
    }

    return successCount;
  }

  @Override
  public int createRecurringEventOccurrences(String eventName, LocalDateTime startDateTime,
                                             LocalDateTime endDateTime,
                                             List<WeekDays> repeatDays, int occurrences,
                                             String description, String location, boolean isPublic,
                                             boolean autoDecline) {
    log.append("createRecurringEventOccurrences:eventName=").append(eventName)
            .append(":startDateTime=").append(startDateTime)
            .append(":endDateTime=").append(endDateTime)
            .append(":repeatDays=").append(repeatDays)
            .append(":occurrences=").append(occurrences)
            .append(":description=").append(description)
            .append(":location=").append(location)
            .append(":isPublic=").append(isPublic)
            .append(":autoDecline=").append(autoDecline).append("\n");

    if (repeatDays == null || repeatDays.isEmpty() || occurrences <= 0) {
      return 0;
    }

    // Calculate the event duration in minutes
    long durationMinutes = java.time.Duration.between(startDateTime, endDateTime).toMinutes();

    // Create individual events for each occurrence
    int successCount = 0;
    LocalDateTime currentDate = startDateTime;
    int remainingOccurrences = occurrences;

    while (remainingOccurrences > 0) {
      WeekDays currentDay = convertDayOfWeekToWeekDays(currentDate.getDayOfWeek());

      if (repeatDays.contains(currentDay)) {
        // Create a new single event for this occurrence
        LocalDateTime eventStart = currentDate;
        LocalDateTime eventEnd = eventStart.plusMinutes(durationMinutes);

        SingleEvent.Builder builder = new SingleEvent.Builder(eventName, eventStart)
                .eventEndDateTime(eventEnd);

        if (description != null) {
          builder.eventDescription(description);
        }

        if (location != null) {
          builder.eventLocation(location);
        }

        builder.isPublic(isPublic);

        boolean added = addEvent(builder, autoDecline);
        if (added) {
          successCount++;
        }

        remainingOccurrences--;
      }

      // Move to the next day
      currentDate = currentDate.plusDays(1);
    }

    return successCount;
  }

  /**
   * Converts java.time.DayOfWeek to WeekDays enum
   */
  private WeekDays convertDayOfWeekToWeekDays(java.time.DayOfWeek dayOfWeek) {
    switch (dayOfWeek) {
      case MONDAY:
        return WeekDays.M;
      case TUESDAY:
        return WeekDays.T;
      case WEDNESDAY:
        return WeekDays.W;
      case THURSDAY:
        return WeekDays.R;
      case FRIDAY:
        return WeekDays.F;
      case SATURDAY:
        return WeekDays.S;
      case SUNDAY:
        return WeekDays.U;
      default:
        throw new IllegalArgumentException("Unknown day of week: " + dayOfWeek);
    }
  }

  /**
   * This method checks for conflicts with the events
   * present in the calendar.
   *
   * @param event an event object to check for conflicts.
   * @return a boolean value which is true if conflicts are found and false if not.
   */
  private boolean checkConflict(Event event) {
    log.append("checkConflict:").append(event.getEventName()).append("\n");

    LocalDateTime newStart = event.getEventStartDateTime();
    LocalDateTime newEnd = event.getEventEndDateTime();

    // Two intervals [start1, end1] and [start2, end2] overlap if and only if:
    // start1 < end2 AND start2 < end1
    //
    // For calendar events, we consider adjacent events (where one ends exactly when
    // another starts) as non-conflicting
    List<Event> conflictingEvents = mockEvents.stream()
            .filter(existingEvent -> {
              LocalDateTime existingStart = existingEvent.getEventStartDateTime();
              LocalDateTime existingEnd = existingEvent.getEventEndDateTime();

              // Check if events are adjacent (one ends exactly when the other starts)
              boolean adjacent = existingEnd.isEqual(newStart) || newEnd.isEqual(existingStart);

              // If they're adjacent, they don't conflict
              if (adjacent) {
                return false;
              }

              // Check for overlap
              return (existingStart.isBefore(newEnd) && newStart.isBefore(existingEnd));
            })
            .collect(Collectors.toList());

    boolean hasConflict = !conflictingEvents.isEmpty();
    if (hasConflict) {
      log.append("conflictDetected:").append(conflictingEvents.get(0).getEventName()).append("\n");
    }

    return hasConflict;
  }

  @Override
  public boolean removeEvent(Event event) {
    log.append("removeEvent:").append(event.toString()).append("\n");
    return mockEvents.remove(event);
  }

  /**
   * Edits a specific property of a single event identified by name, start time, and end time.
   *
   * @param eventName     The name of the event to edit
   * @param startDateTime The start date and time of the event
   * @param endDateTime   The end date and time of the event
   * @param property      The property to edit (name, description, location, or isPublic)
   * @param newValue      The new value for the property
   * @return true if the update was successful, false otherwise
   */
  @Override
  public boolean editSingleEvent(String eventName, LocalDateTime startDateTime,
                                 LocalDateTime endDateTime, String property, String newValue) {
    log.append("editSingleEvent:eventName=").append(eventName)
            .append(":startDateTime=").append(startDateTime)
            .append(":endDateTime=").append(endDateTime)
            .append(":property=").append(property)
            .append(":newValue=").append(newValue).append("\n");

    // Validate property
    if (!isValidProperty(property)) {
      log.append("editFailed:invalidProperty:").append(property).append("\n");
      return false;
    }

    // Find the specific event that matches name, start time, and end time
    Event eventToEdit = null;
    for (Event event : mockEvents) {
      if (event.getEventName().equals(eventName) &&
              event.getEventStartDateTime().equals(startDateTime) &&
              event.getEventEndDateTime().equals(endDateTime)) {
        eventToEdit = event;
        break;
      }
    }

    if (eventToEdit == null) {
      log.append("editFailed:eventNotFound\n");
      return false; // Event not found
    }

    // Since events are immutable, we need to remove the old event and add a new one
    return updateEvent(eventToEdit, property, newValue);
  }

  /**
   * Edits a specific property of all events with a given name that start at or after
   * a specified time.
   *
   * @param eventName     The name of the events to edit
   * @param startDateTime The start date and time threshold for events to edit
   * @param property      The property to edit (name, description, location, or isPublic)
   * @param newValue      The new value for the property
   * @return The number of events successfully updated
   */
  @Override
  public int editEventsByNameAndStartTime(String eventName, LocalDateTime startDateTime,
                                          String property, String newValue) {
    log.append("editEventsByNameAndStartTime:eventName=").append(eventName)
            .append(":startDateTime=").append(startDateTime)
            .append(":property=").append(property)
            .append(":newValue=").append(newValue).append("\n");

    // Validate property
    if (!isValidProperty(property)) {
      log.append("editFailed:invalidProperty:").append(property).append("\n");
      return 0;
    }

    // Find all events that match the name and start at or after the given time
    List<Event> matchingEvents = mockEvents.stream()
            .filter(e -> e.getEventName().equals(eventName) &&
                    (e.getEventStartDateTime().equals(startDateTime) ||
                            e.getEventStartDateTime().isAfter(startDateTime)))
            .collect(Collectors.toList());

    if (matchingEvents.isEmpty()) {
      log.append("editFailed:noEventsFound\n");
      return 0;
    }

    // Edit the property of all matching events
    int successCount = 0;
    for (Event event : matchingEvents) {
      boolean success = updateEvent(event, property, newValue);
      if (success) {
        successCount++;
      }
    }

    log.append("editSuccess:eventsUpdated=").append(successCount).append("\n");
    return successCount;
  }

  /**
   * Edits a specific property of all events with a specific name.
   *
   * @param eventName The name of the events to edit
   * @param property  The property to edit (name, description, location, or isPublic)
   * @param newValue  The new value for the property
   * @return The number of events successfully updated
   */
  @Override
  public int editAllEventsByName(String eventName, String property, String newValue) {
    log.append("editAllEventsByName:eventName=").append(eventName)
            .append(":property=").append(property)
            .append(":newValue=").append(newValue).append("\n");

    // Validate property
    if (!isValidProperty(property)) {
      log.append("editFailed:invalidProperty:").append(property).append("\n");
      return 0;
    }

    // Find all events that match the name
    List<Event> matchingEvents = mockEvents.stream()
            .filter(e -> e.getEventName().equals(eventName))
            .collect(Collectors.toList());

    if (matchingEvents.isEmpty()) {
      log.append("editFailed:noEventsFound\n");
      return 0;
    }

    // Edit the property of all matching events
    int successCount = 0;
    for (Event event : matchingEvents) {
      boolean success = updateEvent(event, property, newValue);
      if (success) {
        successCount++;
      }
    }

    log.append("editSuccess:eventsUpdated=").append(successCount).append("\n");
    return successCount;
  }

  /**
   * Updates a single event by creating a new one with the updated property and replacing old one.
   *
   * @param event    The event to update
   * @param property The property to update
   * @param newValue The new value for the property
   * @return true if the update was successful, false otherwise
   */
  private boolean updateEvent(Event event, String property, String newValue) {
    log.append("updateEvent:event=").append(event.getEventName())
            .append(":property=").append(property)
            .append(":newValue=").append(newValue).append("\n");

    // Remove the old event
    boolean removed = removeEvent(event);
    if (!removed) {
      log.append("updateFailed:removeEventFailed\n");
      return false;
    }

    // Create a new event with the updated property
    SingleEvent.Builder builder = new SingleEvent.Builder(
            property.equals("name") ? newValue : event.getEventName(),
            event.getEventStartDateTime())
            .eventEndDateTime(event.getEventEndDateTime())
            .eventDescription(property.equals("description") ? newValue :
                    event.getEventDescription())
            .eventLocation(property.equals("location") ? newValue : event.getEventLocation());

    if (property.equals("isPublic")) {
      builder.isPublic(Boolean.parseBoolean(newValue));
    } else {
      builder.isPublic(event.isPublic());
    }

    // Add the new event (don't auto-decline since we're updating an existing event slot)
    return addEvent(builder, false);
  }

  /**
   * Checks if the provided property is valid for editing.
   * Based on the Event class properties that can be modified.
   *
   * @param property The property to validate
   * @return true if the property is valid, false otherwise
   */
  private boolean isValidProperty(String property) {
    boolean isValid = "name".equals(property) || "description".equals(property) ||
            "location".equals(property) || "isPublic".equals(property);

    log.append("isValidProperty:property=").append(property)
            .append(":isValid=").append(isValid).append("\n");

    return isValid;
  }
}