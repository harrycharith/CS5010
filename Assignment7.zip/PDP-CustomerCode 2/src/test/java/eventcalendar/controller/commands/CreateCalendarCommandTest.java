package eventcalendar.controller.commands;


import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

import eventcalendar.controller.MockCalendar;
import eventcalendar.controller.MockCalendarManager;
import eventcalendar.controller.MockEvent;

import static org.junit.Assert.assertEquals;

/**
 * This is a class to test teh CreateCalendarCommand class.
 */
public class CreateCalendarCommandTest {
  private MockCalendarManager mockCalendarManager;
  private MockCalendar sourceCalendar;
  private CreateCalendarCommand createCalendarCommand;
  private MockEvent testEvent;

  @Before
  public void setup() {
    // Setup test logging
    StringBuilder log = new StringBuilder();

    // Create mock calendar manager
    mockCalendarManager = new MockCalendarManager(log);

    // Create source calendar with test event
    sourceCalendar = new MockCalendar("Source Calendar", log);

    // Create target calendar with different timezone
    MockCalendar targetCalendar = new MockCalendar("Target Calendar", log);
    targetCalendar.setTimeZone("Asia/Kolkata");

    // Add both calendars to the manager
    mockCalendarManager.addMockCalendar(sourceCalendar);
    mockCalendarManager.addMockCalendar(targetCalendar);

    // Create the command to test
    createCalendarCommand = new CreateCalendarCommand(mockCalendarManager);
  }

  @Test
  public void testEmptyCalendarName() {
    Map<String, String> args = new HashMap<>();
    args.put("calendarName", "");
    args.put("calendarTimeZone", "Asia/Kolkata");
    String result = createCalendarCommand.execute(args);

    assertEquals("Calendar name cannot be empty", result);
  }

  @Test
  public void testDuplicateCalendarName() {
    mockCalendarManager.addMockCalendar(sourceCalendar);

    Map<String, String> args = new HashMap<>();
    args.put("calendarName", sourceCalendar.getName());
    args.put("calendarTimeZone", "Asia/Kolkata");
    String result = createCalendarCommand.execute(args);

    assertEquals(sourceCalendar.getName() +
            " is already present, choose another name.", result);
  }

  @Test
  public void testEmptyCalendarTimeZone() {
    Map<String, String> args = new HashMap<>();
    args.put("calendarName", "NoTimeZoneCalendar");
    args.put("calendarTimeZone", "");
    String result = createCalendarCommand.execute(args);
    assertEquals("Calendar TimeZone cannot be empty", result);
  }

  @Test
  public void testInvalidTimeZone() {
    Map<String, String> args = new HashMap<>();
    args.put("calendarName", "InvalidTimeZoneCalendar");
    args.put("calendarTimeZone", "Invalid/Timezone");
    String result = createCalendarCommand.execute(args);

    String expected = "Error: Invalid timezone 'Invalid/Timezone'. Please use IANA " +
            "Time Zone Database format (area/location).\n" +
            "Examples: America/New_York, Europe/Paris, Asia/Kolkata";
    assertEquals(expected, result);
  }

  @Test
  public void testSuccessfulCalendarCreation() {
    Map<String, String> args = new HashMap<>();
    args.put("calendarName", "New");
    args.put("calendarTimeZone", "Asia/Kolkata");
    String result = createCalendarCommand.execute(args);
    assertEquals("Calendar created successfully: New", result);
  }


  @Test
  public void testQuotesRemoval() {
    Map<String, String> args = new HashMap<>();
    args.put("calendarName", "\"New Calendar\"");
    args.put("calendarTimeZone", "\"Asia/Kolkata\"");
    String result = createCalendarCommand.execute(args);
    assertEquals("Calendar created successfully: New Calendar", result);
  }


}