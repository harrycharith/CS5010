package eventcalendar.controller.commands;

import org.junit.Before;
import org.junit.Test;

import java.util.function.Consumer;

import eventcalendar.controller.CommandProcessor;
import eventcalendar.controller.Controller;
import eventcalendar.model.Calendar;
import eventcalendar.model.CalendarManager;
import eventcalendar.model.ICalendar;
import eventcalendar.model.ICalendarManager;
import eventcalendar.view.View;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Test class for PrintEventsCommand.
 */
public class ShowStatusCommandTest {

  private CommandProcessor commandProcessor;

  @Before
  public void setup() {
    // Initialize test objects
    // Test objects
    ICalendarManager calendarManager = new CalendarManager();
    ICalendar calendar = new Calendar.Builder().build();
    Controller controller = new Controller(calendar);
    // Test data
    View view = new View();
    Consumer<ICalendar> updateCalendarConsumer = null;
    commandProcessor = new CommandProcessor(calendarManager,
            updateCalendarConsumer, controller, calendar, view, "");
  }

  @Test
  public void testProcessCommand_ShowStatus() {
    // Create an event that will make the user busy
    String createCommand = "create event Status Test Meeting from 2025-04-15T10:00" +
            " to 2025-04-15T12:00 " +
            "description Status test meeting location Conference Room";

    String result = commandProcessor.processCommand(createCommand);
    assertTrue("Event creation should succeed", result.contains("successfully"));

    // Test when user is busy (during the meeting)
    String busyStatusCommand = "show status on 2025-04-15T11:00";
    String busyResult = commandProcessor.processCommand(busyStatusCommand);

    assertTrue("User should be busy during the meeting", busyResult.contains("busy"));

    // Test when user is available (outside meeting hours)
    String availableStatusCommand = "show status on 2025-04-15T13:00";
    String availableResult = commandProcessor.processCommand(availableStatusCommand);
    assertTrue("User should be available outside meeting hours",
            availableResult.contains("available"));

    // Test on a different day when no meetings are scheduled
    String differentDayCommand = "show status on 2025-04-16T11:00";
    String differentDayResult = commandProcessor.processCommand(differentDayCommand);
    assertTrue("User should be available on a day with no meetings",
            differentDayResult.contains("available"));
  }

  @Test
  public void testProcessCommand_ShowStatusMissingTimeParameter() {
    // Test when the time parameter is missing
    String command = "show status";
    String result = commandProcessor.processCommand(command);
    assertEquals("Error processing command: Invalid Create Command after: status", result);
  }

  @Test
  public void testProcessCommand_ShowStatusInvalidDate() {
    // Test with invalid date (April 32nd doesn't exist)
    String command = "show status on 2025-04-32T11:00";
    String result = commandProcessor.processCommand(command);
    assertTrue("Should return error for invalid date",
            result.contains("Error"));
  }

  @Test
  public void testProcessCommand_ShowStatusInvalidTime() {
    // Test with invalid time (25 hours doesn't exist)
    String command = "show status on 2025-04-15T25:00";
    String result = commandProcessor.processCommand(command);

    assertTrue("Should return error for invalid time",
            result.contains("Error"));
  }

  @Test
  public void testParseWhitespaceOnlyCommand() {
    String whitespaceCommand = "test";
    String result = commandProcessor.processCommand(whitespaceCommand);
    assertTrue(result.contains("Unknown command: test"));
  }
}