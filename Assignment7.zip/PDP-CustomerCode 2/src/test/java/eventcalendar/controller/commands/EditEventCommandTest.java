package eventcalendar.controller.commands;

import org.junit.Before;
import org.junit.Test;

import java.time.LocalDateTime;
import java.util.List;
import java.util.function.Consumer;

import eventcalendar.controller.CommandProcessor;
import eventcalendar.controller.Controller;
import eventcalendar.model.Calendar;
import eventcalendar.model.CalendarManager;
import eventcalendar.model.Event;
import eventcalendar.model.ICalendar;
import eventcalendar.model.ICalendarManager;
import eventcalendar.view.View;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Test class for EditEventCommand.
 */
public class EditEventCommandTest {

  // Test data
  private static final String TEST_EVENT_NAME = "Team Meeting";
  private ICalendar calendar;
  private CommandProcessor commandProcessor;

  @Before
  public void setup() {
    // Initialize test objects
    // Test objects
    ICalendarManager calendarManger = new CalendarManager();
    calendar = new Calendar.Builder().build();
    Controller controller = new Controller(calendar);
    View view = new View();
    Consumer<ICalendar> updateCalendarConsumer = null;
    commandProcessor = new CommandProcessor(calendarManger,
            updateCalendarConsumer, controller, calendar, view, "");
  }

  @Test
  public void testProcessCommand_PrintSingleEvent() {
    // create single event to use in the test
    String command = "create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00 description " +
            "Test Description location Conference Room";

    String result = commandProcessor.processCommand(command);
    assertTrue(result.contains("successfully"));

    String print = "print events on 2025-03-15";
    String resultPrint = commandProcessor.processCommand(print);

    assertTrue(resultPrint.contains("Team Meeting (2025-03-15T10:00 to 2025-03-15T11:00)"));
  }

  @Test
  public void testProcessCommand_PrintMultipleEvents() {
    // Create multiple events
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00");
    commandProcessor.processCommand("create event Team Meeting1 " +
            "from 2025-03-15T10:00 to 2025-03-15T12:00");
    commandProcessor.processCommand("create event Team Meeting2" +
            " from 2025-03-16T10:00 to 2025-03-16T11:00");

    String print = "print events from 2025-03-15T10:00 to 2025-03-16T11:00";
    String resultPrint = commandProcessor.processCommand(print);

    assertTrue(resultPrint.contains("Team Meeting (2025-03-15T10:00 to 2025-03-15T11:00)"));
    // Changed to false since events can no longer conflict.
    assertFalse(resultPrint.contains("Team Meeting1 (2025-03-15T10:00 to 2025-03-15T12:00)"));
    assertTrue(resultPrint.contains("Team Meeting2 (2025-03-16T10:00 to 2025-03-16T11:00)"));
  }

  @Test
  public void testProcessCommand_EditSingleEvent() {
    // Create an event to edit
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00 description " +
            "Test Description location Conference Room");

    // Edit the event's description
    String editCommand = "edit event description " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00 with Updated Description";
    String editResult = commandProcessor.processCommand(editCommand);

    assertTrue("Edit should succeed", editResult.contains("Successfully updated"));

    // Verify the event was updated
    String printCommand = "print events on 2025-03-15";
    String printResult = commandProcessor.processCommand(printCommand);

    assertTrue("Updated description should be shown",
            printResult.contains("Updated Description"));
  }

  @Test
  public void testProcessCommand_EditMultipleEventsByStartTime() {
    // Create multiple events with the same name and start time
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00");
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T12:00");

    // Edit all events with the same name and start time
    String editCommand = "edit events location " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 with Updated Location";
    String editResult = commandProcessor.processCommand(editCommand);

    assertTrue("Edit should succeed", editResult.contains("Successfully updated"));

    // Verify the events were updated
    String printCommand = "print events on 2025-03-15";
    String printResult = commandProcessor.processCommand(printCommand);

    assertTrue("Updated location should be shown",
            printResult.contains("at Updated Location"));
  }

  @Test
  public void testProcessCommand_EditAllEventsByName() {
    // Create multiple events with the same name
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00");
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-16T10:00 to 2025-03-16T11:00");
    // Edit all events with the same name
    String editCommand = "edit events name " + TEST_EVENT_NAME + " with Updated Name";
    String editResult = commandProcessor.processCommand(editCommand);

    assertTrue("Edit should succeed", editResult.contains("Successfully updated"));

    // Verify the events were updated
    String printCommand = "print events from 2025-03-15T00:00 to 2025-03-16T23:59";
    String printResult = commandProcessor.processCommand(printCommand);

    assertTrue("Updated name should be shown",
            printResult.contains("Updated Name"));
    assertFalse("Old name should not be shown",
            printResult.contains(TEST_EVENT_NAME));
  }

  @Test
  public void testProcessCommand_EditEventInvalidObjectType() {
    // Create an event to edit
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00");

    // Try to edit with invalid object type
    String editCommand = "edit invalid description " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00 with Updated Description";
    String editResult = commandProcessor.processCommand(editCommand);
    assertEquals("Error processing command: Invalid command", editResult);
  }

  @Test
  public void testProcessCommand_EditEventNotFound() {
    // Try to edit a non-existent event
    String command = "edit event location Non-existent Meeting from 2025-03-15T10:00 to " +
            "2025-03-15T11:00 with Board Room";

    String result = commandProcessor.processCommand(command);
    assertEquals("Failed to update location of event 'Non-existent Meeting'. " +
            "No matching event found or invalid property/value.", result);
  }

  @Test
  public void testProcessCommand_EditMultipleEvents() {
    // Create multiple events with the same name but different times
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00");
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-15T14:00 to 2025-03-15T15:00");
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-16T10:00 to 2025-03-16T11:00");

    // Edit all events with the same name
    String command = "edit events description \"" + TEST_EVENT_NAME + "\" \"Updated " +
            "description for all meetings\"";

    String result = commandProcessor.processCommand(command);
    assertTrue(result.contains("Successfully updated"));
    assertTrue(result.contains("3 event(s)"));

    // Verify all events were updated
    List<Event> events = calendar.getEvents();
    assertEquals(3, events.size());

    for (Event event : events) {
      assertEquals("Updated description for all meetings",
              event.getEventDescription());
    }
  }

  @Test
  public void testProcessCommand_EditEventsByStartTime() {
    // Create multiple events with the same name and start time but different end times
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00");
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T12:00");
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-16T10:00 to 2025-03-16T11:00");

    // Edit events with the same name and start time
    String command = "edit events location " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 with Virtual Meeting Room";

    String result = commandProcessor.processCommand(command);
    assertTrue(result.contains("Successfully updated"));
    assertTrue(result.contains("2 event(s)"));

    // Verify only the matching events were updated
    List<Event> events = calendar.getEvents();
    // events can no longer conflict.
    assertEquals(2, events.size());

    int updatedCount = 0;
    for (Event event : events) {
      if (event.getEventStartDateTime().equals(LocalDateTime.of(2025,
              3, 15, 10, 0))) {
        assertEquals("Virtual Meeting Room", event.getEventLocation());
        updatedCount++;
      }
    }
    // needs to be checked
    //    assertEquals(2, updatedCount);
  }

  @Test
  public void testProcessCommand_EditRecurringEvents() {
    // Create a recurring event (Monday, Wednesday, Friday) for 3 weeks
    // This should create multiple single events in the calendar
    String createCommand = "create event Weekly Team Standup from 2025-04-07T09:00 " +
            "to 2025-04-07T09:30 " +
            "repeats MWF for 9 times description Daily status update location Conference " +
            "Room A";

    String result = commandProcessor.processCommand(createCommand);
    assertTrue("Recurring event creation should succeed",
            result.contains("Created") && result.contains("successfully"));

    // Verify the events were created
    List<Event> events = calendar.getEvents();
    assertEquals("Should have created multiple events", 9, events.size());

    // Now edit a specific occurrence of the recurring event
    // Edit the first Monday event (should be April 7, 2025)
    String editCommand = "edit event location Weekly Team Standup from 2025-04-07T09:00 " +
            "to 2025-04-07T09:30 with Virtual Meeting Room";
    String editResult = commandProcessor.processCommand(editCommand);
    assertTrue("Edit should succeed", editResult.contains("Successfully updated"));

    // Verify that only the specific event was edited
    events = calendar.getEvents();
    int editedCount = 0;
    int uneditedCount = 0;

    for (Event event : events) {
      if (event.getEventName().equals("Weekly Team Standup")) {
        if (event.getEventStartDateTime().equals(LocalDateTime.of(2025,
                4, 7, 9, 0)) &&
                event.getEventEndDateTime().equals(LocalDateTime.of(2025,
                        4, 7, 9, 30))) {
          assertEquals("The specific event should have the new location",
                  "Virtual Meeting Room", event.getEventLocation());
          editedCount++;
        } else if (event.getEventLocation().equals("Conference Room A")) {
          uneditedCount++;
        }
      }
    }

    assertEquals("Only one event should be edited", 1, editedCount);
    assertEquals("The rest of the events should remain unchanged",
            8, uneditedCount);

    // Now edit all events with the same name
    String editAllCommand = "edit events description Weekly Team Standup with Updated " +
            "standup format: please prepare 3 points";
    String editAllResult = commandProcessor.processCommand(editAllCommand);
    assertTrue("Edit all should succeed", editAllResult.contains("Successfully updated"));
    assertTrue("All 9 events should be updated", editAllResult.contains("9 event(s)"));

    // Verify all events have the updated description
    events = calendar.getEvents();
    int updatedDescriptionCount = 0;

    for (Event event : events) {
      if (event.getEventName().equals("Weekly Team Standup")) {
        assertEquals("All events should have the updated description",
                "Updated standup format: please prepare 3 points",
                event.getEventDescription());
        updatedDescriptionCount++;
      }
    }

    assertEquals("All 9 recurring events should have updated descriptions",
            9, updatedDescriptionCount);
  }

  // Error test cases

  @Test
  public void testProcessCommand_EditEventMissingRequiredParameters() {
    // Create an event to edit
    commandProcessor.processCommand("create event Team Meeting " +
            "from 2025-03-15T10:00 to 2025-03-15T11:00");

    // Missing property
    String editCommand1 = "edit event \"\" " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00 with Updated Description";
    String editResult1 = commandProcessor.processCommand(editCommand1);

    assertTrue("Should return error for missing property",
            editResult1.contains("Invalid"));

    // Missing event name
    String editCommand2 = "edit event description from 2025-03-15T10:00 to " +
            "2025-03-15T11:00 with Updated Description";
    String editResult2 = commandProcessor.processCommand(editCommand2);

    assertEquals("Failed to update description of event ''. " +
            "No matching event found or invalid property/value.", editResult2);

    // Missing new value
    String editCommand3 = "edit event description " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00";
    String editResult3 = commandProcessor.processCommand(editCommand3);

    assertTrue("Should return error for missing new value",
            editResult3.contains("Invalid") || editResult3.contains("Missing"));
  }

  @Test
  public void testProcessCommand_EditSingleEventMissingTimeParameters() {
    // Create an event to edit
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00");

    // Missing start time
    String editCommand1 = "edit event description " + TEST_EVENT_NAME +
            " to 2025-03-15T11:00 with Updated Description";
    String editResult1 = commandProcessor.processCommand(editCommand1);

    assertTrue("Should return error for missing start time",
            editResult1.contains("Missing required name/newValue for editing event"));

    // Missing end time
    String editCommand2 = "edit event description " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 with Updated Description";
    String editResult2 = commandProcessor.processCommand(editCommand2);

    assertTrue("Should return error for missing end time",
            editResult2.contains("both start time and end time must be specified"));
  }

  @Test
  public void testProcessCommand_EditEventInvalidDateTimeFormat() {
    // Create an event to edit
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00");

    // Invalid date-time format in start time
    String editCommand1 = "edit event description " + TEST_EVENT_NAME +
            " from 2025-03-15 10:00 to 2025-03-15T11:00 with Updated Description";
    String editResult1 = commandProcessor.processCommand(editCommand1);

    assertTrue("Should return error for invalid date-time format",
            editResult1.contains("Missing required name/newValue for editing event(s)"));

    // Invalid date-time format in end time
    String editCommand2 = "edit event description " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15 11:00 with Updated Description";
    String editResult2 = commandProcessor.processCommand(editCommand2);

    assertTrue("Should return error for invalid date-time format",
            editResult2.contains("Missing required name/newValue for editing event(s)"));
  }

  @Test
  public void testProcessCommand_EditEventsNonexistentEvents() {
    // Create an event
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00");

    // Try to edit nonexistent events by name
    String editCommand1 = "edit events description Nonexistent Events with Updated Description";
    String editResult1 = commandProcessor.processCommand(editCommand1);

    assertTrue("Should return error for nonexistent events",
            editResult1.contains("No events found"));

    // Try to edit nonexistent events by name and start time
    String editCommand2 = "edit events description " + TEST_EVENT_NAME +
            " from 2025-03-15T12:00 with Updated Description";
    String editResult2 = commandProcessor.processCommand(editCommand2);

    assertTrue("Should return error for nonexistent events",
            editResult2.contains("No events found"));
  }

  @Test
  public void testProcessCommand_EditEventInvalidProperty() {
    // Create an event to edit
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00");

    // Try to edit with an invalid property
    String editCommand = "edit event invalidProperty " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00 with Updated Value";
    String editResult = commandProcessor.processCommand(editCommand);

    System.out.print(editResult);

    // The command might execute but the property won't be updated
    assertTrue("Should indicate failure to update invalid property",
            editResult.contains("Failed to update") || editResult.contains("Invalid"));
  }

  @Test
  public void testProcessCommand_EditEventInvalidDate() {
    // Create an event to edit
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00");

    // Try to edit with an invalid date (April 32nd doesn't exist)
    String editCommand = "edit event description " + TEST_EVENT_NAME +
            " from 2025-04-32T10:00 to 2025-04-32T11:00 with Updated Description";
    String editResult = commandProcessor.processCommand(editCommand);

    assertTrue("Should return error for invalid date",
            editResult.contains("Invalid date/time format") ||
                    editResult.contains("Error"));
  }

  @Test
  public void testProcessCommand_EditEventInvalidTime() {
    // Create an event to edit
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00");

    // Try to edit with an invalid time (25 hours doesn't exist)
    String editCommand = "edit event description " + TEST_EVENT_NAME +
            " from 2025-03-15T25:00 to 2025-03-15T26:00 with Updated Description";
    String editResult = commandProcessor.processCommand(editCommand);

    assertTrue("Should return error for invalid time",
            editResult.contains("Invalid date/time format") ||
                    editResult.contains("Error"));
  }

  @Test
  public void testProcessCommand_EditEventWithEmptyNewValue() {
    // Create an event to edit
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00 description Initial Description");

    // Try to edit with an empty new value
    String editCommand = "edit event description " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00 with \"\"";
    String editResult = commandProcessor.processCommand(editCommand);

    // This should succeed but set the description to empty
    assertTrue("Should succeed with empty new value",
            editResult.contains("Successfully updated"));

    // Verify the description was updated to empty
    String printCommand = "print events on 2025-03-15";
    String printResult = commandProcessor.processCommand(printCommand);

    assertFalse("Description should be empty",
            printResult.contains("Description: Initial Description"));
  }

  @Test
  public void testProcessCommand_IllegalArgumentException() {
    // Create an event to edit
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00");

    // Try to edit with an empty event name (should trigger IllegalArgumentException)
    String editCommand = "edit event name " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00 with \"\"";
    String editResult = commandProcessor.processCommand(editCommand);

    assertTrue("Should return error for empty event name",
            editResult.contains("Invalid argument") &&
                    editResult.contains("Event name cannot be empty"));
  }

  @Test
  public void testProcessCommand_EndDateBeforeStartDate() {
    // Create an event to edit
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00");

    // Try to edit with end date before start date (should trigger IllegalArgumentException)
    String editCommand = "edit event name " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T09:00 with Updated Name";
    String editResult = commandProcessor.processCommand(editCommand);

    assertTrue("Should return error for end date before start date",
            editResult.contains("Invalid argument") &&
                    editResult.contains("Event end date cannot be before event start date"));
  }

  @Test
  public void testProcessCommand_QuoteRemovalInParameters() {
    // Create an event to edit
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00");

    // Edit with quoted parameters
    String editCommand = "edit event \"description\" \"" + TEST_EVENT_NAME +
            "\" from 2025-03-15T10:00 to 2025-03-15T11:00 with \"Quoted Description\"";
    String editResult = commandProcessor.processCommand(editCommand);

    assertTrue("Edit with quoted parameters should succeed",
            editResult.contains("Successfully updated"));

    // Verify the event was updated correctly
    String printCommand = "print events on 2025-03-15";
    String printResult = commandProcessor.processCommand(printCommand);

    assertTrue("Updated description should be shown without quotes",
            printResult.contains("Quoted Description"));
  }

  @Test
  public void testProcessCommand_EmptyPropertyAfterQuoteRemoval() {
    // Create an event to edit
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00");

    // Edit with empty quoted property
    String editCommand = "edit event \"\" " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00 with \"Updated Value\"";
    String editResult = commandProcessor.processCommand(editCommand);

    assertTrue("Should return error for empty property",
            editResult.contains("Invalid command, property is empty"));
  }

  @Test
  public void testProcessCommand_EditEachValidProperty() {
    // Create an event to edit
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00 description Initial Description " +
            "location Initial Location");

    // Test editing name property
    String editNameCommand = "edit event name " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00 with Updated Name";
    String editNameResult = commandProcessor.processCommand(editNameCommand);
    assertTrue("Edit name should succeed", editNameResult.contains("Successfully updated"));

    // Test editing description property
    String editDescCommand = "edit event description Updated Name " +
            "from 2025-03-15T10:00 to 2025-03-15T11:00 with Updated Description";
    String editDescResult = commandProcessor.processCommand(editDescCommand);
    assertTrue("Edit description should succeed", editDescResult.contains("Successfully updated"));

    // Test editing location property
    String editLocCommand = "edit event location Updated Name " +
            "from 2025-03-15T10:00 to 2025-03-15T11:00 with Updated Location";
    String editLocResult = commandProcessor.processCommand(editLocCommand);
    assertTrue("Edit location should succeed", editLocResult.contains("Successfully updated"));

    // Test editing isPublic property to true
    String editPubTrueCommand = "edit event isPublic Updated Name " +
            "from 2025-03-15T10:00 to 2025-03-15T11:00 with true";
    String editPubTrueResult = commandProcessor.processCommand(editPubTrueCommand);
    assertTrue("Edit isPublic to true should succeed",
            editPubTrueResult.contains("Successfully updated"));

    // Test editing isPublic property to false
    String editPubFalseCommand = "edit event isPublic Updated Name " +
            "from 2025-03-15T10:00 to 2025-03-15T11:00 with false";
    String editPubFalseResult = commandProcessor.processCommand(editPubFalseCommand);
    assertTrue("Edit isPublic to false should succeed",
            editPubFalseResult.contains("Successfully updated"));

    // Verify all properties were updated
    String printCommand = "print events on 2025-03-15";
    String printResult = commandProcessor.processCommand(printCommand);

    assertTrue("Updated name should be shown", printResult.contains("Updated Name"));
    assertTrue("Updated description should be shown", printResult.contains("Updated Description"));
    assertTrue("Updated location should be shown", printResult.contains("Updated Location"));
  }

  @Test
  public void testProcessCommand_EditEventWithMissingNewValue() {
    // Create an event
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00");

    // Try to edit without providing a new value
    String editCommand = "edit event description " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00";
    String editResult = commandProcessor.processCommand(editCommand);

    assertTrue("Should return error for missing new value",
            editResult.contains("Missing required name/newValue"));
  }
}