package eventcalendar.controller.commands;

import org.junit.Before;
import org.junit.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

import eventcalendar.controller.CommandProcessor;
import eventcalendar.controller.Controller;
import eventcalendar.controller.MockCalendar;
import eventcalendar.controller.MockCalendarManager;
import eventcalendar.controller.MockEvent;
import eventcalendar.model.Calendar;
import eventcalendar.model.CalendarManager;
import eventcalendar.model.Event;
import eventcalendar.model.ICalendar;
import eventcalendar.model.ICalendarManager;
import eventcalendar.model.ModelUtils;
import eventcalendar.view.View;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * This is a class to test the CopyEventCommand class.
 */
public class CopyEventCommandTest {
  private static final DateTimeFormatter DATE_TIME_FORMATTER =
          DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");

  private MockCalendar sourceCalendar;
  private MockCalendar targetCalendar;
  private CopyEventCommand copyEventCommand;
  private MockEvent testEvent;

  @Before
  public void setup() {
    // Setup test logging
    StringBuilder log = new StringBuilder();

    // Create mock calendar manager
    MockCalendarManager mockCalendarManager = new MockCalendarManager(log);

    // Create source calendar with test event
    sourceCalendar = new MockCalendar("Source Calendar", log);

    // Create the event to be copied
    LocalDateTime startTime = LocalDateTime.parse("2025-03-15T10:00", DATE_TIME_FORMATTER);
    LocalDateTime endTime = startTime.plusHours(1);
    testEvent = new MockEvent("Team Meeting", startTime, endTime)
            .withDescription("Test Description")
            .withLocation("Conference Room")
            .withIsPublic(true);

    // Add the event to source calendar
    sourceCalendar.addMockEvent(testEvent);

    // Create target calendar with different timezone
    targetCalendar = new MockCalendar("Target Calendar", log);
    targetCalendar.setTimeZone("Asia/Kolkata");

    // Add both calendars to the manager
    mockCalendarManager.addMockCalendar(sourceCalendar);
    mockCalendarManager.addMockCalendar(targetCalendar);

    // Create the command to test
    copyEventCommand = new CopyEventCommand(mockCalendarManager, sourceCalendar);

    // Initialize test objects
    ICalendarManager calendarManger = new CalendarManager();
    ICalendar calendar = new Calendar.Builder().build();
    Controller controller = new Controller(calendar);
    View view = new View();
    Consumer<ICalendar> updateCalendarConsumer = null;
    CommandProcessor commandProcessor = new CommandProcessor(calendarManger,
            updateCalendarConsumer, controller, calendar, view, "");
  }

  @Test
  public void testCopyEvent_NameMissing() {
    Map<String, String> args = new HashMap<>();
    args.put("object", "event");
    args.put("eventName", null);

    String result = copyEventCommand.execute(args);
    assertEquals("Event name cannot be empty", result);
  }

  @Test
  public void testCopyEvent_InvalidCopyCommand() {
    Map<String, String> args = new HashMap<>();
    args.put("object", "eventsss");

    String result = copyEventCommand.execute(args);
    assertEquals("Invalid copy command", result);

  }

  @Test
  public void testCopyEventDifferentTimezone() {
    Map<String, String> args = new HashMap<>();
    args.put("object", "event");
    args.put("eventName", "Team Meeting");
    args.put("sourceDateTime", "2025-03-15T10:00");
    args.put("targetCalendar", "Target Calendar");
    args.put("targetDateTime", "2025-03-15T15:00");

    String result = copyEventCommand.execute(args);

    assertEquals("Event copied successfully: Team Meeting", result);

    List<Event> targetEvents = targetCalendar.getEvents();
    assertEquals(1, targetEvents.size());

    Event copiedEvent = targetEvents.get(0);
    assertEquals("Team Meeting", copiedEvent.getEventName());

    LocalDateTime expectedStartTime = LocalDateTime.parse("2025-03-15T15:00",
            DATE_TIME_FORMATTER);
    assertEquals(expectedStartTime, copiedEvent.getEventStartDateTime());
  }

  @Test
  public void testCopyNonExistentEvent() {
    Map<String, String> args = new HashMap<>();
    args.put("object", "event");
    args.put("eventName", "Non-Existent Meeting");  // Event doesn't exist
    args.put("sourceDateTime", "2025-03-15T10:00");
    args.put("targetCalendar", "Target Calendar");
    args.put("targetDateTime", "2025-03-15T10:00");

    String result = copyEventCommand.execute(args);
    assertEquals(("No events found with name 'Non-Existent Meeting' s" +
            "tarting at the specified time."), result);

    // Verify no event was added to target calendar
    List<Event> targetEvents = targetCalendar.getEvents();
    assertEquals(0, targetEvents.size());
  }

  @Test
  public void testCopyToNonExistentCalendar() {
    Map<String, String> args = new HashMap<>();
    args.put("object", "event");
    args.put("eventName", "Team Meeting");
    args.put("sourceDateTime", "2025-03-15T10:00");
    args.put("targetCalendar", "Non-Existent Calendar");  // Calendar doesn't exist
    args.put("targetDateTime", "2025-03-15T10:00");

    String result = copyEventCommand.execute(args);
    assertEquals(("Target Calendar does not exist."), result);

    // Original calendar should still have the event
    List<Event> sourceEvents = sourceCalendar.getEvents();
    assertEquals(1, sourceEvents.size());
  }

  @Test
  public void testPreserveDuration() {
    LocalDateTime startTime = LocalDateTime.parse("2025-03-15T10:00", DATE_TIME_FORMATTER);
    LocalDateTime endTime = startTime.plusHours(2);  // 2-hour duration
    MockEvent longEvent = new MockEvent("Long Meeting", startTime, endTime);

    sourceCalendar.addMockEvent(longEvent);
    Map<String, String> args = new HashMap<>();
    args.put("object", "event");
    args.put("eventName", "Long Meeting");
    args.put("sourceDateTime", "2025-03-15T10:00");
    args.put("targetCalendar", "Target Calendar");
    args.put("targetDateTime", "2025-03-16T14:00");  // Different day and time

    String result = copyEventCommand.execute(args);
    assertTrue(result.contains("successfully"));

    // Check that the event was copied with the correct duration
    List<Event> targetEvents = targetCalendar.getEvents();

    // Find our copied event (there might be other events from other tests)
    Event copiedEvent = null;
    for (Event event : targetEvents) {
      if (event.getEventName().equals("Long Meeting")) {
        copiedEvent = event;
        break;
      }
    }

    assertNotNull("Copied event should be in target calendar", copiedEvent);

    LocalDateTime expectedStartTime = LocalDateTime.parse("2025-03-16T14:00",
            DATE_TIME_FORMATTER);
    assertEquals(expectedStartTime, copiedEvent.getEventStartDateTime());
    LocalDateTime expectedEndTime = expectedStartTime.plusHours(2);
    assertEquals(expectedEndTime, copiedEvent.getEventEndDateTime());
  }

  @Test
  public void testCopyEventWithConflict() {
    LocalDateTime conflictStartTime = LocalDateTime.parse("2025-03-15T10:00",
            DATE_TIME_FORMATTER);
    LocalDateTime conflictEndTime = conflictStartTime.plusHours(1);
    MockEvent conflictingEvent = new MockEvent("Existing Meeting", conflictStartTime,
            conflictEndTime)
            .withDescription("This will conflict")
            .withLocation("Same Room")
            .withIsPublic(true);

    targetCalendar.addMockEvent(conflictingEvent);

    Map<String, String> args = new HashMap<>();
    args.put("object", "event");
    args.put("eventName", "Team Meeting");
    args.put("sourceDateTime", "2025-03-15T10:00");
    args.put("targetCalendar", "Target Calendar");
    args.put("targetDateTime", "2025-03-15T10:00"); // Same time as conflicting event

    String result = copyEventCommand.execute(args);
    assertEquals("Could not copy event due to conflicts.", result);

    // Target calendar should still have only the original conflicting event
    List<Event> targetEvents = targetCalendar.getEvents();
    assertEquals(1, targetEvents.size());
    assertEquals("Existing Meeting", targetEvents.get(0).getEventName());
  }

  @Test
  public void testCopyEventWithQuotesInName() {
    LocalDateTime startTime = LocalDateTime.parse("2025-03-15T12:00", DATE_TIME_FORMATTER);
    LocalDateTime endTime = startTime.plusHours(1);
    MockEvent eventWithQuotes = new MockEvent("Team \"Quarterly\" Meeting", startTime,
            endTime)
            .withDescription("Meeting with quotes in name")
            .withLocation("Conference Room")
            .withIsPublic(true);

    sourceCalendar.addMockEvent(eventWithQuotes);
    Map<String, String> args = new HashMap<>();
    args.put("object", "event");
    args.put("eventName", "Team \"Quarterly\" Meeting"); // Note the quotes in name
    args.put("sourceDateTime", "2025-03-15T12:00");
    args.put("targetCalendar", "Target Calendar");
    args.put("targetDateTime", "2025-03-15T14:00");

    String result = copyEventCommand.execute(args);
    assertTrue(result.contains("successfully"));

    List<Event> targetEvents = targetCalendar.getEvents();

    Event copiedEvent = null;
    for (Event event : targetEvents) {
      if (event.getEventName().contains("Quarterly")) {
        copiedEvent = event;
        break;
      }
    }

    assertNotNull("Copied event with quotes should be in target calendar", copiedEvent);
    assertEquals("Team \"Quarterly\" Meeting", copiedEvent.getEventName());

    assertEquals("Meeting with quotes in name", copiedEvent.getEventDescription());
    assertEquals("Conference Room", copiedEvent.getEventLocation());
    assertTrue(copiedEvent.isPublic());
  }

  @Test
  public void testCopyEvents_DifferentTimezone() {
    Map<String, String> args = new HashMap<>();
    args.put("object", "events");
    args.put("sourceDate", "2025-03-15");
    args.put("targetDate", "2025-03-15");
    args.put("targetCalendar", "Target Calendar");

    addMultipleEvents();

    String result = copyEventCommand.execute(args);

    List<Event> targetEvents = targetCalendar.getEvents();
    assertEquals(5, targetEvents.size());

    Event copiedEvent = targetEvents.get(1);
    assertEquals("Team Meeting1", copiedEvent.getEventName());

    LocalDateTime expectedDateTime = LocalDateTime.parse("2025-03-15T21:30");
    assertEquals(expectedDateTime, copiedEvent.getEventStartDateTime());

    // event which is going onto the next day
    copiedEvent = targetEvents.get(4);
    assertEquals("Team Meeting4", copiedEvent.getEventName());

    expectedDateTime = LocalDateTime.parse("2025-03-16T10:00");
    assertEquals(expectedDateTime, copiedEvent.getEventEndDateTime());
  }

  @Test
  public void testCopyNonExistentEvents() {
    Map<String, String> args = new HashMap<>();
    args.put("object", "events");
    args.put("eventName", "Non-Existent Meeting");  // Event doesn't exist
    args.put("sourceDate", "2025-03-16");
    args.put("targetDate", "2025-03-16");
    args.put("targetCalendar", "Target Calendar");

    String result = copyEventCommand.execute(args);
    assertEquals(("No events found with specified startDate 2025-03-16"), result);

    // Verify no event was added to target calendar
    List<Event> targetEvents = targetCalendar.getEvents();
    assertEquals(0, targetEvents.size());
  }

  @Test
  public void testCopyEvents_AllDayEvents() {
    Map<String, String> args = new HashMap<>();
    args.put("object", "events");
    args.put("sourceDateFrom", "2025-03-15");
    args.put("sourceDateTo", "2025-03-16");
    args.put("targetStartDate", "2025-04-15");
    args.put("targetCalendar", "Target Calendar");

    LocalDateTime startTime = LocalDateTime.parse("2025-03-16T00:00", DATE_TIME_FORMATTER);
    LocalDateTime endTime = LocalDateTime.parse("2025-03-16T23:59", DATE_TIME_FORMATTER);
    testEvent = new MockEvent("Team Meeting1", startTime, endTime)
            .withDescription("Test Description")
            .withLocation("Conference Room")
            .withIsPublic(true);
    sourceCalendar.addMockEvent(testEvent);

    String result = copyEventCommand.execute(args);
    assertEquals("2 Event(s) copied successfully", result);
  }

  @Test
  public void testCopyEvents_from_to_exact() {
    Map<String, String> args = new HashMap<>();
    args.put("object", "events");
    args.put("sourceDateFrom", "2025-03-15");
    args.put("sourceDateTo", "2025-03-17");
    args.put("targetStartDate", "2025-04-15");
    args.put("targetCalendar", "Target Calendar");

    addMultipleEvents();

    String result = copyEventCommand.execute(args);

    System.out.println(result);

    List<Event> targetEvents = targetCalendar.getEvents();
    assertEquals(7, targetEvents.size());

    Event copiedEvent = targetEvents.get(0);
    assertEquals("Team Meeting", copiedEvent.getEventName());

    LocalDateTime expectedDateTime = LocalDateTime.parse("2025-04-15T19:30");
    assertEquals(expectedDateTime, copiedEvent.getEventStartDateTime());

    // event which is going onto the next day
    copiedEvent = targetEvents.get(4);
    assertEquals("Team Meeting4", copiedEvent.getEventName());

    expectedDateTime = LocalDateTime.parse("2025-04-16T10:00");
    assertEquals(expectedDateTime, copiedEvent.getEventEndDateTime());

    // event which is going onto the next day
    copiedEvent = targetEvents.get(6);
    assertEquals("Team Meeting6", copiedEvent.getEventName());

    expectedDateTime = LocalDateTime.parse("2025-04-18T10:00");
    assertEquals(expectedDateTime, copiedEvent.getEventEndDateTime());
  }

  @Test
  public void testCopyEvents_from_to_startBeforeExactDate() {
    Map<String, String> args = new HashMap<>();
    args.put("object", "events");
    args.put("sourceDateFrom", "2025-03-10");
    args.put("sourceDateTo", "2025-03-17");
    args.put("targetStartDate", "2025-04-15");
    args.put("targetCalendar", "Target Calendar");

    addMultipleEvents();

    String result = copyEventCommand.execute(args);

    List<Event> targetEvents = targetCalendar.getEvents();
    assertEquals(7, targetEvents.size());

    Event copiedEvent = targetEvents.get(0);
    assertEquals("Team Meeting", copiedEvent.getEventName());

    LocalDateTime expectedDateTime = LocalDateTime.parse("2025-04-20T19:30");
    assertEquals(expectedDateTime, copiedEvent.getEventStartDateTime());

    // event which is going onto the next day
    copiedEvent = targetEvents.get(4);
    assertEquals("Team Meeting4", copiedEvent.getEventName());

    expectedDateTime = LocalDateTime.parse("2025-04-21T10:00");
    assertEquals(expectedDateTime, copiedEvent.getEventEndDateTime());

    // event which is going onto the next day
    copiedEvent = targetEvents.get(6);
    assertEquals("Team Meeting6", copiedEvent.getEventName());

    expectedDateTime = LocalDateTime.parse("2025-04-23T10:00");
    assertEquals(expectedDateTime, copiedEvent.getEventEndDateTime());
  }

  private void addMultipleEvents() {
    // Create multiple events to be copied
    LocalDateTime startTime = LocalDateTime.parse("2025-03-15T12:00", DATE_TIME_FORMATTER);
    LocalDateTime endTime = startTime.plusHours(1);
    testEvent = new MockEvent("Team Meeting1", startTime, endTime)
            .withDescription("Test Description")
            .withLocation("Conference Room")
            .withIsPublic(true);
    sourceCalendar.addMockEvent(testEvent);

    // Create multiple events to be copied
    startTime = LocalDateTime.parse("2025-03-15T15:00", DATE_TIME_FORMATTER);
    endTime = startTime.plusHours(1);
    testEvent = new MockEvent("Team Meeting2", startTime, endTime)
            .withDescription("Test Description")
            .withLocation("Conference Room")
            .withIsPublic(true);
    sourceCalendar.addMockEvent(testEvent);

    // Create multiple events to be copied
    startTime = LocalDateTime.parse("2025-03-15T18:00", DATE_TIME_FORMATTER);
    endTime = startTime.plusHours(1);
    testEvent = new MockEvent("Team Meeting3", startTime, endTime)
            .withDescription("Test Description")
            .withLocation("Conference Room")
            .withIsPublic(true);
    sourceCalendar.addMockEvent(testEvent);

    // Create multiple events to be copied
    startTime = LocalDateTime.parse("2025-03-15T23:30", DATE_TIME_FORMATTER);
    endTime = startTime.plusHours(1);
    testEvent = new MockEvent("Team Meeting4", startTime, endTime)
            .withDescription("Test Description")
            .withLocation("Conference Room")
            .withIsPublic(true);
    sourceCalendar.addMockEvent(testEvent);

    // Create multiple events to be copied
    startTime = LocalDateTime.parse("2025-03-16T23:30", DATE_TIME_FORMATTER);
    endTime = startTime.plusHours(1);
    testEvent = new MockEvent("Team Meeting5", startTime, endTime)
            .withDescription("Test Description")
            .withLocation("Conference Room")
            .withIsPublic(true);
    sourceCalendar.addMockEvent(testEvent);

    // Create multiple events to be copied
    startTime = LocalDateTime.parse("2025-03-17T23:30", DATE_TIME_FORMATTER);
    endTime = startTime.plusHours(1);
    testEvent = new MockEvent("Team Meeting6", startTime, endTime)
            .withDescription("Test Description")
            .withLocation("Conference Room")
            .withIsPublic(true);
    sourceCalendar.addMockEvent(testEvent);
  }

  @Test
  public void testChangeEventTime_NullDescription() {
    // Create an event with null description but non-null location
    LocalDateTime startTime = LocalDateTime.parse("2025-03-15T12:00", DATE_TIME_FORMATTER);
    LocalDateTime endTime = startTime.plusHours(1);
    MockEvent eventWithNullDesc = new MockEvent("Team Meeting", startTime, endTime)
            .withDescription(null)
            .withLocation("Conference Room")
            .withIsPublic(true);

    // Directly call modelUtils
    boolean result = ModelUtils.changeEventTime(
            eventWithNullDesc,
            sourceCalendar,
            ZoneId.of("UTC"),
            ZoneId.of("America/New_York"),
            LocalDate.of(2025, 3, 15),
            LocalDate.of(2025, 3, 16)
    );

    assertTrue("Method should return true when successful", result);
  }

  @Test
  public void testChangeEventTimeEmptyDescription() {
    // Create event with empty description but valid location
    LocalDateTime startTime = LocalDateTime.parse("2025-03-15T10:00", DATE_TIME_FORMATTER);
    LocalDateTime endTime = startTime.plusHours(1);

    MockEvent eventWithEmptyDesc = new MockEvent("Test Event", startTime, endTime)
            .withDescription("")
            .withLocation("Test Location")
            .withIsPublic(true);

    // Directly call modelUtils
    boolean result = ModelUtils.changeEventTime(
            eventWithEmptyDesc,
            sourceCalendar,
            ZoneId.of("UTC"),
            ZoneId.of("America/New_York"),
            LocalDate.of(2025, 3, 15),
            LocalDate.of(2025, 3, 16)
    );

    assertTrue("Method should return true when successful", result);
  }

  @Test
  public void testChangeEventTime_NullLocation() {
    // Create an event with null description but non-null location
    LocalDateTime startTime = LocalDateTime.parse("2025-03-15T12:00", DATE_TIME_FORMATTER);
    LocalDateTime endTime = startTime.plusHours(1);
    MockEvent eventWithNullDesc = new MockEvent("Team Meeting", startTime, endTime)
            .withDescription("Test description")
            .withLocation(null)
            .withIsPublic(true);

    // Directly call modelUtils
    boolean result = ModelUtils.changeEventTime(
            eventWithNullDesc,
            sourceCalendar,
            ZoneId.of("UTC"),
            ZoneId.of("America/New_York"),
            LocalDate.of(2025, 3, 15),
            LocalDate.of(2025, 3, 16)
    );

    assertTrue("Method should return true when successful", result);
  }

  @Test
  public void testChangeEventTimeEmptyLocation() {
    // Create event with empty description but valid location
    LocalDateTime startTime = LocalDateTime.parse("2025-03-15T10:00", DATE_TIME_FORMATTER);
    LocalDateTime endTime = startTime.plusHours(1);

    MockEvent eventWithEmptyDesc = new MockEvent("Test Event", startTime, endTime)
            .withDescription("Not Null")
            .withLocation("")
            .withIsPublic(true);

    // Directly call modelUtils
    boolean result = ModelUtils.changeEventTime(
            eventWithEmptyDesc,
            sourceCalendar,
            ZoneId.of("UTC"),
            ZoneId.of("America/New_York"),
            LocalDate.of(2025, 3, 15),
            LocalDate.of(2025, 3, 16)
    );

    assertTrue("Method should return true when successful", result);
  }

  @Test
  public void testCopyEventsRange_MissingCalendarName() {
    Map<String, String> args = new HashMap<>();
    args.put("object", "events");
    args.put("sourceDateFrom", "2025-03-15");
    args.put("sourceDateTo", "2025-03-17");
    args.put("targetStartDate", "2025-04-15");
    // Missing targetCalendar parameter
    String result = copyEventCommand.execute(args);
    assertEquals("Calendar name cannot be empty", result);
  }

  @Test
  public void testCopyEventsRange_NonExistentTargetCalendar() {
    Map<String, String> args = new HashMap<>();
    args.put("object", "events");
    args.put("sourceDateFrom", "2025-03-15");
    args.put("sourceDateTo", "2025-03-17");
    args.put("targetStartDate", "2025-04-15");
    args.put("targetCalendar", "Non-Existent Calendar");
    String result = copyEventCommand.execute(args);
    assertEquals("Calendar name 'Non-Existent Calendar' does not exist", result);
  }

  @Test
  public void testCopyEventsRange_NoEventsFound() {
    Map<String, String> args = new HashMap<>();
    args.put("object", "events");
    args.put("sourceDateFrom", "2024-01-01"); // Date with no events
    args.put("sourceDateTo", "2024-01-10"); // Date with no events
    args.put("targetStartDate", "2025-04-15");
    args.put("targetCalendar", "Target Calendar");

    String result = copyEventCommand.execute(args);
    assertTrue(result.contains("No events found with specified time interval"));
  }

  @Test
  public void testCopyEventsOnDate_MissingCalendarName() {
    Map<String, String> args = new HashMap<>();
    args.put("object", "events");
    args.put("sourceDate", "2025-03-15");
    args.put("targetDate", "2025-04-15");
    String result = copyEventCommand.execute(args);
    assertEquals("Calendar name cannot be empty", result);
  }

  @Test
  public void testCopyEventsOnDate_NonExistentTargetCalendar() {
    Map<String, String> args = new HashMap<>();
    args.put("object", "events");
    args.put("sourceDate", "2025-03-15");
    args.put("targetDate", "2025-04-15");
    args.put("targetCalendar", "Non-Existent Calendar");
    String result = copyEventCommand.execute(args);
    assertEquals("Calendar name 'Non-Existent Calendar' does not exist", result);
  }

  @Test
  public void testCopySingleEvent_MissingCalendarName() {
    Map<String, String> args = new HashMap<>();
    args.put("object", "event");
    args.put("eventName", "Team Meeting");
    args.put("sourceDateTime", "2025-03-15T10:00");
    args.put("targetDateTime", "2025-03-15T10:00");
    String result = copyEventCommand.execute(args);
    assertEquals("Calendar name cannot be empty", result);
  }

}