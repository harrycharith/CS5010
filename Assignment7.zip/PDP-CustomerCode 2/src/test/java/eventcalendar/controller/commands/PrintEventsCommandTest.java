package eventcalendar.controller.commands;

import org.junit.Before;
import org.junit.Test;

import java.util.function.Consumer;

import eventcalendar.controller.CommandProcessor;
import eventcalendar.controller.Controller;
import eventcalendar.model.Calendar;
import eventcalendar.model.CalendarManager;
import eventcalendar.model.ICalendar;
import eventcalendar.model.ICalendarManager;
import eventcalendar.view.View;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Test class for PrintEventsCommand.
 */
public class PrintEventsCommandTest {

  // Test data
  private static final String TEST_EVENT_NAME = "Team Meeting";
  private CommandProcessor commandProcessor;

  @Before
  public void setup() {
    // Initialize test objects
    // Test objects
    ICalendarManager calendarManger = new CalendarManager();
    ICalendar calendar = new Calendar.Builder().build();
    Controller controller = new Controller(calendar);
    View view = new View();
    Consumer<ICalendar> updateCalendarConsumer = null;
    commandProcessor = new CommandProcessor(calendarManger,
            updateCalendarConsumer, controller, calendar, view, "");
  }

  @Test
  public void testProcessCommand_PrintSingleEvent() {
    // create single event to use in the test
    String command = "create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00 description " +
            "Test Description location Conference Room";

    String result = commandProcessor.processCommand(command);
    assertTrue(result.contains("successfully"));

    String print = "print events on 2025-03-15";
    String resultPrint = commandProcessor.processCommand(print);

    assertTrue(resultPrint.contains("Team Meeting (2025-03-15T10:00 to 2025-03-15T11:00)"));
  }

  @Test
  public void testProcessCommand_PrintMultipleEvents() {
    // Create multiple events
    commandProcessor.processCommand("create event " + TEST_EVENT_NAME +
            " from 2025-03-15T10:00 to 2025-03-15T11:00");
    commandProcessor.processCommand("create event Team Meeting1 " +
            "from 2025-03-15T10:00 to 2025-03-15T12:00");
    commandProcessor.processCommand("create event Team Meeting2" +
            " from 2025-03-16T10:00 to 2025-03-16T11:00");

    String print = "print events from 2025-03-15T10:00 to 2025-03-16T11:00";
    String resultPrint = commandProcessor.processCommand(print);

    assertTrue(resultPrint.contains("Team Meeting (2025-03-15T10:00 to 2025-03-15T11:00)"));
    // events can no longer conflict.
    assertFalse(resultPrint.contains("Team Meeting1 (2025-03-15T10:00 to 2025-03-15T12:00)"));
    assertTrue(resultPrint.contains("Team Meeting2 (2025-03-16T10:00 to 2025-03-16T11:00)"));
  }

  @Test
  public void testProcessCommand_PrintEventsInvalidPrintType() {
    // Test with an invalid print type
    String command = "print events something 2025-03-15";
    String result = commandProcessor.processCommand(command);

    // Verify error message is returned
    assertTrue("Should return error for invalid print type",
            result.contains("Invalid print type"));
  }

  @Test
  public void testProcessCommand_PrintEventsInvalidDateFormat() {
    // Test with an invalid date format
    String command = "print events on 03-15-2025"; // Wrong format, should be yyyy-MM-dd
    String result = commandProcessor.processCommand(command);

    // Verify error message is returned
    assertTrue("Should return error for invalid date format",
            result.contains("Error Parsing Date"));
  }

  @Test
  public void testProcessCommand_PrintEventsInvalidStartTimeFormat() {
    // Test with an invalid start time format
    String command = "print events from 2025/03/15T10:00 to 2025-03-16T11:00"; // Wrong format
    String result = commandProcessor.processCommand(command);

    // Verify error message is returned
    assertTrue("Should return error for invalid start time format",
            result.contains("Error Parsing Date"));
  }

  @Test
  public void testProcessCommand_PrintEventsInvalidEndTimeFormat() {
    // Test with an invalid end time format
    String command = "print events from 2025-03-15T10:00 to 2025/03/16T11:00"; // Wrong format
    String result = commandProcessor.processCommand(command);

    // Verify error message is returned
    assertTrue("Should return error for invalid end time format",
            result.contains("Error Parsing Date"));
  }

  @Test
  public void testProcessCommand_PrintEventsEndTimeBeforeStartTime() {
    // Test with end time before start time
    String command = "print events from 2025-03-16T10:00 to 2025-03-15T11:00";
    String result = commandProcessor.processCommand(command);

    // Verify error message is returned
    assertTrue("Should return error when end time is before start time",
            result.contains("End time cannot be before start time"));
  }

  @Test
  public void testProcessCommand_PrintEventsNoEventsOnDate() {
    // Test printing events on a date with no events
    String command = "print events on 2026-01-01"; // No events on this date
    String result = commandProcessor.processCommand(command);

    // Verify appropriate message is returned
    assertTrue("Should indicate no events found",
            result.contains("No events found on 2026-01-01"));
  }

  @Test
  public void testProcessCommand_PrintEventsNoEventsInInterval() {
    // Test printing events in an interval with no events
    String command = "print events from 2026-01-01T00:00 to 2026-01-02T00:00";
    // No events in this interval
    String result = commandProcessor.processCommand(command);

    // Verify appropriate message is returned
    assertTrue("Should indicate no events found in interval",
            result.contains("No events found between"));
  }

  @Test
  public void testProcessCommand_PrintEventsMissingDate() {
    // Test with missing date parameter
    String command = "print events on"; // Missing date
    String result = commandProcessor.processCommand(command);

    // Verify error message is returned
    assertTrue("Should return error for missing date",
            result.contains("Error"));
  }

  @Test
  public void testProcessCommand_PrintEventsMissingStartTime() {
    // Test with missing start time parameter
    String command = "print events from to 2025-03-16T11:00"; // Missing start time
    String result = commandProcessor.processCommand(command);

    // Verify error message is returned
    assertTrue("Should return error for missing start time",
            result.contains("Error"));
  }

  @Test
  public void testProcessCommand_PrintEventsMissingEndTime() {
    // Test with missing end time parameter
    String command = "print events from 2025-03-15T10:00 to"; // Missing end time
    String result = commandProcessor.processCommand(command);

    // Verify error message is returned
    assertTrue("Should return error for missing end time",
            result.contains("Error"));
  }

  @Test
  public void testProcessCommand_PrintEventsSpanningDate() {
    // Create an event that spans multiple days
    commandProcessor.processCommand("create event Multi-day Meeting from " +
            "2025-03-15T10:00 to 2025-03-17T11:00");

    // Print events on a day in the middle of the span
    String command = "print events on 2025-03-16";
    String result = commandProcessor.processCommand(command);

    // Verify the event is found even though it doesn't start or end on that day
    assertTrue("Should find event that spans over the specified date",
            result.contains("Multi-day Meeting"));
  }

  @Test
  public void testProcessCommand_PrintEventsPartiallyInInterval() {
    // Create events that partially overlap with the interval
    commandProcessor.processCommand("create event Before-During Event " +
            "from 2025-03-14T10:00 to 2025-03-15T11:00");
    commandProcessor.processCommand("create event During-After Event " +
            "from 2025-03-16T10:00 to 2025-03-17T11:00");

    // Print events in an interval that partially overlaps with both events
    String command = "print events from 2025-03-15T00:00 to 2025-03-16T23:59";
    String result = commandProcessor.processCommand(command);

    assertTrue("Should find event that starts before and ends during the interval",
            result.contains("Before-During Event"));
    assertTrue("Should find event that starts during and ends after the interval",
            result.contains("During-After Event"));
  }

  @Test
  public void testProcessCommand_PrintEventsWithEventStartingExactlyOnIntervalStart() {
    // Create an event that starts exactly at the interval start
    commandProcessor.processCommand("create event Boundary Start Event from " +
            "2025-03-15T10:00 to 2025-03-15T11:00");

    // Print events in an interval that starts exactly when the event starts
    String command = "print events from 2025-03-15T10:00 to 2025-03-15T12:00";
    String result = commandProcessor.processCommand(command);

    assertTrue("Should find event that starts exactly at interval start",
            result.contains("Boundary Start Event"));
  }

  @Test
  public void testProcessCommand_PrintEventsWithEventEndingExactlyOnIntervalEnd() {
    // Create an event that ends exactly at the interval end
    commandProcessor.processCommand("create event Boundary End Event from " +
            "2025-03-15T10:00 to 2025-03-15T11:00");

    // Print events in an interval that ends exactly when the event ends
    String command = "print events from 2025-03-15T09:00 to 2025-03-15T11:00";
    String result = commandProcessor.processCommand(command);

    assertTrue("Should find event that ends exactly at interval end",
            result.contains("Boundary End Event"));
  }

  @Test
  public void testProcessCommand_PrintEventsWithEventSpanningEntireInterval() {
    // Create an event that completely spans the interval
    commandProcessor.processCommand("create event Spanning Event from " +
            "2025-03-15T09:00 to 2025-03-15T12:00");

    // Print events in an interval that is completely within the event timespan
    String command = "print events from 2025-03-15T10:00 to 2025-03-15T11:00";
    String result = commandProcessor.processCommand(command);

    assertTrue("Should find event that completely spans the interval",
            result.contains("Spanning Event"));
  }

  @Test
  public void testProcessCommand_PrintEventsWithEventStartingOnDate() {
    // Create an event that starts on the specific date
    commandProcessor.processCommand("create event Start Date Event " +
            "from 2025-03-15T00:00 to 2025-03-16T00:00");

    // Print events on the start date
    String command = "print events on 2025-03-15";
    String result = commandProcessor.processCommand(command);

    assertTrue("Should find event that starts on the specified date",
            result.contains("Start Date Event"));
  }

  @Test
  public void testProcessCommand_PrintEventsWithEventEndingOnDate() {
    // Create an event that ends on the specific date
    commandProcessor.processCommand("create event End Date Event " +
            "from 2025-03-14T00:00 to 2025-03-15T23:59");

    // Print events on the end date
    String command = "print events on 2025-03-15";
    String result = commandProcessor.processCommand(command);

    assertTrue("Should find event that ends on the specified date",
            result.contains("End Date Event"));
  }

  @Test
  public void testProcessCommand_PrintEventsWithEventWithLocation() {
    // Create an event with a location
    commandProcessor.processCommand("create event Location Event from " +
            "2025-03-15T10:00 to 2025-03-15T11:00 location Conference Room");

    // Print events on that date
    String command = "print events on 2025-03-15";
    String result = commandProcessor.processCommand(command);

    assertTrue("Should include location in the output",
            result.contains("at Conference Room"));
  }

  @Test
  public void testProcessCommand_PrintEventsWithEventWithEmptyLocation() {
    // Create an event with an empty location string
    commandProcessor.processCommand("create event Empty Location " +
            "Event from 2025-03-15T10:00 to 2025-03-15T11:00 location \"\"");

    // Print events on that date
    String command = "print events on 2025-03-15";
    String result = commandProcessor.processCommand(command);

    assertTrue("Should find event with empty location",
            result.contains("Empty Location Event"));
    // The output should not contain " at " followed by nothing
    assertFalse("Should not include empty location in output",
            result.contains("Empty Location Event") && result.contains(" at \n"));
  }

  @Test
  public void testProcessCommand_PrintEventsWithEventWithDescription() {
    // Create an event with a description
    commandProcessor.processCommand("create event Description Event from " +
            "2025-03-15T10:00 to 2025-03-15T11:00 description Test Description");

    // Print events on that date
    String command = "print events on 2025-03-15";
    String result = commandProcessor.processCommand(command);

    assertTrue("Should include description in the output",
            result.contains("Description: Test Description"));
  }

  @Test
  public void testProcessCommand_PrintEventsWithEventWithEmptyDescription() {
    // Create an event with an empty description string
    commandProcessor.processCommand("create event Empty Description Event " +
            "from 2025-03-15T10:00 to 2025-03-15T11:00 description \"\"");

    // Print events on that date
    String command = "print events on 2025-03-15";
    String result = commandProcessor.processCommand(command);

    // Verify the event is found but no description is printed
    assertTrue("Should find event with empty description",
            result.contains("Empty Description Event"));
    // The output should not contain "Description: " followed by nothing
    assertFalse("Should not include empty description in output",
            result.contains("Empty Description Event") && result.contains("Description: \n"));
  }

  @Test
  public void testProcessCommand_PrintEventsWithNullPrintType() {
    // Create a command with a null print type (this would happen if the command is malformed)
    // We can't directly pass null, but we can test the behavior by using an invalid command format
    String command = "print events";
    String result = commandProcessor.processCommand(command);

    // Verify error message is returned
    assertTrue("Should return error for null print type",
            result.contains("Error") || result.contains("Invalid"));
  }

  @Test
  public void testProcessCommand_PrintEventsExactlyAtMidnight() {
    // Create an event that starts exactly at midnight
    commandProcessor.processCommand("create event Midnight " +
            "Event from 2025-03-15T00:00 to 2025-03-15T01:00");

    // Print events on that date
    String command = "print events on 2025-03-15";
    String result = commandProcessor.processCommand(command);

    assertTrue("Should find event starting at midnight",
            result.contains("Midnight Event"));
  }

  @Test
  public void testProcessCommand_PrintEventsExactlyAtEndOfDay() {
    // Create an event that ends exactly at the end of the day
    commandProcessor.processCommand("create event End of Day Event " +
            "from 2025-03-15T23:00 to 2025-03-15T23:59");

    // Print events on that date
    String command = "print events on 2025-03-15";
    String result = commandProcessor.processCommand(command);

    assertTrue("Should find event ending at end of day",
            result.contains("End of Day Event"));
  }

  @Test
  public void testProcessCommand_PrintEventsWithEventCompletelyOutsideInterval() {
    // Create an event that is completely outside the interval (ends before interval starts)
    commandProcessor.processCommand("create event Before " +
            "Interval Event from 2025-03-15T07:00 to 2025-03-15T08:00");

    // Create an event that is completely outside the interval (starts after interval ends)
    commandProcessor.processCommand("create event After " +
            "Interval Event from 2025-03-15T13:00 to 2025-03-15T14:00");

    // Print events in an interval that doesn't include either event
    String command = "print events from 2025-03-15T09:00 to 2025-03-15T12:00";
    String result = commandProcessor.processCommand(command);

    // Verify the events are NOT found (tests the negation of all conditions in the filter)
    assertFalse("Should NOT find event that ends before interval starts",
            result.contains("Before Interval Event"));
    assertFalse("Should NOT find event that starts after interval ends",
            result.contains("After Interval Event"));

    // Verify the correct message is shown
    assertTrue("Should show 'No events found' message",
            result.contains("No events found between"));
  }
}