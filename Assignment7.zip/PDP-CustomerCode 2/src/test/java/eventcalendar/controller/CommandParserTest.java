package eventcalendar.controller;

import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import eventcalendar.controller.parsers.CopyCommandParser;
import eventcalendar.controller.parsers.EditCommandParser;
import eventcalendar.controller.parsers.ParserUtils;
import eventcalendar.controller.parsers.PrintCommandParser;
import eventcalendar.controller.parsers.UseCommandParser;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

/**
 * This class test the functionality of the CommandParser class as a unit.
 */
public class CommandParserTest {
  private final EditCommandParser editparser = new EditCommandParser();
  private final UseCommandParser useparser = new UseCommandParser();
  // Test objects
  private CommandParser commandParse;
  private Map<String, String> resultMap;
  private PrintCommandParser printParser;

  @Before
  public void setup() {
    commandParse = new CommandParser();
    printParser = new PrintCommandParser();
    resultMap = new HashMap<>();
  }

  @Test
  public void testParseInvalidCommand() {
    String invalidCommand = "invalidCommand";
    try {
      commandParse.parseCommand(invalidCommand);
      fail("Expected IllegalArgumentException to be thrown");
    } catch (IllegalArgumentException e) {
      assertTrue(e.getMessage().contains("Unknown command: invalidCommand"));
    }
  }

  @Test
  public void testParseEmptyCommand() {
    String emptyCommand = "";
    try {
      commandParse.parseCommand(emptyCommand);
      fail("Expected IllegalArgumentException to be thrown for empty command");
    } catch (IllegalArgumentException e) {
      assertTrue(e.getMessage().contains("Unknown command:"));
    }
  }

  @Test
  public void testParseNullCommand() {
    try {
      commandParse.parseCommand(null);
      fail("Expected NullPointerException or IllegalArgumentException to be " +
              "thrown for null command");
    } catch (Exception e) {
      assertTrue(e instanceof NullPointerException || e instanceof
              IllegalArgumentException);
    }
  }

  @Test
  public void testParseCommandWithOnlyAction() {
    String incompleteCommand = "create";
    try {
      commandParse.parseCommand(incompleteCommand);
      fail("Expected IllegalArgumentException to be thrown for command with only action");
    } catch (IllegalArgumentException e) {
      assertTrue(e.getMessage().contains("Invalid"));
    }
  }

  @Test
  public void testParseCommandWithInvalidAction() {
    String[] invalidActions = {"delete event Team Meeting", "modify event Team Meeting"};

    for (String command : invalidActions) {
      try {
        commandParse.parseCommand(command);
        fail("Expected IllegalArgumentException to be thrown for: " + command);
      } catch (IllegalArgumentException e) {
        assertTrue("Error message should mention 'Invalid' for: " + command,
                e.getMessage().contains("Unknown command:"));
      }
    }
  }

  @Test
  public void testParseCommandWithInvalidObject() {
    String[] invalidObjects = {"create reminder Team Meeting", "create 123 Team Meeting"};

    for (String command : invalidObjects) {
      try {
        commandParse.parseCommand(command);
        fail("Expected IllegalArgumentException to be thrown for: " + command);
      } catch (IllegalArgumentException e) {
        assertTrue("Error message should mention 'Invalid' for: " + command,
                e.getMessage().contains("Invalid"));
      }
    }
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseCreate1WordInCommands() {
    String invalidCommand = "create";
    commandParse.parseCommand(invalidCommand);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseCreate2WordInCommands() {
    String invalidCommand = "create event";
    commandParse.parseCommand(invalidCommand);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseInValidCreateCommandFrom() {
    String cmd = "create event Meeting from ";

    commandParse.parseCommand(cmd);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseInValidCreateCommandTo() {
    String cmd = "create event Meeting from 2024-03-04T10:00 to";

    commandParse.parseCommand(cmd);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseInValidCreateCommandOn() {
    String cmd = "create event Meeting on ";

    commandParse.parseCommand(cmd);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseInvalidExportCommand1() {
    String cmd = "export cal ";
    commandParse.parseCommand(cmd);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseInvalidShowCommand1() {
    String cmd = "show status on ";
    commandParse.parseCommand(cmd);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseInvalidCreateCalendarCommand1() {
    String cmd = "create calendar Meeting";
    commandParse.parseCommand(cmd);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testParseInvalidEditCalendarCommand1() {
    String cmd = "edit calendar Meeting";
    commandParse.parseCommand(cmd);
  }

  @Test
  public void testParseValidCreateCommand1() {
    String cmd = "create event Birthday on 2024-12-25";
    Map<String, String> expectedResult = new HashMap<>();
    expectedResult.put("autoDecline", "True");
    expectedResult.put("eventName", "Birthday");
    expectedResult.put("date", "2024-12-25");
    expectedResult.put("command", "create");
    expectedResult.put("object", "event");

    Map<String, String> actualResult = commandParse.parseCommand(cmd);

    assertEquals(expectedResult, actualResult);
  }

  @Test
  public void testParseValidCreateCommand2() {
    String cmd = "create event Meeting from 2024-03-04T10:00 to 2024-03-04T11:00";
    Map<String, String> expectedResult = new HashMap<>();
    expectedResult.put("autoDecline", "True");
    expectedResult.put("eventName", "Meeting");
    expectedResult.put("startTime", "2024-03-04T10:00");
    expectedResult.put("endTime", "2024-03-04T11:00");
    expectedResult.put("command", "create");
    expectedResult.put("object", "event");

    Map<String, String> actualResult = commandParse.parseCommand(cmd);

    assertEquals(expectedResult, actualResult);
  }


  @Test
  public void testParseValidEditCommand2() {
    String cmd = "edit events name Project with Updated Project";
    Map<String, String> expectedResult = new HashMap<>();
    expectedResult.put("eventName", "Project");
    expectedResult.put("newValue", "Updated Project");
    expectedResult.put("property", "name");
    expectedResult.put("command", "edit");
    expectedResult.put("object", "events");

    Map<String, String> actualResult = commandParse.parseCommand(cmd);

    assertEquals(expectedResult, actualResult);
  }

  @Test
  public void testParseValidExportCommand1() {
    String cmd = "export cal calendar_backup.csv";
    Map<String, String> expectedResult = new HashMap<>();
    expectedResult.put("fileName", "calendar_backup.csv");
    expectedResult.put("command", "export");
    expectedResult.put("action", "cal");

    Map<String, String> actualResult = commandParse.parseCommand(cmd);

    assertEquals(expectedResult, actualResult);
  }

  @Test
  public void testParseValidShowCommand1() {
    String cmd = "show status on 2024-03-04T10:00";
    Map<String, String> expectedResult = new HashMap<>();
    expectedResult.put("time", "2024-03-04T10:00");
    expectedResult.put("command", "show");
    expectedResult.put("action", "status");

    Map<String, String> actualResult = commandParse.parseCommand(cmd);

    assertEquals(expectedResult, actualResult);
  }

  @Test
  public void testParseValidPrintCommand1() {
    String cmd = "print events from 2024-03-04T10:00 to 2024-03-05T11:00";
    Map<String, String> expectedResult = new HashMap<>();
    expectedResult.put("printType", "interval");
    expectedResult.put("startTime", "2024-03-04T10:00");
    expectedResult.put("endTime", "2024-03-05T11:00");
    expectedResult.put("command", "print");
    expectedResult.put("object", "events");

    Map<String, String> actualResult = commandParse.parseCommand(cmd);

    assertEquals(expectedResult, actualResult);
  }

  @Test
  public void testParseCreateCalendarCommand_ValidWithName() {
    String cmd = "create calendar --name Personal Calendar --timezone Europe/Paris";
    Map<String, String> expectedResult = new HashMap<>();
    expectedResult.put("command", "create");
    expectedResult.put("object", "calendar");
    expectedResult.put("calendarName", "Personal Calendar");
    expectedResult.put("calendarTimeZone", "Europe/Paris");

    Map<String, String> actualResult = commandParse.parseCommand(cmd);

    assertEquals(expectedResult, actualResult);
  }

  @Test
  public void testParseEditCalendarCommand_ValidWithName() {
    String cmd = "edit calendar --name Personal Calendar --property name Edited Calendar";
    Map<String, String> expectedResult = new HashMap<>();
    expectedResult.put("command", "edit");
    expectedResult.put("object", "calendar");
    expectedResult.put("calendarName", "Personal Calendar");
    expectedResult.put("property", "name");
    expectedResult.put("newValue", "Edited Calendar");

    Map<String, String> actualResult = commandParse.parseCommand(cmd);

    assertEquals(expectedResult, actualResult);
  }

  @Test
  public void testParseUseCalendarCommand_ValidWithName() {
    String cmd = "use calendar --name Personal Calendar";
    Map<String, String> expectedResult = new HashMap<>();
    expectedResult.put("command", "use");
    expectedResult.put("object", "calendar");
    expectedResult.put("calendarName", "Personal Calendar");

    Map<String, String> actualResult = commandParse.parseCommand(cmd);

    assertEquals(expectedResult, actualResult);
  }

  @Test
  public void testParseCopyEventCommand_ValidWithName() {
    String cmd = "copy event Test Event on 2024-03-04T10:00 --target Personal Calendar " +
            "to 2024-03-04T10:00";
    Map<String, String> expectedResult = new HashMap<>();
    expectedResult.put("command", "copy");
    expectedResult.put("object", "event");
    expectedResult.put("sourceDateTime", "2024-03-04T10:00");
    expectedResult.put("targetDateTime", "2024-03-04T10:00");
    expectedResult.put("targetCalendar", "Personal Calendar");
    expectedResult.put("eventName", "Test Event");

    Map<String, String> actualResult = commandParse.parseCommand(cmd);

    assertEquals(expectedResult, actualResult);
  }

  @Test
  public void testParseCopyEventsCommand_Valid() {
    String cmd = "copy events on 2024-03-04 --target Personal Calendar " +
            "to 2024-03-04";
    Map<String, String> expectedResult = new HashMap<>();
    expectedResult.put("command", "copy");
    expectedResult.put("object", "events");
    expectedResult.put("sourceDate", "2024-03-04");
    expectedResult.put("targetDate", "2024-03-04");
    expectedResult.put("targetCalendar", "Personal Calendar");

    Map<String, String> actualResult = commandParse.parseCommand(cmd);

    assertEquals(expectedResult, actualResult);
  }

  @Test
  public void testParseCopyEventsCommand_Valid2() {
    String cmd = "copy events between 2024-03-04 and 2024-03-05 --target New Calendar to " +
            "2024-03-04";
    Map<String, String> expectedResult = new HashMap<>();
    expectedResult.put("command", "copy");
    expectedResult.put("object", "events");
    expectedResult.put("sourceDateTo", "2024-03-05");
    expectedResult.put("sourceDateFrom", "2024-03-04");
    expectedResult.put("targetStartDate", "2024-03-04");
    expectedResult.put("targetCalendar", "New Calendar");

    Map<String, String> actualResult = commandParse.parseCommand(cmd);

    assertEquals(expectedResult, actualResult);
  }


  // new testing method

  @Test
  public void testParseWithInsufficientCommandParts() {
    String[] commandParts = new String[]{"copy"};
    try {
      new CopyCommandParser().parse(commandParts);
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertTrue(e.getMessage().contains("missing object type"));
    }
  }

  @Test
  public void testParseInvalidObjectAfterCopy() {
    String[] commandParts = new String[]{"copy", "invalid"};
    try {
      new CopyCommandParser().parse(commandParts);
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertTrue(e.getMessage().contains("Invalid Copy Command after"));
    }
  }

  @Test
  public void testParseMissingSourceDate() {
    String[] commandParts = new String[]{"copy", "events", "between"};
    try {
      new CopyCommandParser().parse(commandParts);
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertTrue(e.getMessage().contains("Missing date after 'between'"));
    }
  }

  @Test
  public void testParseMissingSourceDateTo() {
    String[] commandParts = new String[]{"copy", "events", "between", "2024-03-04"};
    try {
      new CopyCommandParser().parse(commandParts);
      fail("Expected IllegalArgumentException");
    } catch (ArrayIndexOutOfBoundsException e) {
      assertTrue(e.getMessage().contains("Index 4 out of bounds for length 4"));
    }
  }

  // mutation specific checks for parser

  @Test
  public void testExtractQuotedStrings_SingleQuoteComplete() {
    String[] commandParts = {"before", "\"quoted\"", "after"};
    List<String> results = ParserUtils.extractQuotedStrings(commandParts, 0);
    assertEquals(1, results.size());
    assertEquals("quoted", results.get(0));
  }

  @Test
  public void testParseOnTargetToPattern_ReturnValueCheck() {
    String[] commandParts = {"copy", "events", "on", "2023-10-20", "--target",
                                "Calendar", "to", "2023-10-21"};
    int idx = 2;
    int resultIdx = ParserUtils.parseOnTargetToPattern(commandParts, idx, resultMap, false);
    assertTrue("Return value should not be 0", resultIdx != 0);
    assertEquals("Return value should be the updated index", 8, resultIdx);
  }

  @Test
  public void testParseOnTargetToPattern_ToParameterBoundaryCheck() {
    String[] commandParts = {"copy", "events", "on", "2023-10-20", "--target", "Calendar", "to"};
    int idx = 2;
    try {
      ParserUtils.parseOnTargetToPattern(commandParts, idx, resultMap, false);
      fail("Expected exception when 'to' is the last element");
    } catch (IllegalArgumentException e) {
      assertTrue(e.getMessage().contains("Missing target date"));
    }
  }

  @Test
  public void testParseOnTargetToPattern_TargetParamExactBoundary() {
    String[] commandParts = {"copy", "events", "on", "2023-10-20", "--target"};
    int idx = 2;
    try {
      ParserUtils.parseOnTargetToPattern(commandParts, idx, resultMap, false);
      fail("Expected exception when --target is the last element");
    } catch (IllegalArgumentException e) {
      assertTrue(e.getMessage().contains("Missing calendar name"));
    }
  }

  @Test
  public void testParseOnTargetToPattern_ArrayExactBoundary() {
    String[] commandParts = {"copy", "events"};
    int idx = 2; // Exactly at boundary
    try {
      ParserUtils.parseOnTargetToPattern(commandParts, idx, resultMap, false);
      fail("Expected exception at array boundary");
    } catch (IllegalArgumentException e) {
      assertTrue(e.getMessage().contains("Date and time information is not provided"));
    }
  }

  @Test
  public void testCommandPartsLengthExactlyEqualsIdx() {
    // Create a command array with length exactly equal to idx
    String[] commandParts = {"print"};
    Map<String, String> result = printParser.parse(commandParts);

    // Should still return a map with the command key set
    assertNotNull(result);
    assertEquals("print", result.get("command"));
    // But no other keys should be set since the condition fails
    assertNull(result.get("object"));
  }

  @Test
  public void testIdxExactlyEqualsCommandPartsLength() {
    // Create a command array where idx will be exactly equal to length
    String[] commandParts = {"print", "events"};
    Map<String, String> result = printParser.parse(commandParts);

    // Should still have object set but no printType since the next check fails
    assertEquals("events", result.get("object"));
    assertNull(result.get("printType"));
  }

  @Test
  public void testInvalidPrintCommands() {
    // Test with invalid object
    String[] invalidObjectCmd = {"print", "invalid"};
    Map<String, String> result1 = printParser.parse(invalidObjectCmd);
    assertEquals("print", result1.get("command"));
    assertNull(result1.get("object"));

    // Test with invalid format after events
    String[] invalidFormatCmd = {"print", "events", "invalid"};
    Map<String, String> result2 = printParser.parse(invalidFormatCmd);
    assertEquals("events", result2.get("object"));
    assertNull(result2.get("printType"));
  }

  @Test
  public void testCanHandle() {
    assertTrue(printParser.canHandle("print"));
    assertFalse(printParser.canHandle("not-print"));
    assertFalse(printParser.canHandle(null));
  }

  @Test
  public void testStartTimeWithoutTo() {
    // Create a command where idx+1 is exactly equal to length
    String[] commandParts = {"print", "events", "from", "2024-03-04T10:00"};
    Map<String, String> result = printParser.parse(commandParts);

    // Should have startTime set but to/endTime not processed
    assertEquals("events", result.get("object"));
    assertEquals("interval", result.get("printType"));
    assertEquals("2024-03-04T10:00", result.get("startTime"));
    assertNull(result.get("endTime"));
  }

  @Test
  public void testParseEditCalendarPropertyMissingValue() {
    String[] commandParts = {"edit", "calendar", "--name", "Test Calendar", "--property", "name"};
    try {
      editparser.parse(commandParts);
      fail("Should throw exception when property value is missing");
    } catch (IllegalArgumentException e) {
      assertTrue(e.getMessage().contains("Missing new value after property name"));
    }
  }

  @Test
  public void testEditCalendarMissingPropertyParameter() {
    String[] commandParts = {"edit", "calendar", "--name", "Test Calendar"};
    try {
      editparser.parse(commandParts);
      fail("Should throw exception when property parameter is missing");
    } catch (IllegalArgumentException e) {
      assertTrue(e.getMessage().contains("Property must be provided"));
    }
  }

  @Test
  public void testEditParserWithJustEdit() {
    String[] commandParts = {"edit"};
    try {
      editparser.parse(commandParts);
      fail("Should throw exception when index equals array length");
    } catch (IllegalArgumentException e) {
      assertTrue(e.getMessage().contains("Invalid command"));
    }
  }

  @Test
  public void testNonNameParameterParsing() {

    String[] commandParts = {"use", "calendar", "not-name-param", "--name", "Test Calendar"};
    Map<String, String> result = useparser.parse(commandParts);

    assertEquals("use", result.get("command"));
    assertEquals("calendar", result.get("object"));
    assertEquals("Test Calendar", result.get("calendarName"));
  }

}