# Event Calendar USEME

## 1. Create event action:-
![Create Event 1](<EventCalSS at 18.15.48.png>)
![Create Event 2](<EventCalSS at 18.15.53.png>)
![Create Event 3](<EventCalSS at 18.16.07.png>)
- Clickling on a day will open up the "Create Event Dialog".
- Here there are 3 options here, for the first action, we can either create a single event or recurring event.
- We have created a single event in the screenshots.
- Clicking again on the day will show the events scheduled on that day.

## 2. Edit event action:-
![Edit Event 1](<EventCalSS at 18.16.12.png>)
![Edit Event 2](<EventCalSS at 18.16.17.png>)
![Edit Event 3](<EventCalSS at 18.16.26.png>)
- Clickling on a day will open up the "Create Event Dialog".
- Here there are 3 options here, for this action, we will be editing a event.
- Upon clicking the Edit event button, the user will be show the events scheduled for the day.
- Upon selecting the event, the user will be given a choice to either edit a single event or all events with the same name.
- The user can edit either the name, description, location of the event.

## 3. Import csv:
![Create New Calendar](<EventCalSS at 18.17.00.png>)
-⁠ ⁠Click on the 'Import CSV' button at the top right corner of the application.
-⁠ ⁠A new dialog box will open up as a file explorer.
-⁠ ⁠Select the csv file to import events.
-⁠ ⁠A dialog box will appear indicating how many events were imported.

## 4. Export CSV:
![Create New Calendar](<EventCalSS at 18.17.04.png>)
-⁠ ⁠Select the calendar from which you want to export all the events.
-⁠ ⁠Click on the 'Export CSV' button at the top right corner of the application.
-⁠ ⁠This will download all the events of the selected calendar as a csv file tom be used in Google Calendar.
-⁠ ⁠A dialog box will let you know when the csv file is exported.

## 5. Create New Calendar:
![Create New Calendar](<EventCalSS at 18.16.39.png>)
-⁠ ⁠Click on the 'New Calendar' button at the top right side of the application.
-⁠ ⁠Add the calendar name and the calendar timezone.
-⁠ ⁠Click 'OK' to add the calendar.
-⁠ ⁠A dialog box will be displayed indicating if the calendar was created or not.

## 6. Change current calendar:
![Create New Calendar](<EventCalSS at 18.17.08.png>)
-⁠ ⁠Click on the drop down button next to 'Calendar:' at the top of the application.
-⁠ ⁠Select the calendar to used.
-⁠ ⁠The calendar will be switched to the selected one and will also be indicated by  a change of color.

## 7. 'Previous', 'Today' and 'Next' button:
- Use these buttons to navigate to the previous month, to the current date or to the next month respectively.