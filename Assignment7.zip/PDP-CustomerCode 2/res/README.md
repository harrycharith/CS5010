## How to run the program.

1. Navigate to res folder
```
cd res/
```

2. Use the following command to run the jar - you have multiple modes for it- 
For interactive mode
```
java -jar EventsCalendar-PDP.jar --mode interactive
```
or for headless mode
```
java -jar EventsCalendar-PDP.jar --mode headless <txt-file>
```
or for GUI mode
```
java -jar EventsCalendar-PDP.jar
```

## Which features work
- All the features listed in the Assignment description work. Namely :-
(valid_commands.txt has all the valid commands)
1. create
2. edit
3. print
4. export
5. show
6. copy
7. use

## Contribution - Updated
- Rohan (move to interfaces and factory, copy event(s) command)
- Tejas (create cal and use cal command, ModelUtils)

## Changes
- Main
  - We moved the methods that drove the interactive and headless mode to the controller/Controller class. This was done to place all the logic of running the different modes in Controller a we are following MVC model.
  - Separation of Concerns.
- CalendarManager
  - Added a concrete class that implements the ICalendarManager interface.
  - This was added to manage several calenders and separate this concern from the calender class.
- ICalendarManager
  - Interface for building calender managers.
  - Built an interface as it could be replicated for another use case.
- ICalendar
  - Interface for building calenders.
  - Built an interface as it could be replicated for another use case.
- ModelUtils
  - Added all the utility methods in a single place.
  - The method in this class are being used in many other classes.
  - Code reuse.
- AbstractCommand
  - Added this abstract class to define the common commands used in several command classes.
  - Code reuse.
- Business logic
  - Moved the logic of handling events and internal attributes from controller to the model as we are using the MVC model.
  - MVC model.
- Moved the parser to use factory strategy
  - Previously all the commandParser were in one file, causing the file to be very big and had too much logic in it.
  - With the Factory pattern each command has its own parser, so there is separation of concern.
  - All parser classes implement a single interface.
  - Utils file stores all common logic, used across all parsers.
- Added mocks for Calendar, CalendarManager and Event so the controller can be tested in isolation.
