package util;

import java.io.File;
import java.time.LocalDateTime;
import java.time.ZoneId;

import model.Calendar;
import model.Event;
import org.junit.Test;

import static org.junit.Assert.assertTrue;

/**
 * Unit tests for the CSVExporter class.
 */
public class CSVExporterTest {
  /**
   * Tests exporting a calendar to a CSV file and verifying file creation.
   */
  @Test
  public void testExportToCSV() {
    Calendar calendar = new Calendar("America/New_York", ZoneId.of("UTC"));  // Fixed: Provide timezone
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    Event event = new Event("Meeting", start, end, "Team meeting",
            "Room 1", true);
    calendar.addEvent(event);

    String filePath = "test_calendar.csv";
    CSVExporter.exportToCSV(calendar, filePath);

    assertTrue(new File(filePath).exists());
  }

  /**
   * Tests copying events on a specific date to another calendar and exporting it.
   */
  @Test
  public void testCopyEventsOnDateAndExport() {
    Calendar sourceCalendar = new Calendar("America/New_York", ZoneId.of("UTC"));  // Fixed: Provide timezone
    Calendar targetCalendar = new Calendar("Europe/London", ZoneId.of("UTC"));     // Fixed: Provide timezone

    LocalDateTime sourceStart = LocalDateTime.of(2025, 10, 15,
            14, 0);
    LocalDateTime sourceEnd = LocalDateTime.of(2025, 10, 15,
            15, 0);
    Event event = new Event("Meeting", sourceStart, sourceEnd, "Team meeting",
            "Room 1", true);
    sourceCalendar.addEvent(event);

    LocalDateTime targetStart = LocalDateTime.of(2025, 10, 16,
            0, 0);
    sourceCalendar.copyEventsOnDate(sourceStart, targetStart, targetCalendar);

    String filePath = "test_target_calendar.csv";
    CSVExporter.exportToCSV(targetCalendar, filePath);

    assertTrue(new File(filePath).exists());
    assertTrue(targetCalendar.getEventsOnDate(targetStart).size() == 1);
    Event copiedEvent = targetCalendar.getEventsOnDate(targetStart).get(0);
    assertTrue(copiedEvent.getStartDateTime().equals(LocalDateTime.of(2025, 10,
            16, 14, 0)));
    assertTrue(copiedEvent.getEndDateTime().equals(LocalDateTime.of(2025, 10,
            16, 15, 0)));
  }

  /**
   * Tests copying events within a range to another calendar and exporting it.
   */
  @Test
  public void testCopyEventsInRangeAndExport() {
    Calendar sourceCalendar = new Calendar("America/New_York", ZoneId.of("UTC"));  // Fixed: Provide timezone
    Calendar targetCalendar = new Calendar("Asia/Tokyo", ZoneId.of("UTC"));        // Fixed: Provide timezone

    LocalDateTime start1 = LocalDateTime.of(2025, 10, 15, 14,
            0);
    LocalDateTime end1 = LocalDateTime.of(2025, 10, 15, 15, 0);
    Event event1 = new Event("Meeting1", start1, end1, "Team meeting 1",
            "Room 1", true);
    sourceCalendar.addEvent(event1);

    LocalDateTime start2 = LocalDateTime.of(2025, 10, 16, 10,
            0);
    LocalDateTime end2 = LocalDateTime.of(2025, 10, 16, 11, 0);
    Event event2 = new Event("Meeting2", start2, end2, "Team meeting 2",
            "Room 2", true);
    sourceCalendar.addEvent(event2);

    LocalDateTime rangeStart = LocalDateTime.of(2025, 10, 15, 0,
            0);
    LocalDateTime rangeEnd = LocalDateTime.of(2025, 10, 16, 23,
            59);
    LocalDateTime targetStart = LocalDateTime.of(2025, 10, 20, 0,
            0);
    sourceCalendar.copyEventsInRange(rangeStart, rangeEnd, targetStart, targetCalendar);

    String filePath = "test_range_calendar.csv";
    CSVExporter.exportToCSV(targetCalendar, filePath);

    assertTrue(new File(filePath).exists());
    assertTrue(targetCalendar.getAllEvents().size() == 2);

    Event copiedEvent1 = targetCalendar.getEventsOnDate(LocalDateTime.of(2025, 10,
            20, 0, 0)).get(0);
    assertTrue(copiedEvent1.getStartDateTime().equals(LocalDateTime.of(2025, 10,
            20, 14, 0)));
    assertTrue(copiedEvent1.getEndDateTime().equals(LocalDateTime.of(2025, 10,
            20, 15, 0)));

    Event copiedEvent2 = targetCalendar.getEventsOnDate(LocalDateTime.of(2025, 10,
            21, 0, 0)).get(0);
    assertTrue(copiedEvent2.getStartDateTime().equals(LocalDateTime.of(2025, 10,
            21, 10, 0)));
    assertTrue(copiedEvent2.getEndDateTime().equals(LocalDateTime.of(2025, 10,
            21, 11, 0)));
  }

  /**
   * Tests that copying an event with a conflict fails and does not export an invalid state.
   */
  @Test
  public void testCopyEventWithConflict() {
    Calendar sourceCalendar = new Calendar("America/New_York", ZoneId.of("UTC"));  // Fixed: Provide timezone
    Calendar targetCalendar = new Calendar("America/New_York", ZoneId.of("UTC"));  // Fixed: Provide timezone

    LocalDateTime sourceStart = LocalDateTime.of(2025, 10, 15, 14,
            0);
    LocalDateTime sourceEnd = LocalDateTime.of(2025, 10, 15, 15,
            0);
    Event event = new Event("Meeting", sourceStart, sourceEnd, "Team meeting",
            "Room 1", true);
    sourceCalendar.addEvent(event);

    LocalDateTime conflictingStart = LocalDateTime.of(2025, 10, 16, 14,
            30);
    LocalDateTime conflictingEnd = LocalDateTime.of(2025, 10, 16, 15,
            30);
    Event conflictingEvent = new Event("Conflict", conflictingStart, conflictingEnd,
            "Conflict meeting", "Room 2", true);
    targetCalendar.addEvent(conflictingEvent);

    LocalDateTime targetStart = LocalDateTime.of(2025, 10, 16, 0,
            0);
    try {
      sourceCalendar.copyEventsOnDate(sourceStart, targetStart, targetCalendar);
    } catch (IllegalArgumentException e) {
      assertTrue(e.getMessage().contains("conflict"));
    }

    String filePath = "test_conflict_calendar.csv";
    CSVExporter.exportToCSV(targetCalendar, filePath);
    assertTrue(new File(filePath).exists());
    assertTrue(targetCalendar.getAllEvents().size() == 1);
  }
}