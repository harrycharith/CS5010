package model;

import java.time.LocalDateTime;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

/**
 * Unit tests for the Event class.
 */
public class EventTest {
  /**
   * Tests creating an event and verifying its properties.
   */
  @Test
  public void testEventCreation() {
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    Event event = new Event("Meeting", start, end, "Team meeting",
            "Room 1", true);

    assertEquals("Meeting", event.getSubject());
    assertEquals(start, event.getStartDateTime());
    assertEquals(end, event.getEndDateTime());
    assertEquals("Team meeting", event.getDescription());
    assertEquals("Room 1", event.getLocation());
    assertTrue(event.isPublic());
  }

  /**
   * Tests creating an all-day event and verifying its properties.
   */
  @Test
  public void testAllDayEvent() {
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 0, 0);
    Event event = new Event("All Day Event", start, null, "Holiday",
            "Home", false);

    assertNull(event.getEndDateTime());
    assertEquals("All Day Event", event.getSubject());
    assertFalse(event.isPublic());
  }

  /**
   * Tests the conflictsWith method with overlapping, non-overlapping, and all-day events.
   */
  @Test
  public void testConflictsWith() {
    Event event1 =
            new Event(
                    "Meeting",
                    LocalDateTime.of(2025, 10, 15, 14, 0),
                    LocalDateTime.of(2025, 10, 15, 15, 0),
                    "Team meeting",
                    "Room 1",
                    true);
    Event event2 =
            new Event(
                    "Workshop",
                    LocalDateTime.of(2025, 10, 15, 14, 30),
                    LocalDateTime.of(2025, 10, 15, 16, 0),
                    "Java Workshop",
                    "Room 2",
                    true);
    Event event3 =
            new Event(
                    "Lunch",
                    LocalDateTime.of(2025, 10, 15, 12, 0),
                    LocalDateTime.of(2025, 10, 15, 13, 0),
                    "Lunch break",
                    "Cafeteria",
                    true);
    Event allDayEvent =
            new Event(
                    "Holiday",
                    LocalDateTime.of(2025, 10, 15, 0, 0),
                    null,
                    "Company holiday",
                    "N/A",
                    true);

    assertTrue(event1.conflictsWith(event2));
    assertFalse(event1.conflictsWith(event3));
    assertTrue(event1.conflictsWith(allDayEvent));
    assertTrue(allDayEvent.conflictsWith(event2));
  }

  /**
   * Tests the toString method for regular and all-day events.
   */
  @Test
  public void testToString() {
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    Event event = new Event("Meeting", start, end, "Team meeting",
            "Room 1", true);

    String expected =
            "Event: Meeting, Start: 2025-10-15T14:00, End: 2025-10-15T15:00, Location: Room 1";
    assertEquals(expected, event.toString());

    LocalDateTime allDayStart = LocalDateTime.of(2025, 10, 15, 0,
            0);
    Event allDayEvent = new Event("Holiday", allDayStart, null,
            "Company holiday", "N/A", true);
    String allDayExpected = "Event: Holiday, Start: 2025-10-15T00:00, End: All Day, Location: N/A";
    assertEquals(allDayExpected, allDayEvent.toString());
  }
}