package model;

import java.io.File;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Unit tests for the Calendar class.
 */
public class CalendarTest {

  private Calendar calendar;

  @Before
  public void setUp() {
    calendar = new Calendar("America/New_York", ZoneId.of("UTC"));
  }

  @After
  public void tearDown() {
    // Clean up any temporary files created during tests
    File file = new File("test_calendar.csv");
    if (file.exists()) {
      file.delete();
    }
  }

  /**
   * Tests that the timezone is set correctly in the constructor.
   */
  @Test
  public void testConstructorAndGetTimezone() {
    assertEquals("America/New_York", calendar.getTimezone().toString());
  }

  /**
   * Tests setting a new timezone.
   */
  @Test
  public void testSetTimezone() {
    calendar.setTimezone("America/Los_Angeles");
    assertEquals("America/Los_Angeles", calendar.getTimezone().toString());
  }

  /**
   * Tests adding an event and retrieving all events.
   */
  @Test
  public void testAddEventAndGetAllEvents() {
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    Event event = new Event("Meeting", start, end, "Team sync", "Room 1", true);
    assertTrue(calendar.addEvent(event));

    List<Event> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    Event retrievedEvent = events.get(0);
    assertEquals("Meeting", retrievedEvent.getSubject());
    assertEquals(start, retrievedEvent.getStartDateTime());
    assertEquals(end, retrievedEvent.getEndDateTime());
    assertEquals("Team sync", retrievedEvent.getDescription());
    assertEquals("Room 1", retrievedEvent.getLocation());
    assertTrue(retrievedEvent.isPublic());
  }

  /**
   * Tests that adding a conflicting event fails.
   */
  @Test
  public void testAddEventWithConflict() {
    LocalDateTime start1 = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end1 = LocalDateTime.of(2025, 10, 15, 15, 0);
    Event event1 = new Event("Meeting1", start1, end1, "Team sync", "Room 1", true);
    calendar.addEvent(event1);

    LocalDateTime start2 = LocalDateTime.of(2025, 10, 15, 14, 30);
    LocalDateTime end2 = LocalDateTime.of(2025, 10, 15, 15, 30);
    Event event2 = new Event("Meeting2", start2, end2, "Overlap", "Room 2", false);
    assertFalse(calendar.addEvent(event2));

    List<Event> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    assertEquals("Meeting1", events.get(0).getSubject());
  }

  /**
   * Tests retrieving events on a specific date.
   */
  @Test
  public void testGetEventsOnDate() {
    LocalDateTime start1 = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end1 = LocalDateTime.of(2025, 10, 15, 15, 0);
    Event event1 = new Event("Meeting1", start1, end1, "Team sync", "Room 1", true);
    calendar.addEvent(event1);

    LocalDateTime start2 = LocalDateTime.of(2025, 10, 16, 10, 0);
    LocalDateTime end2 = LocalDateTime.of(2025, 10, 16, 11, 0);
    Event event2 = new Event("Meeting2", start2, end2, "Planning", "Room 2", false);
    calendar.addEvent(event2);

    LocalDateTime date = LocalDateTime.of(2025, 10, 15, 0, 0);
    List<Event> events = calendar.getEventsOnDate(date);
    assertEquals(1, events.size());
    assertEquals("Meeting1", events.get(0).getSubject());
  }

  /**
   * Tests exporting events to a CSV file.
   */
  @Test
  public void testExportToCSV() {
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    Event event = new Event("Meeting", start, end, "Team sync", "Room 1", true);
    calendar.addEvent(event);

    String filePath = "test_calendar.csv";
    calendar.exportToCSV(filePath);

    File file = new File(filePath);
    assertTrue(file.exists());
  }

  /**
   * Tests checking if the calendar is busy at a specific time.
   */
  @Test
  public void testIsBusy() {
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    Event event = new Event("Meeting", start, end, "Team sync", "Room 1", true);
    calendar.addEvent(event);

    assertTrue(calendar.isBusy(LocalDateTime.of(2025, 10, 15, 14, 30)));
    assertFalse(calendar.isBusy(LocalDateTime.of(2025, 10, 15, 15, 30)));
  }

  /**
   * Tests finding an event by subject and start time.
   */
  @Test
  public void testFindEvent() {
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    Event event = new Event("Meeting", start, end, "Team sync", "Room 1", true);
    calendar.addEvent(event);

    Event foundEvent = calendar.findEvent("Meeting", start);
    assertEquals("Meeting", foundEvent.getSubject());
    assertNull(calendar.findEvent("Meeting", LocalDateTime.of(2025, 10, 15, 10, 0)));
  }

  /**
   * Tests finding events starting at or after a given time.
   */
  @Test
  public void testFindEventsStartingAtOrAfter() {
    LocalDateTime start1 = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end1 = LocalDateTime.of(2025, 10, 15, 15, 0);
    Event event1 = new Event("Meeting", start1, end1, "Team sync", "Room 1", true);
    calendar.addEvent(event1);

    LocalDateTime start2 = LocalDateTime.of(2025, 10, 15, 16, 0);
    LocalDateTime end2 = LocalDateTime.of(2025, 10, 15, 17, 0);
    Event event2 = new Event("Meeting", start2, end2, "Planning", "Room 2", false);
    calendar.addEvent(event2);

    List<Event> events = calendar.findEventsStartingAtOrAfter(
            "Meeting", LocalDateTime.of(2025, 10, 15, 15, 0));
    assertEquals(1, events.size());
    assertEquals(start2, events.get(0).getStartDateTime());
  }

  /**
   * Tests editing an event's subject.
   */
  @Test
  public void testEditEvent() {
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    Event event = new Event("Meeting", start, end, "Team sync", "Room 1", true);
    calendar.addEvent(event);

    calendar.editEvent(event, "subject", "Updated Meeting");
    assertEquals("Updated Meeting", event.getSubject());
  }

  /**
   * Tests copying a single event to another calendar.
   */
  @Test
  public void testCopyEvent() {
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    Event event = new Event("Meeting", start, end, "Team sync", "Room 1", true);
    calendar.addEvent(event);

    Calendar targetCalendar = new Calendar("America/Los_Angeles", ZoneId.of("UTC"));
    LocalDateTime targetStart = LocalDateTime.of(2025, 10, 16, 14, 0);
    calendar.copyEvent(event, targetStart, targetCalendar);

    List<Event> targetEvents = targetCalendar.getAllEvents();
    assertEquals(1, targetEvents.size());
    Event copiedEvent = targetEvents.get(0);
    assertEquals("Meeting", copiedEvent.getSubject());
    assertEquals(targetStart, copiedEvent.getStartDateTime());
    assertEquals(LocalDateTime.of(2025, 10, 16, 15, 0), copiedEvent.getEndDateTime());
  }

  /**
   * Tests copying events on a specific date to another calendar.
   */
  @Test
  public void testCopyEventsOnDate() {
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    Event event = new Event("Meeting", start, end, "Team sync", "Room 1", true);
    calendar.addEvent(event);

    Calendar targetCalendar = new Calendar("America/Los_Angeles", ZoneId.of("UTC"));
    LocalDateTime targetStart = LocalDateTime.of(2025, 10, 16, 0, 0);
    calendar.copyEventsOnDate(start, targetStart, targetCalendar);

    List<Event> targetEvents = targetCalendar.getEventsOnDate(targetStart);
    assertEquals(1, targetEvents.size());
    Event copiedEvent = targetEvents.get(0);
    assertEquals("Meeting", copiedEvent.getSubject());
    assertEquals(LocalDateTime.of(2025, 10, 16, 14, 0), copiedEvent.getStartDateTime());
  }

  /**
   * Tests copying events within a date range to another calendar.
   */
  @Test
  public void testCopyEventsInRange() {
    LocalDateTime start1 = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end1 = LocalDateTime.of(2025, 10, 15, 15, 0);
    Event event1 = new Event("Meeting1", start1, end1, "Team sync", "Room 1", true);
    calendar.addEvent(event1);

    LocalDateTime start2 = LocalDateTime.of(2025, 10, 16, 10, 0);
    LocalDateTime end2 = LocalDateTime.of(2025, 10, 16, 11, 0);
    Event event2 = new Event("Meeting2", start2, end2, "Planning", "Room 2", false);
    calendar.addEvent(event2);

    Calendar targetCalendar = new Calendar("America/Los_Angeles", ZoneId.of("UTC"));
    LocalDateTime rangeStart = LocalDateTime.of(2025, 10, 15, 0, 0);
    LocalDateTime rangeEnd = LocalDateTime.of(2025, 10, 16, 23, 59);
    LocalDateTime targetStart = LocalDateTime.of(2025, 10, 17, 0, 0);
    calendar.copyEventsInRange(rangeStart, rangeEnd, targetStart, targetCalendar);

    List<Event> targetEvents = targetCalendar.getAllEvents();
    assertEquals(2, targetEvents.size());
    assertEquals("Meeting1", targetEvents.get(0).getSubject());
    assertEquals(LocalDateTime.of(2025, 10, 17, 14, 0), targetEvents.get(0).getStartDateTime());
    assertEquals("Meeting2", targetEvents.get(1).getSubject());
    assertEquals(LocalDateTime.of(2025, 10, 18, 10, 0), targetEvents.get(1).getStartDateTime());
  }
}