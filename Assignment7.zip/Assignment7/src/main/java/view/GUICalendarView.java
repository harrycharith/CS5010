
package view;

import controller.CalendarController;
import model.Calendar;
import model.CalendarAnalytics;
import model.Event;

import javax.swing.*;
import java.awt.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.awt.event.ActionListener;

/**
 * A Swing-based graphical user interface for the calendar application, displaying a month view
 * with event management and analytics capabilities.
 */
public class GUICalendarView extends JFrame {
  public CalendarController controller;
  private LocalDate currentMonth;
  JComboBox<String> calendarComboBox;
  private JLabel monthLabel;
  private JTable calendarTable;
  JTextArea eventsTextArea;
  private JComboBox<String> timezoneComboBox;
  private static final DateTimeFormatter DATE_FORMATTER =
          DateTimeFormatter.ofPattern("yyyy-MM-dd");
  private Map<String, Calendar> lastCalendars;
  private String lastCurrentCalendarName;

  public GUICalendarView() {
    super("Calendar Application");
    this.currentMonth = LocalDate.now();
    this.lastCalendars = null;
    this.lastCurrentCalendarName = null;

    setSize(800, 600);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLayout(new BorderLayout());

    initializeComponents();
  }

  private void initializeComponents() {
    JPanel topPanel = new JPanel(new BorderLayout());
    add(topPanel, BorderLayout.NORTH);

    JPanel calendarSelectionPanel = new JPanel(new FlowLayout());
    calendarComboBox = new JComboBox<>();
    calendarComboBox.addActionListener(
            e -> {
              String selectedCalendar = (String) calendarComboBox.getSelectedItem();
              if (selectedCalendar != null && !selectedCalendar.equals("No Calendars Available")) {
                controller.setCurrentCalendar(selectedCalendar);
                refreshMonthView();
              }
            });
    calendarSelectionPanel.add(new JLabel("Select Calendar: "));
    calendarSelectionPanel.add(calendarComboBox);

    JButton createCalendarButton = new JButton("Create New Calendar");
    createCalendarButton.addActionListener(e -> createNewCalendar());
    calendarSelectionPanel.add(createCalendarButton);

    topPanel.add(calendarSelectionPanel, BorderLayout.NORTH);

    JPanel navigationPanel = new JPanel(new FlowLayout());
    monthLabel =
            new JLabel(currentMonth.getMonth() + " " + currentMonth.getYear(), SwingConstants.CENTER);
    JButton prevButton = new JButton("<");
    prevButton.addActionListener(
            e -> {
              currentMonth = currentMonth.minusMonths(1);
              monthLabel.setText(currentMonth.getMonth() + " " + currentMonth.getYear());
              refreshMonthView();
            });
    JButton nextButton = new JButton(">");
    nextButton.addActionListener(
            e -> {
              currentMonth = currentMonth.plusMonths(1);
              monthLabel.setText(currentMonth.getMonth() + " " + currentMonth.getYear());
              refreshMonthView();
            });
    navigationPanel.add(prevButton);
    navigationPanel.add(monthLabel);
    navigationPanel.add(nextButton);
    topPanel.add(navigationPanel, BorderLayout.CENTER);

    calendarTable = new JTable(6, 7);
    calendarTable.setRowHeight(50);
    calendarTable.setDefaultEditor(Object.class, null);
    calendarTable.setCellSelectionEnabled(true);
    calendarTable
            .getSelectionModel()
            .addListSelectionListener(
                    e -> {
                      if (!e.getValueIsAdjusting()) {
                        int row = calendarTable.getSelectedRow();
                        int col = calendarTable.getSelectedColumn();
                        if (row >= 0 && col >= 0) {
                          String value = (String) calendarTable.getValueAt(row, col);
                          if (value != null && !value.isEmpty()) {
                            try {
                              int day = Integer.parseInt(value.split("\n")[0]);
                              LocalDate selectedDate = currentMonth.withDayOfMonth(day);
                              controller.showEventsOnDate(selectedDate.atStartOfDay());
                            } catch (NumberFormatException ex) {
                              // Ignore invalid selections.
                            }
                          }
                        }
                      }
                    });
    add(new JScrollPane(calendarTable), BorderLayout.CENTER);

    JPanel rightPanel = new JPanel();
    rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
    rightPanel.setBorder(BorderFactory.createTitledBorder("Events and Actions"));
    add(rightPanel, BorderLayout.EAST);

    eventsTextArea = new JTextArea(10, 20);
    eventsTextArea.setEditable(false);
    rightPanel.add(new JScrollPane(eventsTextArea));

    JButton createEventButton = new JButton("Create Event");
    createEventButton.addActionListener(e -> createEventDialog(null));
    rightPanel.add(createEventButton);

    JButton editEventButton = new JButton("Edit Event");
    editEventButton.addActionListener(e -> editEventDialog());
    rightPanel.add(editEventButton);

    JButton showAnalyticsButton = new JButton("Show Analytics");
    showAnalyticsButton.addActionListener(e -> showAnalyticsDialog());
    rightPanel.add(showAnalyticsButton);

    JButton exportButton = new JButton("Export Calendar");
    exportButton.addActionListener(e -> exportCalendar());
    rightPanel.add(exportButton);

    JButton importButton = new JButton("Import Calendar");
    importButton.addActionListener(e -> importCalendar());
    rightPanel.add(importButton);
  }

  public void initialize() {
    updateCalendarComboBox();
    if (controller != null) {
      refreshMonthView();
    }
  }

  private void updateCalendarComboBox() {
    ActionListener[] listeners = calendarComboBox.getActionListeners();
    for (ActionListener listener : listeners) {
      calendarComboBox.removeActionListener(listener);
    }

    System.out.println("GUICalendarView: Updating calendar combo box...");
    calendarComboBox.removeAllItems();
    if (controller == null) {
      calendarComboBox.addItem("No Calendars Available");
      calendarComboBox.setEnabled(false);
      System.out.println("GUICalendarView: No controller set.");
      return;
    }
    Map<String, Calendar> calendars = controller.getCalendars();
    if (calendars.isEmpty()) {
      calendarComboBox.addItem("No Calendars Available");
      calendarComboBox.setEnabled(false);
      System.out.println("GUICalendarView: No calendars available.");
    } else {
      calendarComboBox.setEnabled(true);
      for (String name : calendars.keySet()) {
        calendarComboBox.addItem(name);
        System.out.println("GUICalendarView: Added calendar '" + name + "' to combo box.");
      }
      String currentCalendarName = controller.getCurrentCalendarName();
      if (calendars.containsKey(currentCalendarName)) {
        calendarComboBox.setSelectedItem(currentCalendarName);
        System.out.println("GUICalendarView: Selected calendar '" + currentCalendarName + "'.");
      } else if (calendars.size() > 0) {
        String firstCalendar = calendars.keySet().iterator().next();
        calendarComboBox.setSelectedItem(firstCalendar);
        controller.setCurrentCalendar(firstCalendar);
        System.out.println("GUICalendarView: Defaulted to first calendar '" + firstCalendar + "'.");
      }
    }
    calendarComboBox.revalidate();
    calendarComboBox.repaint();
    System.out.println(
            "GUICalendarView: Finished updating combo box. Items: " + calendarComboBox.getItemCount());

    for (ActionListener listener : listeners) {
      calendarComboBox.addActionListener(listener);
    }
  }

  public void updateCalendarList(Map<String, Calendar> calendars, String currentCalendarName) {
    boolean calendarsChanged = !calendars.equals(lastCalendars);
    boolean currentCalendarChanged =
            (currentCalendarName == null && lastCurrentCalendarName != null)
                    || (currentCalendarName != null
                    && !currentCalendarName.equals(lastCurrentCalendarName));
    if (!calendarsChanged && !currentCalendarChanged) {
      System.out.println(
              "GUICalendarView: No changes in calendar list or current calendar. Skipping update.");
      return;
    }
    System.out.println(
            "GUICalendarView: updateCalendarList called with " + calendars.size() + " calendars.");
    lastCalendars = new java.util.HashMap<>(calendars);
    lastCurrentCalendarName = currentCalendarName;
    updateCalendarComboBox();
    if (controller != null) {
      refreshMonthView();
    }
  }

  public void refreshMonthView() {
    if (controller == null) {
      return;
    }
    String[] days = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
    for (int col = 0; col < 7; col++) {
      calendarTable.getColumnModel().getColumn(col).setHeaderValue(days[col]);
    }

    for (int row = 0; row < 6; row++) {
      for (int col = 0; col < 7; col++) {
        calendarTable.setValueAt("", row, col);
      }
    }

    LocalDate firstOfMonth = currentMonth.withDayOfMonth(1);
    int startDay = firstOfMonth.getDayOfWeek().getValue() % 7;
    int daysInMonth = currentMonth.lengthOfMonth();

    int row = 0;
    int col = startDay;
    for (int day = 1; day <= daysInMonth; day++) {
      LocalDate date = currentMonth.withDayOfMonth(day);
      List<Event> events = controller.getEventsOnDate(date.atStartOfDay());
      StringBuilder cellText = new StringBuilder(String.valueOf(day));
      if (!events.isEmpty()) {
        cellText.append("\n").append(events.size()).append(" event(s)");
      }
      calendarTable.setValueAt(cellText.toString(), row, col);
      col++;
      if (col == 7) {
        col = 0;
        row++;
      }
    }
    calendarTable.repaint();
  }

  private void createNewCalendar() {
    JTextField nameField = new JTextField(10);
    timezoneComboBox = new JComboBox<>(ZoneId.getAvailableZoneIds().toArray(new String[0]));
    timezoneComboBox.setSelectedItem(ZoneId.systemDefault().getId());

    JPanel panel = new JPanel(new GridLayout(0, 2));
    panel.add(new JLabel("Calendar Name:"));
    panel.add(nameField);
    panel.add(new JLabel("Timezone:"));
    panel.add(timezoneComboBox);

    int result =
            JOptionPane.showConfirmDialog(
                    this, panel, "Create New Calendar", JOptionPane.OK_CANCEL_OPTION);
    if (result == JOptionPane.OK_OPTION) {
      String name = nameField.getText().trim();
      String timezone = (String) timezoneComboBox.getSelectedItem();
      if (name.isEmpty()) {
        displayMessage("Calendar name cannot be empty.");
        return;
      }
      try {
        System.out.println(
                "GUICalendarView: Creating new calendar '"
                        + name
                        + "' with timezone '"
                        + timezone
                        + "'.");
        controller.createCalendar(name, timezone);
        controller.setCurrentCalendar(name);
        System.out.println("GUICalendarView: Finished creating and setting calendar '" + name + "'.");
      } catch (IllegalArgumentException e) {
        displayMessage(e.getMessage());
      }
    }
  }

  private void createEventDialog(Event existingEvent) {
    JTextField subjectField =
            new JTextField(existingEvent != null ? existingEvent.getSubject() : "", 15);
    JTextField startDateField =
            new JTextField(
                    existingEvent != null
                            ? existingEvent.getStartDateTime().format(DATE_FORMATTER)
                            : LocalDate.now().format(DATE_FORMATTER),
                    10);
    JTextField startTimeField =
            new JTextField(
                    existingEvent != null
                            ? existingEvent.getStartDateTime().toLocalTime().toString()
                            : "09:00",
                    5);
    JTextField endDateField =
            new JTextField(
                    existingEvent != null
                            ? existingEvent.getEndDateTime().format(DATE_FORMATTER)
                            : LocalDate.now().format(DATE_FORMATTER),
                    10);
    JTextField endTimeField =
            new JTextField(
                    existingEvent != null
                            ? existingEvent.getEndDateTime().toLocalTime().toString()
                            : "10:00",
                    5);
    JTextField descriptionField =
            new JTextField(existingEvent != null ? existingEvent.getDescription() : "", 15);
    JTextField locationField =
            new JTextField(existingEvent != null ? existingEvent.getLocation() : "", 15);
    JCheckBox publicCheckBox =
            new JCheckBox("Public", existingEvent != null ? existingEvent.isPublic() : true);
    JCheckBox recurringCheckBox = new JCheckBox("Recurring Event");
    JPanel recurringPanel = new JPanel(new GridLayout(0, 2));
    JCheckBox[] dayCheckBoxes = new JCheckBox[7];
    String[] days = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
    for (int i = 0; i < 7; i++) {
      dayCheckBoxes[i] = new JCheckBox(days[i]);
      recurringPanel.add(dayCheckBoxes[i]);
    }
    JTextField endRecurrenceField =
            new JTextField(
                    existingEvent != null ? LocalDate.now().plusMonths(1).format(DATE_FORMATTER) : "", 10);

    recurringPanel.add(new JLabel("End Recurrence (yyyy-MM-dd):"));
    recurringPanel.add(endRecurrenceField);
    recurringPanel.setVisible(false);
    recurringCheckBox.addActionListener(e -> recurringPanel.setVisible(recurringCheckBox.isSelected()));

    JPanel panel = new JPanel(new BorderLayout());
    JPanel inputPanel = new JPanel(new GridLayout(0, 2, 5, 5));
    inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    inputPanel.add(new JLabel("Subject:"));
    inputPanel.add(subjectField);
    inputPanel.add(new JLabel("Start Date (yyyy-MM-dd):"));
    inputPanel.add(startDateField);
    inputPanel.add(new JLabel("Start Time (HH:mm):"));
    inputPanel.add(startTimeField);
    inputPanel.add(new JLabel("End Date (yyyy-MM-dd):"));
    inputPanel.add(endDateField);
    inputPanel.add(new JLabel("End Time (HH:mm):"));
    inputPanel.add(endTimeField);
    inputPanel.add(new JLabel("Description:"));
    inputPanel.add(descriptionField);
    inputPanel.add(new JLabel("Location:"));
    inputPanel.add(locationField);
    inputPanel.add(new JLabel("Visibility:"));
    inputPanel.add(publicCheckBox);
    inputPanel.add(new JLabel("Recurring:"));
    inputPanel.add(recurringCheckBox);

    panel.add(inputPanel, BorderLayout.NORTH);
    panel.add(recurringPanel, BorderLayout.CENTER);

    int result =
            JOptionPane.showConfirmDialog(
                    this,
                    panel,
                    existingEvent != null ? "Edit Event" : "Create Event",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE);
    if (result == JOptionPane.OK_OPTION) {
      try {
        String subject = subjectField.getText().trim();
        LocalDateTime start =
                LocalDateTime.parse(
                        startDateField.getText() + "T" + startTimeField.getText(),
                        DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm"));
        LocalDateTime end =
                LocalDateTime.parse(
                        endDateField.getText() + "T" + endTimeField.getText(),
                        DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm"));
        String description = descriptionField.getText().trim();
        String location = locationField.getText().trim();
        boolean isPublic = publicCheckBox.isSelected();

        if (subject.isEmpty() || description.isEmpty() || location.isEmpty()) {
          displayMessage("All fields (subject, description, location) must be filled.");
          return;
        }

        if (start.isAfter(end)) {
          displayMessage("Start date/time must be before end date/time.");
          return;
        }

        if (recurringCheckBox.isSelected()) {
          Set<DayOfWeek> recurringDays = new java.util.HashSet<>();
          for (int i = 0; i < 7; i++) {
            if (dayCheckBoxes[i].isSelected()) {
              recurringDays.add(DayOfWeek.of((i + 1) % 7 == 0 ? 7 : (i + 1) % 7));
            }
          }
          if (recurringDays.isEmpty()) {
            displayMessage("Select at least one day for recurrence.");
            return;
          }
          if (endRecurrenceField.getText().trim().isEmpty()) {
            displayMessage("End recurrence date must be specified.");
            return;
          }
          LocalDateTime endRecurrence =
                  LocalDateTime.parse(
                          endRecurrenceField.getText() + "T23:59",
                          DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm"));
          if (endRecurrence.isBefore(start)) {
            displayMessage("End recurrence date must be after the start date.");
            return;
          }
          controller.createRecurringEvent(
                  subject, start, end, description, location, isPublic, recurringDays, endRecurrence);
        } else {
          if (existingEvent != null) {
            existingEvent.setSubject(subject);
            existingEvent.setStartDateTime(start);
            existingEvent.setEndDateTime(end);
            existingEvent.setDescription(description);
            existingEvent.setLocation(location);
            existingEvent.setPublic(isPublic);
            controller.editEvent(existingEvent, "subject", subject);
          } else {
            controller.createEvent(subject, start, end, description, location, isPublic);
          }
        }
      } catch (Exception e) {
        displayMessage("Error creating/editing event: " + e.getMessage());
      }
    }
  }

  private void editEventDialog() {
    int row = calendarTable.getSelectedRow();
    int col = calendarTable.getSelectedColumn();
    if (row < 0 || col < 0) {
      displayMessage("Please select a date to edit events.");
      return;
    }
    String value = (String) calendarTable.getValueAt(row, col);
    if (value == null || value.isEmpty()) {
      return;
    }
    int day = Integer.parseInt(value.split("\n")[0]);
    LocalDate selectedDate = currentMonth.withDayOfMonth(day);
    List<Event> events = controller.getEventsOnDate(selectedDate.atStartOfDay());
    if (events.isEmpty()) {
      displayMessage("No events to edit on this date.");
      return;
    }

    JComboBox<String> eventComboBox =
            new JComboBox<>(events.stream().map(Event::toString).toArray(String[]::new));
    JCheckBox multipleCheckBox = new JCheckBox("Edit all events with this subject from this date");
    JPanel panel = new JPanel(new GridLayout(0, 1));
    panel.add(new JLabel("Select Event:"));
    panel.add(eventComboBox);
    panel.add(multipleCheckBox);

    int result =
            JOptionPane.showConfirmDialog(
                    this, panel, "Select Event to Edit", JOptionPane.OK_CANCEL_OPTION);
    if (result == JOptionPane.OK_OPTION) {
      int selectedIndex = eventComboBox.getSelectedIndex();
      Event selectedEvent = events.get(selectedIndex);
      if (multipleCheckBox.isSelected()) {
        JTextField propertyField = new JTextField(10);
        JTextField valueField = new JTextField(10);
        JPanel editPanel = new JPanel(new GridLayout(0, 2));
        editPanel.add(new JLabel("Property (subject, description, location):"));
        editPanel.add(propertyField);
        editPanel.add(new JLabel("New Value:"));
        editPanel.add(valueField);

        int editResult =
                JOptionPane.showConfirmDialog(
                        this, editPanel, "Edit Multiple Events", JOptionPane.OK_CANCEL_OPTION);
        if (editResult == JOptionPane.OK_OPTION) {
          String property = propertyField.getText().trim().toLowerCase();
          String newValue = valueField.getText().trim();
          if (!property.equals("subject")
                  && !property.equals("description")
                  && !property.equals("location")) {
            displayMessage("Invalid property. Use 'subject', 'description', or 'location'.");
            return;
          }
          controller.editEvents(
                  selectedEvent.getSubject(), selectedDate.atStartOfDay(), property, newValue);
        }
      } else {
        createEventDialog(selectedEvent);
      }
    }
  }

  private void showAnalyticsDialog() {
    JTextField startDateField = new JTextField(LocalDate.now().format(DATE_FORMATTER), 10);
    JTextField endDateField = new JTextField(LocalDate.now().format(DATE_FORMATTER), 10);

    JPanel panel = new JPanel(new GridLayout(0, 2));
    panel.add(new JLabel("Start Date (yyyy-MM-dd):"));
    panel.add(startDateField);
    panel.add(new JLabel("End Date (yyyy-MM-dd):"));
    panel.add(endDateField);

    int result =
            JOptionPane.showConfirmDialog(
                    this, panel, "Select Date Range for Analytics", JOptionPane.OK_CANCEL_OPTION);
    if (result == JOptionPane.OK_OPTION) {
      try {
        LocalDate startDate = LocalDate.parse(startDateField.getText(), DATE_FORMATTER);
        LocalDate endDate = LocalDate.parse(endDateField.getText(), DATE_FORMATTER);
        controller.showAnalytics(startDate, endDate);
      } catch (Exception e) {
        displayMessage("Invalid date format. Use yyyy-MM-dd.");
      }
    }
  }

  public void displayAnalytics(CalendarAnalytics analytics) {
    JTextArea analyticsArea = new JTextArea(20, 50);
    analyticsArea.setEditable(false);
    StringBuilder sb = new StringBuilder();
    sb.append("Calendar Analytics Dashboard\n");
    sb.append("-------------------------\n");
    sb.append("Total Events: ").append(analytics.getTotalEvents()).append("\n\n");

    sb.append("Events by Weekday:\n");
    for (Map.Entry<String, Integer> entry : analytics.getEventsByWeekday().entrySet()) {
      sb.append("  ").append(entry.getKey()).append(": ").append(entry.getValue()).append("\n");
    }
    sb.append("\n");

    sb.append("Events by Name:\n");
    for (Map.Entry<String, Integer> entry : analytics.getEventsByName().entrySet()) {
      sb.append("  ").append(entry.getKey()).append(": ").append(entry.getValue()).append("\n");
    }
    sb.append("\n");

    sb.append("Average Events per Day: ")
            .append(String.format("%.2f", analytics.getAverageEventsPerDay()))
            .append("\n\n");

    Map.Entry<LocalDate, LocalDate> busiestLeast = analytics.getBusiestAndLeastBusyDay();
    sb.append("Busiest Day: ")
            .append(busiestLeast.getKey() != null ? busiestLeast.getKey() : "N/A")
            .append("\n");
    sb.append("Least Busy Day: ")
            .append(busiestLeast.getValue() != null ? busiestLeast.getValue() : "N/A")
            .append("\n\n");

    Map.Entry<Double, Double> onlineOffline = analytics.getOnlineOfflinePercentages();
    sb.append("Online Events: ").append(String.format("%.2f%%", onlineOffline.getKey())).append("\n");
    sb.append("Offline Events: ")
            .append(String.format("%.2f%%", onlineOffline.getValue()))
            .append("\n");

    analyticsArea.setText(sb.toString());
    JOptionPane.showMessageDialog(this, new JScrollPane(analyticsArea), "Analytics Dashboard", JOptionPane.PLAIN_MESSAGE);
  }

  private void exportCalendar() {
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle("Export Calendar to CSV");
    if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
      String filePath = fileChooser.getSelectedFile().getAbsolutePath();
      if (!filePath.endsWith(".csv")) {
        filePath += ".csv";
      }
      controller.exportCalendar(filePath);
    }
  }

  private void importCalendar() {
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle("Import Calendar from CSV");
    if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
      String filePath = fileChooser.getSelectedFile().getAbsolutePath();
      controller.importCalendar(filePath);
    }
  }

  public void displayMessage(String message) {
    JOptionPane.showMessageDialog(this, message);
  }

  public void displayEvents(List<Event> events) {
    StringBuilder sb = new StringBuilder();
    for (Event event : events) {
      sb.append(event.toString()).append("\n");
    }
    eventsTextArea.setText(sb.toString());
  }
}
