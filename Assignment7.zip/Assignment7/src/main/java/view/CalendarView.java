
package view;

import model.Event;
import java.util.List;

/**
 * Text-based view for the calendar application.
 */
public class CalendarView {
  public void displayMessage(String message) {
    System.out.println(message);
  }

  public void displayEvents(List<Event> events) {
    if (events.isEmpty()) {
      System.out.println("No events found.");
      return;
    }
    for (Event event : events) {
      System.out.println(event.toString());
    }
  }
}
