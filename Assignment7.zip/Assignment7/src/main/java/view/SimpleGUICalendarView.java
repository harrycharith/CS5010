package view;

import java.util.List;
import java.util.Map;
import model.Calendar;
import model.Event;

/**
 * A simple implementation of GUICalendarView for testing purposes.
 */
public class SimpleGUICalendarView extends GUICalendarView {

  @Override
  public void displayMessage(String message) {
    // No-op
  }

  @Override
  public void displayEvents(List<Event> events) {
    // No-op
  }

  @Override
  public void updateCalendarList(Map<String, Calendar> calendars, String currentCalendarName) {
    // No-op
  }

  @Override
  public void refreshMonthView() {
    // No-op
  }
}