package util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/**
 * Utility class for date and time operations.
 */
public class DateTimeUtil {
  private static final DateTimeFormatter DATE_TIME_FORMATTER =
          DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");

  /**
   * Parses a date-time string into a LocalDateTime object.
   *
   * @param dateTimeString the date-time string to parse
   * @return the parsed LocalDateTime object
   * @throws DateTimeParseException if the string cannot be parsed
   */
  public static LocalDateTime parseDateTime(String dateTimeString) throws DateTimeParseException {
    return LocalDateTime.parse(dateTimeString, DATE_TIME_FORMATTER);
  }

  /**
   * Formats a LocalDateTime object into a string.
   *
   * @param dateTime the LocalDateTime object to format
   * @return the formatted string
   */
  public static String formatDateTime(LocalDateTime dateTime) {
    return dateTime.format(DATE_TIME_FORMATTER);
  }
}