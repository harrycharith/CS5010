
package controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/**
 * Parses and executes commands for the text-based calendar interface.
 */
public class CommandParser {
  private static final DateTimeFormatter DATE_FORMATTER =
          DateTimeFormatter.ofPattern("yyyy-MM-dd");
  private final CalendarController controller;

  public CommandParser(CalendarController controller) {
    this.controller = controller;
  }

  public void parseCommand(String command) {
    if (command == null || command.trim().isEmpty()) {
      controller.notifyViews("Empty command.");
      return;
    }

    String[] parts = command.trim().split("\\s+");
    try {
      if (parts[0].equalsIgnoreCase("use") && parts[1].equalsIgnoreCase("calendar")) {
        StringBuilder calendarName = new StringBuilder();
        for (int i = 2; i < parts.length; i++) {
          calendarName.append(parts[i]).append(" ");
        }
        controller.setCurrentCalendar(calendarName.toString().trim());
      } else if (parts[0].equalsIgnoreCase("show")
              && parts[1].equalsIgnoreCase("calendar")
              && parts[2].equalsIgnoreCase("dashboard")
              && parts[3].equalsIgnoreCase("from")
              && parts[5].equalsIgnoreCase("to")) {
        LocalDate fromDate = LocalDate.parse(parts[4], DATE_FORMATTER);
        LocalDate toDate = LocalDate.parse(parts[6], DATE_FORMATTER);
        controller.showAnalytics(fromDate, toDate);
      } else {
        controller.notifyViews("Unknown command: " + command);
      }
    } catch (DateTimeParseException e) {
      controller.notifyViews("Invalid date format. Use yyyy-MM-dd.");
    } catch (Exception e) {
      controller.notifyViews("Error parsing command: " + e.getMessage());
    }
  }
}
