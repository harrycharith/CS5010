package model;

import java.time.LocalDateTime;

/**
 * Interface defining the contract for calendar events.
 */
public interface CalendarEvent {
  /**
   * Returns the subject of the event.
   *
   * @return the event subject
   */
  String getSubject();

  /**
   * Returns the start date and time of the event.
   *
   * @return the start date and time
   */
  LocalDateTime getStartDateTime();

  /**
   * Returns the end date and time of the event.
   *
   * @return the end date and time
   */
  LocalDateTime getEndDateTime();

  /**
   * Returns the description of the event.
   *
   * @return the event description
   */
  String getDescription();

  /**
   * Returns the location of the event.
   *
   * @return the event location
   */
  String getLocation();

  /**
   * Returns whether the event is public.
   *
   * @return true if the event is public, false otherwise
   */
  boolean isPublic();

  /**
   * Checks if this event conflicts with another event.
   *
   * @param other the other event to check against
   * @return true if there is a time conflict, false otherwise
   */
  boolean conflictsWith(CalendarEvent other);
}