package model;

import java.time.*;
import java.util.*;
import java.time.format.TextStyle;

/**
 * Computes analytics metrics for a calendar over a specified date range.
 */
public class CalendarAnalytics {
  private final Calendar calendar;
  private final LocalDate startDate;
  private final LocalDate endDate;

  /**
   * Constructs analytics for a calendar over a date range.
   *
   * @param calendar the calendar to analyze
   * @param startDate the start date (inclusive)
   * @param endDate the end date (inclusive)
   */
  public CalendarAnalytics(Calendar calendar, LocalDate startDate, LocalDate endDate) {
    this.calendar = calendar;
    this.startDate = startDate;
    this.endDate = endDate;
  }

  /**
   * Gets the total number of events in the date range.
   *
   * @return the total event count
   */
  public int getTotalEvents() {
    int count = 0;
    LocalDate date = startDate;
    while (!date.isAfter(endDate)) {
      count += calendar.getEventsOnDate(date.atStartOfDay()).size();
      date = date.plusDays(1);
    }
    return count;
  }

  /**
   * Gets the number of events per weekday.
   *
   * @return a map of weekday names to event counts
   */
  public Map<String, Integer> getEventsByWeekday() {
    Map<String, Integer> counts = new LinkedHashMap<>();
    for (DayOfWeek day : DayOfWeek.values()) {
      counts.put(day.getDisplayName(TextStyle.FULL, Locale.US), 0);
    }
    LocalDate date = startDate;
    while (!date.isAfter(endDate)) {
      String weekday = date.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.US);
      counts.put(weekday, counts.get(weekday) + calendar.getEventsOnDate(date.atStartOfDay()).size());
      date = date.plusDays(1);
    }
    return counts;
  }

  /**
   * Gets the number of events by event name.
   *
   * @return a map of event subjects to event counts
   */
  public Map<String, Integer> getEventsByName() {
    Map<String, Integer> counts = new HashMap<>();
    LocalDate date = startDate;
    while (!date.isAfter(endDate)) {
      for (Event event : calendar.getEventsOnDate(date.atStartOfDay())) {
        counts.merge(event.getSubject(), 1, Integer::sum);
      }
      date = date.plusDays(1);
    }
    return counts;
  }

  /**
   * Gets the average number of events per day.
   *
   * @return the average event count per day
   */
  public double getAverageEventsPerDay() {
    long days = Duration.between(startDate.atStartOfDay(), endDate.plusDays(1).atStartOfDay()).toDays();
    return days > 0 ? (double) getTotalEvents() / days : 0.0;
  }

  /**
   * Gets the busiest and least busy days based on event counts.
   *
   * @return a pair of dates (busiest, least busy)
   */
  public Map.Entry<LocalDate, LocalDate> getBusiestAndLeastBusyDay() {
    LocalDate busiest = startDate;
    LocalDate leastBusy = startDate;
    int maxEvents = -1;
    int minEvents = Integer.MAX_VALUE;

    LocalDate date = startDate;
    while (!date.isAfter(endDate)) {
      int count = calendar.getEventsOnDate(date.atStartOfDay()).size();
      if (count > maxEvents) {
        maxEvents = count;
        busiest = date;
      }
      if (count < minEvents) {
        minEvents = count;
        leastBusy = date;
      }
      date = date.plusDays(1);
    }
    return new AbstractMap.SimpleEntry<>(busiest, leastBusy);
  }

  /**
   * Gets the percentage of online and offline events.
   *
   * @return a pair of percentages (online, offline)
   */
  public Map.Entry<Double, Double> getOnlineOfflinePercentages() {
    int online = 0;
    int total = getTotalEvents();
    LocalDate date = startDate;
    while (!date.isAfter(endDate)) {
      for (Event event : calendar.getEventsOnDate(date.atStartOfDay())) {
        if ("online".equalsIgnoreCase(event.getLocation())) {
          online++;
        }
      }
      date = date.plusDays(1);
    }
    double onlinePct = total > 0 ? (online * 100.0 / total) : 0.0;
    return new AbstractMap.SimpleEntry<>(onlinePct, 100.0 - onlinePct);
  }
}
