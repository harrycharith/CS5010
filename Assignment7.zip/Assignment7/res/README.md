# Assignment 6 - Calendar Application


## Development Environment
- **Java Version**: 11
- **IDE**: IntelliJ IDEA
- **Testing Framework**: JUnit 4
- **Build System**: Maven

## Features

### Core Functionality
- Multi-calendar management with timezone support
- Event creation/modification (one-time, all-day, recurring)
- Conflict detection system
- Import/export capabilities

### Interfaces
1. **Command-Line Interface**:
    - Interactive shell
    - Batch processing mode
    - Full command documentation

2. **Graphical User Interface**:
    - Swing-based interface
   
   

## Project Setup


### Running the Application
**CLI Version**:
#### Interactive Mode
java -jar CalendarApp.jar --mode interactive

#### Headless Mode
java -jar CalendarApp.jar --mode headless [COMMAND_FILE]

#### GUI Mode



Instructions for using the Calendar Application GUI to perform supported operations.

- **Create a New Calendar**:
    - Click "Create New Calendar" in the top panel.
    - Enter a name (e.g., "Work") and select a timezone (e.g., "America/New_York").
    - Click "OK" to create and set it as the active calendar.

- **Select a Calendar**:
    - Use the "Select Calendar" dropdown to choose an existing calendar (e.g., "Work").
    - The GUI updates to show the selected calendar’s events.

- **View Events for a Day**:
    - Navigate to a month using "<" or ">" buttons (e.g., October 2025).
    - Click a day (e.g., 15) in the calendar table.
    - Events appear in the right text area (e.g., "Team Meeting").

- **Create a Single Event**:
    - Click "Create Event" in the right panel.
    - Fill in: Subject (e.g., "Meeting"), Start Date (e.g., "2025-10-15"), Start Time (e.g., "14:00"),
      End Date (e.g., "2025-10-15"), End Time (e.g., "15:00"), Description (e.g., "Team sync"),
      Location (e.g., "Room 1"), and check/uncheck "Public".
    - Click "OK" to add the event.

- **Create a Recurring Event**:
    - Click "Create Event".
    - Fill in event details as above.
    - Check "Recurring Event", select weekdays (e.g., "Wed"), and set an end date (e.g., "2025-11-15").
    - Click "OK" to add the recurring event.

- **Edit a Single Event**:
    - Select a day with events (e.g., October 15, 2025).
    - Click "Edit Event".
    - Choose an event from the dropdown (e.g., "Meeting"), leave "Edit all" unchecked.
    - Update fields in the dialog (e.g., change Subject to "Updated Meeting").
    - Click "OK" to save changes.

- **Edit Multiple Events**:
    - Select a day (e.g., October 15, 2025).
    - Click "Edit Event".
    - Choose an event (e.g., "Meeting"), check "Edit all events with this subject from this date".
    - Click "OK", then enter a property (e.g., "location") and new value (e.g., "Room 2").
    - Click "OK" to update all matching events.

- **Export a Calendar**:
    - Select a calendar (e.g., "Work").
    - Click "Export Calendar".
    - Choose a file location and name (e.g., "work.csv"), click "Save".

- **Import Events into a Calendar**:
    - Select a calendar (e.g., "Work").
    - Click "Import Calendar".
    - Choose a CSV file (e.g., "import-sample.csv"), click "Open".
    - Events are added to the selected calendar.

- **Default Calendar**:
    - On first launch, a default calendar uses the system timezone (e.g., "America/New_York").
    - Use it without creating a new calendar.



