package controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import model.Calendar;
import model.Event;

/**
 * Parses and processes text commands for calendar management.
 * Supports various operations like creating calendars, events, copying events, etc.
 */
public class CommandParser {
  private static final DateTimeFormatter DATE_TIME_FORMATTER =
          DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");
  private static final DateTimeFormatter DATE_FORMATTER =
          DateTimeFormatter.ofPattern("yyyy-MM-dd");

  private CalendarController controller;

  public CommandParser(CalendarController controller) {
    this.controller = controller;
  }

  public void parseCommand(String command) {
    if (command == null || command.trim().isEmpty()) {
      throw new IllegalArgumentException("Command cannot be empty or null");
    }

    String[] parts = command.trim().split("\\s+");

    try {
      switch (parts[0].toLowerCase()) {
        case "create":
          if (parts[1].equalsIgnoreCase("calendar")) {
            handleCreateCalendarCommand(command);
          } else {
            handleCreateCommand(command, parts);
          }
          break;
        case "set":
          if (parts[1].equalsIgnoreCase("calendar")) {
            handleSetCalendarCommand(command);
          } else {
            throw new IllegalArgumentException("Unknown set type: " + parts[1]);
          }
          break;
        case "copy":
          if (parts[1].equalsIgnoreCase("event")) {
            handleCopyEventCommand(command);
          }
          break;
        case "export":
          if (parts[1].equalsIgnoreCase("calendar")) {
            handleExportCalendarCommand(command);
          } else {
            throw new IllegalArgumentException("Unknown export type: " + parts[1]);
          }
          break;
        default:
          throw new IllegalArgumentException("Unknown command: " + parts[0]);
      }
    } catch (Exception e) {
      throw new IllegalArgumentException("Error processing command: " + e.getMessage(), e);
    }
  }

  private void handleCreateCalendarCommand(String command) {
    Pattern pattern = Pattern.compile("create calendar --name (\\w+) " +
            "--timezone (\\S+(?:/\\S+)?)");
    Matcher matcher = pattern.matcher(command);
    if (!matcher.find()) {
      throw new IllegalArgumentException("Invalid format for create calendar command");
    }
    String name = matcher.group(1);
    String timezone = matcher.group(2);
    controller.createCalendar(name, timezone);
  }

  private void handleCreateCommand(String command, String[] parts) {
    if (parts.length < 2) {
      throw new IllegalArgumentException("Invalid create command");
    }
    if (parts[1].equalsIgnoreCase("event")) {
      if (command.contains("--allDay")) {
        handleAllDayEvent(command);
      } else {
        handleCreateEventCommand(command);
      }
    } else {
      throw new IllegalArgumentException("Unknown create type: " + parts[1]);
    }
  }

  private void handleCreateEventCommand(String command) {
    Pattern pattern = Pattern.compile(
            "create event --subject (\\w+) " +
                    "--start (\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}) " +
                    "--end (\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}) " +
                    "--description (\\w+) --location (\\w+) --public"
    );
    Matcher matcher = pattern.matcher(command);
    if (!matcher.find()) {
      throw new IllegalArgumentException("Invalid format for create event command");
    }
    String subject = matcher.group(1);
    LocalDateTime start = LocalDateTime.parse(matcher.group(2), DATE_TIME_FORMATTER);
    LocalDateTime end = LocalDateTime.parse(matcher.group(3), DATE_TIME_FORMATTER);
    String description = matcher.group(4);
    String location = matcher.group(5);
    boolean isPublic = true;

    controller.createEvent(subject, start, end, description, location, isPublic);
  }

  private void handleAllDayEvent(String command) {
    Pattern pattern = Pattern.compile(
            "create event --subject (\\w+) " +
                    "--allDay (\\d{4}-\\d{2}-\\d{2}) " +
                    "--description (\\w+) --location (\\w+) --public"
    );
    Matcher matcher = pattern.matcher(command);
    if (!matcher.find()) {
      throw new IllegalArgumentException("Invalid date format for all-day event");
    }
    String subject = matcher.group(1);
    LocalDateTime date = LocalDateTime.parse(matcher.group(2) + "T00:00", DATE_TIME_FORMATTER);
    String description = matcher.group(3);
    String location = matcher.group(4);
    boolean isPublic = true;

    controller.createEvent(subject, date, date.plusDays(1).minusMinutes(1), description, location, isPublic);
  }

  private void handleCopyEventCommand(String command) {
    Pattern pattern = Pattern.compile(
            "copy event --subject (\\w+) --start (\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}) " +
                    "--targetCalendar (\\w+) --targetStart (\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2})"
    );
    Matcher matcher = pattern.matcher(command);
    if (!matcher.find()) {
      throw new IllegalArgumentException("Invalid format for copy event command");
    }
    String subject = matcher.group(1);
    LocalDateTime sourceStart = LocalDateTime.parse(matcher.group(2), DATE_TIME_FORMATTER);
    String targetCalendarName = matcher.group(3);
    LocalDateTime targetStart = LocalDateTime.parse(matcher.group(4), DATE_TIME_FORMATTER);

    Calendar sourceCal = controller.getCalendars().get(controller.getCurrentCalendarName());
    Calendar targetCal = controller.getCalendars().get(targetCalendarName);
    sourceCal.copyEventsOnDate(sourceStart, targetStart, targetCal);
  }

  private void handleSetCalendarCommand(String command) {
    Pattern pattern = Pattern.compile("set calendar --name (\\w+)");
    Matcher matcher = pattern.matcher(command);
    if (!matcher.find()) {
      throw new IllegalArgumentException("Invalid format for set calendar command");
    }
    String name = matcher.group(1);
    controller.setCurrentCalendar(name);
  }

  private void handleExportCalendarCommand(String command) {
    Pattern pattern = Pattern.compile("export calendar --file (\\S+)");
    Matcher matcher = pattern.matcher(command);
    if (!matcher.find()) {
      throw new IllegalArgumentException("Invalid format for export calendar command");
    }
    String filePath = matcher.group(1);
    controller.exportCalendar(filePath);
  }
}