package view;

import controller.CalendarController;
import model.Calendar;
import model.Event;

import javax.swing.*;
import java.awt.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class GUICalendarView extends JFrame {
  private CalendarController controller;
  private LocalDate currentMonth;

  private JComboBox<String> calendarComboBox;
  private JLabel monthLabel;
  private JTable calendarTable;
  private JTextArea eventsTextArea;
  private JComboBox<String> timezoneComboBox;

  private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

  public GUICalendarView(CalendarController controller) {
    this.controller = controller;
    this.currentMonth = LocalDate.now();

    setTitle("Calendar Application");
    setSize(800, 600);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLayout(new BorderLayout());

    initializeComponents();
  }

  private void initializeComponents() {
    // Top panel for calendar selection and navigation
    JPanel topPanel = new JPanel(new BorderLayout());
    add(topPanel, BorderLayout.NORTH);

    // Calendar selection
    JPanel calendarSelectionPanel = new JPanel(new FlowLayout());
    calendarComboBox = new JComboBox<>();
    updateCalendarComboBox();
    calendarComboBox.addActionListener(e -> {
      String selectedCalendar = (String) calendarComboBox.getSelectedItem();
      controller.setCurrentCalendar(selectedCalendar);
      refreshMonthView();
    });
    calendarSelectionPanel.add(new JLabel("Select Calendar: "));
    calendarSelectionPanel.add(calendarComboBox);

    // Buttons for creating a new calendar
    JButton createCalendarButton = new JButton("Create New Calendar");
    createCalendarButton.addActionListener(e -> createNewCalendar());
    calendarSelectionPanel.add(createCalendarButton);

    topPanel.add(calendarSelectionPanel, BorderLayout.NORTH);

    // Month navigation
    JPanel navigationPanel = new JPanel(new FlowLayout());
    monthLabel = new JLabel(currentMonth.getMonth() + " " + currentMonth.getYear(), SwingConstants.CENTER);
    JButton prevButton = new JButton("<");
    prevButton.addActionListener(e -> {
      currentMonth = currentMonth.minusMonths(1);
      monthLabel.setText(currentMonth.getMonth() + " " + currentMonth.getYear());
      refreshMonthView();
    });
    JButton nextButton = new JButton(">");
    nextButton.addActionListener(e -> {
      currentMonth = currentMonth.plusMonths(1);
      monthLabel.setText(currentMonth.getMonth() + " " + currentMonth.getYear());
      refreshMonthView();
    });
    navigationPanel.add(prevButton);
    navigationPanel.add(monthLabel);
    navigationPanel.add(nextButton);
    topPanel.add(navigationPanel, BorderLayout.CENTER);

    // Center panel for month view
    calendarTable = new JTable(6, 7);
    calendarTable.setRowHeight(50);
    calendarTable.setDefaultEditor(Object.class, null); // Make cells non-editable
    calendarTable.setCellSelectionEnabled(true);
    calendarTable.getSelectionModel().addListSelectionListener(e -> {
      int row = calendarTable.getSelectedRow();
      int col = calendarTable.getSelectedColumn();
      if (row >= 0 && col >= 0) {
        String value = (String) calendarTable.getValueAt(row, col);
        if (value != null && !value.isEmpty()) {
          try {
            int day = Integer.parseInt(value.split("\n")[0]);
            LocalDate selectedDate = currentMonth.withDayOfMonth(day);
            controller.showEventsOnDate(selectedDate.atStartOfDay());
          } catch (NumberFormatException ex) {
            // Ignore invalid selections
          }
        }
      }
    });
    refreshMonthView();
    add(new JScrollPane(calendarTable), BorderLayout.CENTER);

    // Right panel for events and actions
    JPanel rightPanel = new JPanel();
    rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
    rightPanel.setBorder(BorderFactory.createTitledBorder("Events and Actions"));
    add(rightPanel, BorderLayout.EAST);

    // Events display
    eventsTextArea = new JTextArea(10, 20);
    eventsTextArea.setEditable(false);
    rightPanel.add(new JScrollPane(eventsTextArea));

    // Action buttons
    JButton createEventButton = new JButton("Create Event");
    createEventButton.addActionListener(e -> createEventDialog(null));
    rightPanel.add(createEventButton);

    JButton editEventButton = new JButton("Edit Event");
    editEventButton.addActionListener(e -> editEventDialog());
    rightPanel.add(editEventButton);

    JButton exportButton = new JButton("Export Calendar");
    exportButton.addActionListener(e -> exportCalendar());
    rightPanel.add(exportButton);

    JButton importButton = new JButton("Import Calendar");
    importButton.addActionListener(e -> importCalendar());
    rightPanel.add(importButton);
  }

  private void updateCalendarComboBox() {
    calendarComboBox.removeAllItems();
    for (String name : controller.getCalendars().keySet()) {
      calendarComboBox.addItem(name);
    }
    calendarComboBox.setSelectedItem(controller.getCurrentCalendarName());
  }

  public void updateCalendarList(Map<String, Calendar> calendars, String currentCalendarName) {
    updateCalendarComboBox();
    refreshMonthView();
  }

  public void refreshMonthView() {
    String[] days = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
    for (int col = 0; col < 7; col++) {
      calendarTable.getColumnModel().getColumn(col).setHeaderValue(days[col]);
    }

    for (int row = 0; row < 6; row++) {
      for (int col = 0; col < 7; col++) {
        calendarTable.setValueAt("", row, col);
      }
    }

    LocalDate firstOfMonth = currentMonth.withDayOfMonth(1);
    int startDay = firstOfMonth.getDayOfWeek().getValue() % 7; // Sunday = 0
    int daysInMonth = currentMonth.lengthOfMonth();

    int row = 0;
    int col = startDay;
    for (int day = 1; day <= daysInMonth; day++) {
      LocalDate date = currentMonth.withDayOfMonth(day);
      List<Event> events = controller.getEventsOnDate(date.atStartOfDay());
      StringBuilder cellText = new StringBuilder(String.valueOf(day));
      if (!events.isEmpty()) {
        cellText.append("\n").append(events.size()).append(" event(s)");
      }
      calendarTable.setValueAt(cellText.toString(), row, col);
      col++;
      if (col == 7) {
        col = 0;
        row++;
      }
    }
    calendarTable.repaint();
  }

  private void createNewCalendar() {
    JTextField nameField = new JTextField(10);
    timezoneComboBox = new JComboBox<>(ZoneId.getAvailableZoneIds().toArray(new String[0]));
    timezoneComboBox.setSelectedItem(ZoneId.systemDefault().getId());

    JPanel panel = new JPanel(new GridLayout(0, 2));
    panel.add(new JLabel("Calendar Name:"));
    panel.add(nameField);
    panel.add(new JLabel("Timezone:"));
    panel.add(timezoneComboBox);

    int result = JOptionPane.showConfirmDialog(this, panel, "Create New Calendar",
            JOptionPane.OK_CANCEL_OPTION);
    if (result == JOptionPane.OK_OPTION) {
      String name = nameField.getText().trim();
      String timezone = (String) timezoneComboBox.getSelectedItem();
      if (name.isEmpty()) {
        displayMessage("Calendar name cannot be empty.");
        return;
      }
      try {
        controller.createCalendar(name, timezone);
      } catch (IllegalArgumentException e) {
        displayMessage(e.getMessage());
      }
    }
  }

  private void createEventDialog(Event existingEvent) {
    JTextField subjectField = new JTextField(existingEvent != null ? existingEvent.getSubject() : "", 10);
    JTextField startDateField = new JTextField(existingEvent != null ?
            existingEvent.getStartDateTime().format(DATE_FORMATTER) : "", 10);
    JTextField startTimeField = new JTextField(existingEvent != null ?
            existingEvent.getStartDateTime().toLocalTime().toString() : "00:00", 5);
    JTextField endDateField = new JTextField(existingEvent != null ?
            existingEvent.getEndDateTime().format(DATE_FORMATTER) : "", 10);
    JTextField endTimeField = new JTextField(existingEvent != null ?
            existingEvent.getEndDateTime().toLocalTime().toString() : "00:00", 5);
    JTextField descriptionField = new JTextField(existingEvent != null ? existingEvent.getDescription() : "", 10);
    JTextField locationField = new JTextField(existingEvent != null ? existingEvent.getLocation() : "", 10);
    JCheckBox publicCheckBox = new JCheckBox("Public", existingEvent != null ? existingEvent.isPublic() : true);
    JCheckBox recurringCheckBox = new JCheckBox("Recurring");
    JPanel recurringPanel = new JPanel(new GridLayout(0, 2));
    JCheckBox[] dayCheckBoxes = new JCheckBox[7];
    String[] days = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
    for (int i = 0; i < 7; i++) {
      dayCheckBoxes[i] = new JCheckBox(days[i]);
      recurringPanel.add(dayCheckBoxes[i]);
    }
    JTextField endRecurrenceField = new JTextField("", 10);

    recurringPanel.add(new JLabel("End Recurrence (yyyy-MM-dd):"));
    recurringPanel.add(endRecurrenceField);
    recurringPanel.setVisible(false);
    recurringCheckBox.addActionListener(e -> recurringPanel.setVisible(recurringCheckBox.isSelected()));

    JPanel panel = new JPanel(new GridLayout(0, 2));
    panel.add(new JLabel("Subject:"));
    panel.add(subjectField);
    panel.add(new JLabel("Start Date (yyyy-MM-dd):"));
    panel.add(startDateField);
    panel.add(new JLabel("Start Time (HH:mm):"));
    panel.add(startTimeField);
    panel.add(new JLabel("End Date (yyyy-MM-dd):"));
    panel.add(endDateField);
    panel.add(new JLabel("End Time (HH:mm):"));
    panel.add(endTimeField);
    panel.add(new JLabel("Description:"));
    panel.add(descriptionField);
    panel.add(new JLabel("Location:"));
    panel.add(locationField);
    panel.add(new JLabel("Visibility:"));
    panel.add(publicCheckBox);
    panel.add(new JLabel("Recurring:"));
    panel.add(recurringCheckBox);
    panel.add(new JLabel("Recurring Days:"));
    panel.add(recurringPanel);

    int result = JOptionPane.showConfirmDialog(this, panel, existingEvent != null ? "Edit Event" : "Create Event",
            JOptionPane.OK_CANCEL_OPTION);
    if (result == JOptionPane.OK_OPTION) {
      try {
        String subject = subjectField.getText().trim();
        LocalDateTime start = LocalDateTime.parse(startDateField.getText() + "T" + startTimeField.getText(),
                DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm"));
        LocalDateTime end = LocalDateTime.parse(endDateField.getText() + "T" + endTimeField.getText(),
                DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm"));
        String description = descriptionField.getText().trim();
        String location = locationField.getText().trim();
        boolean isPublic = publicCheckBox.isSelected();

        if (subject.isEmpty() || description.isEmpty() || location.isEmpty()) {
          displayMessage("All fields must be filled.");
          return;
        }

        if (recurringCheckBox.isSelected()) {
          Set<DayOfWeek> recurringDays = new java.util.HashSet<>();
          for (int i = 0; i < 7; i++) {
            if (dayCheckBoxes[i].isSelected()) {
              recurringDays.add(DayOfWeek.of((i + 1) % 7 == 0 ? 7 : (i + 1) % 7));
            }
          }
          if (recurringDays.isEmpty()) {
            displayMessage("Select at least one day for recurrence.");
            return;
          }
          LocalDateTime endRecurrence = LocalDateTime.parse(endRecurrenceField.getText() + "T23:59",
                  DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm"));
          controller.createRecurringEvent(subject, start, end, description, location, isPublic,
                  recurringDays, endRecurrence);
        } else {
          if (existingEvent != null) {
            existingEvent.setSubject(subject);
            existingEvent.setStartDateTime(start);
            existingEvent.setEndDateTime(end);
            existingEvent.setDescription(description);
            existingEvent.setLocation(location);
            existingEvent.setPublic(isPublic);
            controller.editEvent(existingEvent, "subject", subject); // Trigger refresh
          } else {
            controller.createEvent(subject, start, end, description, location, isPublic);
          }
        }
      } catch (Exception e) {
        displayMessage("Error: " + e.getMessage());
      }
    }
  }

  private void editEventDialog() {
    int row = calendarTable.getSelectedRow();
    int col = calendarTable.getSelectedColumn();
    if (row < 0 || col < 0) {
      displayMessage("Please select a date to edit events.");
      return;
    }
    String value = (String) calendarTable.getValueAt(row, col);
    if (value == null || value.isEmpty()) {
      return;
    }
    int day = Integer.parseInt(value.split("\n")[0]);
    LocalDate selectedDate = currentMonth.withDayOfMonth(day);
    List<Event> events = controller.getEventsOnDate(selectedDate.atStartOfDay());
    if (events.isEmpty()) {
      displayMessage("No events to edit on this date.");
      return;
    }

    JComboBox<String> eventComboBox = new JComboBox<>(
            events.stream().map(Event::toString).toArray(String[]::new));
    JCheckBox multipleCheckBox = new JCheckBox("Edit all events with this subject from this date");
    JPanel panel = new JPanel(new GridLayout(0, 1));
    panel.add(new JLabel("Select Event:"));
    panel.add(eventComboBox);
    panel.add(multipleCheckBox);

    int result = JOptionPane.showConfirmDialog(this, panel, "Select Event to Edit",
            JOptionPane.OK_CANCEL_OPTION);
    if (result == JOptionPane.OK_OPTION) {
      int selectedIndex = eventComboBox.getSelectedIndex();
      Event selectedEvent = events.get(selectedIndex);
      if (multipleCheckBox.isSelected()) {
        JTextField propertyField = new JTextField(10);
        JTextField valueField = new JTextField(10);
        JPanel editPanel = new JPanel(new GridLayout(0, 2));
        editPanel.add(new JLabel("Property (subject, description, location):"));
        editPanel.add(propertyField);
        editPanel.add(new JLabel("New Value:"));
        editPanel.add(valueField);

        int editResult = JOptionPane.showConfirmDialog(this, editPanel, "Edit Multiple Events",
                JOptionPane.OK_CANCEL_OPTION);
        if (editResult == JOptionPane.OK_OPTION) {
          String property = propertyField.getText().trim().toLowerCase();
          String newValue = valueField.getText().trim();
          if (!property.equals("subject") && !property.equals("description") && !property.equals("location")) {
            displayMessage("Invalid property. Use 'subject', 'description', or 'location'.");
            return;
          }
          controller.editEvents(selectedEvent.getSubject(), selectedDate.atStartOfDay(),
                  property, newValue);
        }
      } else {
        createEventDialog(selectedEvent);
      }
    }
  }

  private void exportCalendar() {
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle("Export Calendar to CSV");
    if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
      String filePath = fileChooser.getSelectedFile().getAbsolutePath();
      if (!filePath.endsWith(".csv")) {
        filePath += ".csv";
      }
      controller.exportCalendar(filePath);
    }
  }

  private void importCalendar() {
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle("Import Calendar from CSV");
    if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
      String filePath = fileChooser.getSelectedFile().getAbsolutePath();
      controller.importCalendar(filePath);
    }
  }

  public void displayMessage(String message) {
    JOptionPane.showMessageDialog(this, message);
  }

  public void displayEvents(List<Event> events) {
    StringBuilder sb = new StringBuilder();
    for (Event event : events) {
      sb.append(event.toString()).append("\n");
    }
    eventsTextArea.setText(sb.toString());
  }
}