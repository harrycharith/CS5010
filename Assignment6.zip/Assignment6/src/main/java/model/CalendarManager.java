package model;

import java.util.HashMap;
import java.util.Map;

/**
 * Manages multiple Calendar instances, allowing for creation, retrieval, and switching between calendars.
 */
public class CalendarManager {
  private Map<String, Calendar> calendars;
  private String currentCalendarName;

  public CalendarManager() {
    this.calendars = new HashMap<>();
    this.currentCalendarName = null;
  }

  public void createCalendar(String name, String timezone) {
    if (calendars.containsKey(name)) {
      throw new IllegalArgumentException("Calendar with name '" + name + "' already exists.");
    }
    Calendar calendar = new Calendar(timezone); // Updated to match Calendar's constructor
    calendars.put(name, calendar);
    System.out.println("CalendarManager: Created calendar '" + name + "'. Total calendars: " + calendars.size());
    if (currentCalendarName == null) {
      currentCalendarName = name;
      System.out.println("CalendarManager: Set '" + name + "' as the default current calendar.");
    }
  }

  public void setCurrentCalendar(String name) {
    if (!calendars.containsKey(name)) {
      throw new IllegalArgumentException("Calendar '" + name + "' does not exist.");
    }
    currentCalendarName = name;
    System.out.println("CalendarManager: Switched to calendar '" + name + "'.");
  }

  public Calendar getCalendar(String name) {
    Calendar calendar = calendars.get(name);
    if (calendar == null) {
      throw new IllegalArgumentException("Calendar '" + name + "' does not exist.");
    }
    return calendar;
  }

  public Map<String, Calendar> getCalendars() {
    return new HashMap<>(calendars);
  }

  public String getCurrentCalendarName() {
    return currentCalendarName;
  }
}