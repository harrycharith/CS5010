package model;

import java.time.ZoneId;
import java.util.HashMap;
import java.util.Map;

/**
 * Manages a collection of calendars, including creation, editing, and selection.
 */
public class CalendarManager {
  private Map<String, Calendar> calendars;
  private String currentCalendarName;

  public CalendarManager() {
    this.calendars = new HashMap<>();
    this.currentCalendarName = null;

    // Create a default calendar in the user's timezone
    String defaultName = "Default";
    String defaultTimezone = ZoneId.systemDefault().getId();
    createCalendar(defaultName, defaultTimezone);
    setCurrentCalendar(defaultName);
  }

  public void createCalendar(String name, String timezone) {
    if (calendars.containsKey(name)) {
      throw new IllegalArgumentException("Calendar with name '" + name + "' already exists.");
    }
    Calendar calendar = new Calendar(timezone);
    calendars.put(name, calendar);
  }

  public Calendar getCalendar(String name) {
    Calendar calendar = calendars.get(name);
    if (calendar == null) {
      throw new IllegalArgumentException("Calendar with name '" + name + "' does not exist.");
    }
    return calendar;
  }

  public void setCurrentCalendar(String name) {
    if (!calendars.containsKey(name)) {
      throw new IllegalArgumentException("Calendar with name '" + name + "' does not exist.");
    }
    this.currentCalendarName = name;
  }

  public String getCurrentCalendarName() {
    return currentCalendarName;
  }

  public Map<String, Calendar> getCalendars() {
    return new HashMap<>(calendars);
  }

  public void editCalendar(String oldName, String property, String newValue) {
    Calendar calendar = getCalendar(oldName);
    switch (property.toLowerCase()) {
      case "name":
        if (calendars.containsKey(newValue)) {
          throw new IllegalArgumentException("Calendar with name '" + newValue + "' already exists.");
        }
        calendars.remove(oldName);
        calendars.put(newValue, calendar);
        if (currentCalendarName != null && currentCalendarName.equals(oldName)) {
          currentCalendarName = newValue;
        }
        break;
      case "timezone":
        calendar.setTimezone(newValue);
        break;
      default:
        throw new IllegalArgumentException("Invalid property: " + property);
    }
  }

  public void resetCalendars() {
    calendars.clear();
    currentCalendarName = null;
  }
}