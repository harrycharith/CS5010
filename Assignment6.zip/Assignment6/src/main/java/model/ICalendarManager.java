
package model;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Interface defining the contract for calendar model operations.
 */
public interface ICalendarManager {

  /**
   * Creates a new calendar with the specified name and timezone.
   */
  void createCalendar(String name, String timezone);

  /**
   * Sets the current calendar.
   */
  void setCurrentCalendar(String name);

  /**
   * Returns the name of the current calendar.
   */
  String getCurrentCalendarName();

  /**
   * Returns all calendars managed by the system.
   */
  Map<String, Calendar> getCalendars();

  /**
   * Creates a one-time event in the current calendar.
   */
  void createEvent(String subject, LocalDateTime start, LocalDateTime end,
                   String description, String location, boolean isPublic);

  /**
   * Creates a recurring event in the current calendar.
   */
  void createRecurringEvent(String subject, LocalDateTime start, LocalDateTime end,
                            String description, String location, boolean isPublic,
                            Set<java.time.DayOfWeek> days, LocalDateTime endRecurrence);

  /**
   * Edits a specific property of an existing event.
   */
  void editEvent(Event event, String property, String newValue);

  /**
   * Edits multiple events that match the subject from a given date.
   */
  void editEvents(String subject, LocalDateTime from, String property, String newValue);

  /**
   * Returns a list of events on the specified date.
   */
  List<Event> getEventsOnDate(LocalDateTime date);

  /**
   * Imports a calendar from a CSV file.
   */
  void importCalendar(String filePath);

  /**
   * Exports the current calendar to a CSV file.
   */
  void exportCalendar(String filePath);
}
