package util;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import model.Calendar;
import model.Event;

/**
 * Utility class for exporting the calendar to a CSV file.
 */
public class CSVExporter {
  /**
   * Exports the calendar to a CSV file.
   *
   * @param calendar the calendar to export
   * @param filePath the path to the CSV file
   */
  public static void exportToCSV(Calendar calendar, String filePath) {
    try (FileWriter writer = new FileWriter(filePath)) {
      // Write CSV header
      writer.write("Subject,Start Date,Start Time,End Date,End Time,Description,Location\n");

      // Write events
      List<Event> events = calendar.getAllEvents();
      for (Event event : events) {
        writer.write(
                String.format(
                        "%s,%s,%s,%s,%s,%s,%s\n",
                        event.getSubject(),
                        event.getStartDateTime().toLocalDate(),
                        event.getStartDateTime().toLocalTime(),
                        event.getEndDateTime() != null ? event.getEndDateTime().toLocalDate() : "",
                        event.getEndDateTime() != null ? event.getEndDateTime().toLocalTime() : "",
                        event.getDescription(),
                        event.getLocation()));
      }
    } catch (IOException e) {
      System.err.println("Error exporting calendar to CSV: " + e.getMessage());
    }
  }
}