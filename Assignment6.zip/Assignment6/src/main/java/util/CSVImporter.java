package util;

import model.Event;

import java.io.BufferedReader;
import java.io.FileReader;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class CSVImporter {
  private static final DateTimeFormatter GOOGLE_DATE_FORMATTER =
          DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss'Z'");

  public static List<Event> importFromCSV(String filePath) {
    List<Event> events = new ArrayList<>();
    try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
      String line = reader.readLine(); // Skip header
      while ((line = reader.readLine()) != null) {
        String[] parts = line.split(",");
        if (parts.length < 6) continue; // Skip malformed lines
        String subject = parts[0];
        LocalDateTime start = LocalDateTime.parse(parts[1], GOOGLE_DATE_FORMATTER);
        LocalDateTime end = LocalDateTime.parse(parts[2], GOOGLE_DATE_FORMATTER);
        String description = parts[3];
        String location = parts[4];
        boolean isPublic = parts[5].equalsIgnoreCase("Public");
        events.add(new Event(subject, start, end, description, location, isPublic));
      }
    } catch (Exception e) {
      throw new IllegalArgumentException("Error importing CSV: " + e.getMessage());
    }
    return events;
  }
}