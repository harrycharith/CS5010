package controller;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import model.Calendar;
import model.CalendarManager;
import model.Event;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import view.CalendarView;
import view.SimpleGUICalendarView;
import static org.junit.Assert.*;

/**
 * Unit tests for the CommandParser class.
 */
public class CommandParserTest {

  private CommandParser parser;
  private CalendarController controller;
  private CalendarManager calendarManager;
  private CalendarView textView;
  private SimpleGUICalendarView guiView;
  private static final DateTimeFormatter DATE_TIME_FORMATTER =
          DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");

  @Before
  public void setUp() {
    calendarManager = new CalendarManager();
    textView = new CalendarView();
    guiView = new SimpleGUICalendarView();
    controller = new CalendarController(calendarManager, textView, guiView);
    parser = new CommandParser(controller);
    // Pre-populate calendars for copy event tests
    controller.createCalendar("Source", "America/New_York");
    controller.createCalendar("Target", "America/Los_Angeles");
  }

  @After
  public void tearDown() {
    // Clean up any temporary files created during tests
    File file = new File("test_calendar.csv");
    if (file.exists()) {
      file.delete();
    }
  }

  /**
   * Tests parsing and executing a create calendar command.
   */
  @Test
  public void testCreateCalendar() {
    String command = "create calendar --name Work --timezone America/New_York";

    parser.parseCommand(command);

    Calendar calendar = calendarManager.getCalendar("Work");
    assertTrue(calendar != null);
    assertEquals("America/New_York", calendar.getTimezone().toString());
  }

  /**
   * Tests parsing and executing a create event command.
   */
  @Test
  public void testCreateEvent() {
    String command =
            "create event --subject Meeting " +
                    "--start 2025-04-09T09:00 " +
                    "--end 2025-04-09T10:00 " +
                    "--description Sync " +
                    "--location Office " +
                    "--public";

    parser.parseCommand(command);

    Calendar calendar = calendarManager.getCalendar("Source");
    List<Event> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    Event event = events.get(0);
    assertEquals("Meeting", event.getSubject());
    assertEquals(
            LocalDateTime.parse("2025-04-09T09:00", DATE_TIME_FORMATTER),
            event.getStartDateTime());
    assertEquals(
            LocalDateTime.parse("2025-04-09T10:00", DATE_TIME_FORMATTER),
            event.getEndDateTime());
    assertEquals("Sync", event.getDescription());
    assertEquals("Office", event.getLocation());
    assertTrue(event.isPublic());
  }

  /**
   * Tests parsing and executing a create all-day event command.
   */
  @Test
  public void testCreateAllDayEvent() {
    String command =
            "create event --subject Holiday " +
                    "--allDay 2025-04-09 " +
                    "--description Break " +
                    "--location Park " +
                    "--private";

    parser.parseCommand(command);

    Calendar calendar = calendarManager.getCalendar("Source");
    List<Event> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    Event event = events.get(0);
    assertEquals("Holiday", event.getSubject());
    assertEquals(
            LocalDateTime.parse("2025-04-09T00:00", DATE_TIME_FORMATTER),
            event.getStartDateTime());
    assertEquals(
            LocalDateTime.parse("2025-04-09T23:59", DATE_TIME_FORMATTER),
            event.getEndDateTime());
    assertEquals("Break", event.getDescription());
    assertEquals("Park", event.getLocation());
    assertTrue(!event.isPublic());
  }

  /**
   * Tests parsing and executing a copy event command when the event exists.
   */
  @Test
  public void testCopyEventWhenEventExists() {
    // Add an event to the source calendar
    LocalDateTime start = LocalDateTime.of(2025, 4, 9, 9, 0);
    LocalDateTime end = LocalDateTime.of(2025, 4, 9, 10, 0);
    controller.createEvent("Meeting", start, end, "Sync", "Office", true);

    String command =
            "copy event --subject Meeting " +
                    "--start 2025-04-09T09:00 " +
                    "--targetCalendar Target " +
                    "--targetStart 2025-04-10T09:00";

    parser.parseCommand(command);

    // Verify the event was copied to the target calendar
    Calendar targetCalendar = calendarManager.getCalendar("Target");
    List<Event> targetEvents = targetCalendar.getEventsOnDate(
            LocalDateTime.of(2025, 4, 10, 9, 0));
    assertEquals(1, targetEvents.size());
    Event copiedEvent = targetEvents.get(0);
    assertEquals("Meeting", copiedEvent.getSubject());
    assertEquals(
            LocalDateTime.parse("2025-04-10T09:00", DATE_TIME_FORMATTER),
            copiedEvent.getStartDateTime());
    assertEquals(
            LocalDateTime.parse("2025-04-10T10:00", DATE_TIME_FORMATTER),
            copiedEvent.getEndDateTime());
  }

  /**
   * Tests parsing and executing a set calendar command.
   */
  @Test
  public void testSetCalendar() {
    String command = "set calendar --name Target";

    parser.parseCommand(command);

    String currentCalendarName = calendarManager.getCurrentCalendarName();
    assertEquals("Target", currentCalendarName);
  }

  /**
   * Tests parsing and executing an export calendar command and verifying file creation.
   */
  @Test
  public void testExportCalendar() {
    // Add an event to the current calendar (Source)
    LocalDateTime start = LocalDateTime.of(2025, 4, 9, 9, 0);
    LocalDateTime end = LocalDateTime.of(2025, 4, 9, 10, 0);
    controller.createEvent("Meeting", start, end, "Sync", "Office", true);

    String command = "export calendar --file test_calendar.csv";

    parser.parseCommand(command);

    File file = new File("test_calendar.csv");
    assertTrue(file.exists());
  }
}