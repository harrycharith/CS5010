package controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import model.Calendar;
import model.Event;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;


/**
 * Unit tests for the CommandParser class.
 */
public class CommandParserTest {
  private CommandParser parser;
  private static final DateTimeFormatter DATE_TIME_FORMATTER =
          DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");
  private static final DateTimeFormatter DATE_FORMATTER =
          DateTimeFormatter.ofPattern("yyyy-MM-dd");

  @Before
  public void setUp() {
    parser = new CommandParser();
    Main.resetCalendars();
    Main.createCalendar("sourceCal", "America/New_York");
    Main.createCalendar("targetCal", "Europe/London");
    Main.setCurrentCalendar("sourceCal");
  }

  @Test
  public void testCreateCalendar() {
    String command = "create calendar --name testCal --timezone UTC";
    parser.parseCommand(command);

    Calendar cal = Main.getCalendar("testCal");
    assertNotNull(cal);
    assertEquals("UTC", cal.getTimezone().toString());
  }

  @Test
  public void testDateTimeParsing() {
    LocalDateTime time = LocalDateTime.parse("2025-10-15T14:00");
    assertNotNull(time); // Will fail if format is invalid
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateDuplicateCalendar() {
    String command = "create calendar --name sourceCal --timezone UTC";
    parser.parseCommand(command);
  }

  @Test
  public void testCreateEvent() {
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    String command = "create event --subject Meeting --start " + start.format(DATE_TIME_FORMATTER) +
            " --end " + end.format(DATE_TIME_FORMATTER) +
            " --description Team_meeting --location Room_1 --public";
    parser.parseCommand(command);

    Calendar cal = Main.getCalendar("sourceCal");
    List<Event> events = cal.getEventsOnDate(start);
    assertEquals(1, events.size());
    Event event = events.get(0);
    assertEquals("Meeting", event.getSubject());
    assertEquals(start, event.getStartDateTime());
    assertEquals(end, event.getEndDateTime());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateEventWithConflict() {
    LocalDateTime start1 = LocalDateTime.of(2025, 10, 15,
            14, 0);
    LocalDateTime end1 = LocalDateTime.of(2025, 10, 15, 15, 0);
    String command1 = "create event --subject Meeting1 --start "
            + start1.format(DATE_TIME_FORMATTER) +
            " --end " + end1.format(DATE_TIME_FORMATTER) +
            " --description Team_meeting_1 --location Room_1 --public";
    parser.parseCommand(command1);

    LocalDateTime start2 = LocalDateTime.of(2025, 10,
            15, 14, 30);
    LocalDateTime end2 = LocalDateTime.of(2025, 10,
            15, 15, 30);
    String command2 = "create event --subject Meeting2 --start "
            + start2.format(DATE_TIME_FORMATTER) +
            " --end " + end2.format(DATE_TIME_FORMATTER) +
            " --description Team_meeting_2 --location Room_2 --public";
    parser.parseCommand(command2);
  }

  @Test
  public void testCopyEvent() {
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    String createCommand = "create event --subject Meeting --start "
            + start.format(DATE_TIME_FORMATTER) +
            " --end " + end.format(DATE_TIME_FORMATTER) +
            " --description Team_meeting --location Room_1 --public";
    parser.parseCommand(createCommand);

    LocalDateTime targetStart = LocalDateTime.of(2025,
            10, 16, 0, 0);
    String copyCommand = "copy event --subject Meeting --start "
            + start.format(DATE_TIME_FORMATTER) +
            " --targetCalendar targetCal --targetStart " + targetStart.format(DATE_TIME_FORMATTER);
    parser.parseCommand(copyCommand);

    Calendar targetCal = Main.getCalendar("targetCal");
    List<Event> events = targetCal.getEventsOnDate(targetStart);
    assertEquals(1, events.size());
    Event copiedEvent = events.get(0);
    assertEquals("Meeting", copiedEvent.getSubject());
    assertEquals(LocalDateTime.of(2025, 10, 16, 14, 0),
            copiedEvent.getStartDateTime());
    assertEquals(LocalDateTime.of(2025, 10, 16, 15, 0),
            copiedEvent.getEndDateTime());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCopyEventToNonExistentCalendar() {
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    String createCommand = "create event --subject Meeting --start "
            + start.format(DATE_TIME_FORMATTER) +
            " --end " + end.format(DATE_TIME_FORMATTER)
            + " --description Team_meeting --location Room_1 --public";
    parser.parseCommand(createCommand);

    LocalDateTime targetStart = LocalDateTime.of(2025, 10, 16,
            0, 0);
    String copyCommand = "copy event --subject Meeting --start "
            + start.format(DATE_TIME_FORMATTER) +
            " --targetCalendar nonExistentCal --targetStart "
            + targetStart.format(DATE_TIME_FORMATTER);
    parser.parseCommand(copyCommand);
  }

  @Test
  public void testSetCalendar() {
    String command = "set calendar --name targetCal";
    parser.parseCommand(command);
    assertEquals("targetCal", Main.getCurrentCalendarName());
  }

  @Test
  public void testExportCalendar() throws Exception {
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    String createCommand = "create event --subject Meeting --start "
            + start.format(DATE_TIME_FORMATTER) +
            " --end " + end.format(DATE_TIME_FORMATTER)
            + " --description Team_meeting --location Room_1 --public";
    parser.parseCommand(createCommand);

    String exportCommand = "export calendar --file testEvents.csv";
    parser.parseCommand(exportCommand);

    java.nio.file.Path path = java.nio.file.Paths.get("testEvents.csv");
    assertTrue(java.nio.file.Files.exists(path));
    java.nio.file.Files.deleteIfExists(path); // Clean up after test
  }
}