package model;

import java.util.HashMap;
import java.util.Map;


/**
 * A test implementation of {@link CalendarManager} to track calendar creation and switching
 * operations for testing purposes.
 */
public class CalendarManagerTest extends CalendarManager {

  private Map<String, Calendar> calendars = new HashMap<>();
  private String currentCalendarName;

  /**
   * Creates a calendar with the specified name and timezone.
   *
   * @param name     the name of the calendar
   * @param timezone the timezone of the calendar
   */
  @Override
  public void createCalendar(String name, String timezone) {
    calendars.put(name, new Calendar(timezone));
    if (currentCalendarName == null) {
      currentCalendarName = name;
    }
  }

  /**
   * Sets the current calendar to the one with the specified name.
   *
   * @param name the name of the calendar to set as current
   * @throws IllegalArgumentException if the calendar does not exist
   */
  @Override
  public void setCurrentCalendar(String name) {
    if (!calendars.containsKey(name)) {
      throw new IllegalArgumentException("Calendar not found: " + name);
    }
    currentCalendarName = name;
  }

  /**
   * Gets the map of all calendars.
   *
   * @return a map of calendar names to Calendar objects
   */
  @Override
  public Map<String, Calendar> getCalendars() {
    return new HashMap<>(calendars);
  }

  /**
   * Gets the name of the current calendar.
   *
   * @return the name of the current calendar
   */
  @Override
  public String getCurrentCalendarName() {
    return currentCalendarName;
  }

  /**
   * Gets the calendar with the specified name.
   *
   * @param name the name of the calendar to retrieve
   * @return the Calendar object, or null if not found
   */
  @Override
  public Calendar getCalendar(String name) {
    return calendars.get(name);
  }
}