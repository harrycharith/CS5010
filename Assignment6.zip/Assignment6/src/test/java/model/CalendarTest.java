package model;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;


/**
 * Unit tests for the Calendar class.
 */
public class CalendarTest {
  private Calendar calendar;

  @Before
  public void setUp() {
    calendar = new Calendar("America/New_York");
  }

  @Test
  public void testAddEvent() {
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    Event event = new Event("Meeting", start, end, "Team meeting", "Room 1", true);
    assertTrue(calendar.addEvent(event));
    List<Event> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    assertEquals("Meeting", events.get(0).getSubject());
  }

  @Test
  public void testAddEventWithConflict() {
    LocalDateTime start1 = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end1 = LocalDateTime.of(2025, 10, 15, 15, 0);
    Event event1 = new Event("Meeting1", start1, end1, "Team meeting 1", "Room 1", true);
    assertTrue(calendar.addEvent(event1));

    LocalDateTime start2 = LocalDateTime.of(2025, 10, 15, 14, 30);
    LocalDateTime end2 = LocalDateTime.of(2025, 10, 15, 15, 30);
    Event event2 = new Event("Meeting2", start2, end2, "Team meeting 2", "Room 2", true);
    assertFalse(calendar.addEvent(event2));  // Should fail due to conflict
    assertEquals(1, calendar.getAllEvents().size());
  }

  @Test
  public void testGetEventsOnDate() {
    LocalDateTime start1 = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end1 = LocalDateTime.of(2025, 10, 15, 15, 0);
    Event event1 = new Event("Meeting1", start1, end1, "Team meeting 1", "Room 1", true);
    calendar.addEvent(event1);

    LocalDateTime start2 = LocalDateTime.of(2025, 10, 16, 10, 0);
    LocalDateTime end2 = LocalDateTime.of(2025, 10, 16, 11, 0);
    Event event2 = new Event("Meeting2", start2, end2, "Team meeting 2", "Room 2", true);
    calendar.addEvent(event2);

    List<Event> eventsOnDate = calendar.getEventsOnDate(LocalDateTime.of(2025, 10, 15, 0, 0));
    assertEquals(1, eventsOnDate.size());
    assertEquals("Meeting1", eventsOnDate.get(0).getSubject());
  }

  @Test
  public void testCopyEventsOnDate() {
    Calendar targetCalendar = new Calendar("Europe/London");  // Fixed: Added timezone
    LocalDateTime sourceStart = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime sourceEnd = LocalDateTime.of(2025, 10, 15, 15, 0);
    Event event = new Event("Meeting", sourceStart, sourceEnd, "Team meeting", "Room 1", true);
    calendar.addEvent(event);

    LocalDateTime targetStart = LocalDateTime.of(2025, 10, 16, 0, 0);
    calendar.copyEventsOnDate(sourceStart, targetStart, targetCalendar);

    List<Event> targetEvents = targetCalendar.getEventsOnDate(targetStart);
    assertEquals(1, targetEvents.size());
    Event copiedEvent = targetEvents.get(0);
    assertEquals("Meeting", copiedEvent.getSubject());
    assertEquals(LocalDateTime.of(2025, 10, 16, 14, 0), copiedEvent.getStartDateTime());
    assertEquals(LocalDateTime.of(2025, 10, 16, 15, 0), copiedEvent.getEndDateTime());
  }

  @Test
  public void testSetTimezone() {
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    Event event = new Event("Meeting", start, end, "Team meeting", "Room 1", true);
    calendar.addEvent(event);

    calendar.setTimezone("Europe/London");
    assertEquals(ZoneId.of("Europe/London"), calendar.getTimezone());
    assertEquals(1, calendar.getAllEvents().size());  // Events should remain unchanged
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidTimezone() {
    calendar.setTimezone("Invalid/Timezone");  // Should throw exception
  }
}