# Calendar Application
**Team**: Srihari and Shahana

## a. List of Changes to the Design

### Change 1: Timezone Support
Added timezone parameter to Calendar class with getter/setter methods to ensure proper timezone handling when copying events between different regions.

### Change 2: Event Copying Logic
Updated copyEventsOnDate to use ZonedDateTime for accurate time preservation during event transfers between calendars.

### Change 3: Testing Support
Added resetCalendars() method to Main class to clear calendar state between test runs.

### Change 4: Timezone Parsing
Enhanced timezone input handling to support both Region/City format and simple timezone identifiers.

### Change 5: Command Support
Implemented set calendar and export calendar commands for headless operation mode.

---

## b. Instructions on How to Run Your Program

### Requirements
- Java 11 or later
- Terminal/Command Prompt

### Running the Application

#### Interactive Mode
java -jar CalendarApp.jar --mode interactive

#### Headless Mode
java -jar CalendarApp.jar --mode headless [COMMAND_FILE]  

#### Available Commands

##### Calendar Operations
create calendar --name [NAME] --timezone [TZ]  
list calendars  
set calendar --name [NAME]  
delete calendar --name [NAME]  

##### Event Operations
create event --name [NAME] --start [YYYY-MM-DDTHH:MM] --end [YYYY-MM-DDTHH:MM]   
list events [--date YYYY-MM-DD]  
delete event --name [NAME] --date [YYYY-MM-DD]  

##### Export Operations
export calendar --file [FILENAME.csv]  

##### System Commands
help  
exit  

## c. Feature Status

### Implemented Features

Calendar creation and management
Event creation and copying
Timezone conversion
CSV export

### Unimplemented Features
GUI interface

## d. Contribution Distribution
### Srihari
Core calendar/event logic
Timezone implementation
Unit testing

### Shahana
Command parsing system
Application architecture
Build configuration

