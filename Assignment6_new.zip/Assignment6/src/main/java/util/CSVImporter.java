package util;

import model.Event;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

public class CSVImporter {
  private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
  private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm");

  public static List<Event> importFromCSV(String filePath) {
    List<Event> events = new ArrayList<>();
    try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
      String line;
      boolean firstLine = true;
      while ((line = br.readLine()) != null) {
        if (firstLine) {
          firstLine = false;
          continue; // Skip header
        }
        String[] data = line.split(",");
        // Expect 7 fields: subject, startDate, startTime, endDate, endTime, description, location
        // isPublic may be optional
        if (data.length < 7) {
          System.err.println("Skipping malformed line (expected at least 7 fields): " + line);
          continue; // Skip malformed lines
        }
        try {
          String subject = data[0].trim();
          // Parse start date and time
          String startDateStr = data[1].trim();
          String startTimeStr = data[2].trim();
          LocalDateTime startDateTime = LocalDateTime.parse(startDateStr + "T" + startTimeStr,
                  DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm"));
          // Parse end date and time
          String endDateStr = data[3].trim();
          String endTimeStr = data[4].trim();
          LocalDateTime endDateTime = LocalDateTime.parse(endDateStr + "T" + endTimeStr,
                  DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm"));
          String description = data[5].trim();
          String location = data[6].trim();
          // Handle isPublic (optional field)
          boolean isPublic = true; // Default to true if not specified
          if (data.length > 7) {
            isPublic = Boolean.parseBoolean(data[7].trim());
          }
          Event event = new Event(subject, startDateTime, endDateTime, description, location, isPublic);
          events.add(event);
        } catch (DateTimeParseException e) {
          System.err.println("Error parsing date/time in line: " + line + " - " + e.getMessage());
          continue; // Skip lines with invalid dates
        } catch (Exception e) {
          System.err.println("Error parsing line: " + line + " - " + e.getMessage());
          continue; // Skip lines with other parsing errors
        }
      }
    } catch (IOException e) {
      throw new IllegalArgumentException("Error reading CSV file: " + e.getMessage(), e);
    }
    return events;
  }
}