package view;

import java.util.List;
import model.Event;

/**
 * The view for the calendar application.
 * Handles displaying messages and events to the user.
 */
public class CalendarView {
  /**
   * Displays a message to the user.
   *
   * @param message the message to display
   */
  public void displayMessage(String message) {
    System.out.println(message);
  }

  /**
   * Displays a list of events.
   *
   * @param events the events to display
   */
  public void displayEvents(List<Event> events) {
    if (events.isEmpty()) {
      System.out.println("No events found.");
    } else {
      System.out.println("Events:");
      for (Event event : events) {
        System.out.println("- " + event);
      }
    }
  }
}