package view;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import model.Event;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Unit tests for CalendarView output rendering.
 */
public class CalendarViewTest {
  private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
  private final PrintStream originalOut = System.out;

  /** Redirects System.out to capture console output. */
  @Before
  public void setUpStreams() {
    System.setOut(new PrintStream(outContent));
  }

  /** Restores System.out and clears captured output. */
  @After
  public void restoreStreams() {
    System.setOut(originalOut);
    outContent.reset();
  }

  /** Tests displaying a simple message to the console. */
  @Test
  public void testDisplayMessage() {
    CalendarView view = new CalendarView();
    view.displayMessage("Test message");
    assertEquals("Test message\n", outContent.toString());
  }

  /** Tests displaying a list with one event. */
  @Test
  public void testDisplayEvents() {
    CalendarView view = new CalendarView();
    List<Event> events = new ArrayList<>();
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    events.add(new Event("Meeting", start, end, "Team meeting", "Room 1",
            true));
    view.displayEvents(events);

    String expected = "Events:\n" +
            "- Event: Meeting, Start: 2025-10-15T14:00, End: 2025-10-15T15:00, " +
            "Location: Room 1\n";
    assertEquals(expected, outContent.toString());
  }

  /** Tests displaying an empty list of events. */
  @Test
  public void testDisplayEmptyEvents() {
    CalendarView view = new CalendarView();
    List<Event> events = new ArrayList<>();
    view.displayEvents(events);
    assertEquals("No events found.\n", outContent.toString());
  }

  /** Tests displaying a list with an all-day event. */
  @Test
  public void testDisplayAllDayEvent() {
    CalendarView view = new CalendarView();
    List<Event> events = new ArrayList<>();
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 0, 0);
    events.add(new Event("Holiday", start, null, "Company holiday",
            "N/A", true));
    view.displayEvents(events);

    String expected = "Events:\n" +
            "- Event: Holiday, Start: 2025-10-15T00:00, End: All Day, Location: N/A\n";
    assertEquals(expected, outContent.toString());
  }
}