package controller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import model.CalendarManager;
import view.CalendarView;
import view.GUICalendarView;

/**
 * The main entry point for the calendar application.
 * Initializes the application in the appropriate mode (interactive, headless, or GUI).
 */
public class Main {
  public static void main(String[] args) {
    // Initialize the model
    CalendarManager calendarManager = new CalendarManager();

    // Determine the mode and initialize the appropriate components
    if (args.length > 0 && args[0].equalsIgnoreCase("--mode")) {
      String mode = args[1];
      if (mode.equalsIgnoreCase("headless")) {
        if (args.length < 3) {
          System.err.println("Error: Missing file path for headless mode.");
          return;
        }
        String filePath = args[2];
        runHeadlessMode(calendarManager, filePath);
      } else if (mode.equalsIgnoreCase("interactive")) {
        runInteractiveMode(calendarManager);
      } else {
        System.err.println("Error: Invalid mode. Use 'interactive', 'headless', or omit for GUI.");
      }
    } else {
      // Default to GUI mode
      runGUIMode(calendarManager);
    }
  }

  private static void runHeadlessMode(CalendarManager calendarManager, String filePath) {
    CalendarView textView = new CalendarView();
    CalendarController controller = new CalendarController(calendarManager, textView, null);
    CommandParser parser = new CommandParser(controller);

    try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
      String command;
      while ((command = reader.readLine()) != null) {
        command = command.trim();
        if (!command.isEmpty()) {
          parser.parseCommand(command);
        }
      }
    } catch (IOException e) {
      System.err.println("Error reading file: " + e.getMessage());
    }
  }

  private static void runInteractiveMode(CalendarManager calendarManager) {
    CalendarView textView = new CalendarView();
    CalendarController controller = new CalendarController(calendarManager, textView, null);
    CommandParser parser = new CommandParser(controller);

    Scanner scanner = new Scanner(System.in);
    while (true) {
      System.out.print("> ");
      String command = scanner.nextLine().trim();
      if (command.equalsIgnoreCase("exit")) {
        break;
      }
      parser.parseCommand(command);
    }
    scanner.close();
  }

  private static void runGUIMode(CalendarManager calendarManager) {
    javax.swing.SwingUtilities.invokeLater(() -> {
      CalendarController controller;
      GUICalendarView guiView = new GUICalendarView();
      controller = new CalendarController(calendarManager, null, guiView);
      guiView.controller = controller;
      // Create the default calendar and set it as current
      if (calendarManager.getCalendars().isEmpty()) {
        controller.createCalendar("Default Calendar", "America/New_York");
      }
      guiView.setVisible(true);
      // Initialize the GUI after setting the default calendar
      guiView.initialize();
    });
  }
}