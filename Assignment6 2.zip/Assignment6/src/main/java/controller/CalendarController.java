package controller;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import model.Calendar;
import model.CalendarManager;
import model.Event;
import model.RecurringEvent;
import util.CSVImporter;
import view.CalendarView;
import view.GUICalendarView;

/**
 * Controls the creation, management, and display of calendar events.
 * Acts as an intermediary between the CalendarManager model and views (text and GUI).
 */
public class CalendarController {
  private CalendarManager calendarManager;
  private CalendarView textView;
  private GUICalendarView guiView;

  public CalendarController(CalendarManager calendarManager, CalendarView textView, GUICalendarView guiView) {
    this.calendarManager = calendarManager;
    this.textView = textView;
    this.guiView = guiView;
  }

  public void createEvent(String subject, LocalDateTime startDateTime, LocalDateTime endDateTime,
                          String description, String location, boolean isPublic) {
    String currentCalendarName = calendarManager.getCurrentCalendarName();
    if (currentCalendarName == null) {
      notifyViews("No calendar selected. Please create or select a calendar first.");
      return;
    }
    Calendar calendar = calendarManager.getCalendar(currentCalendarName);
    Event event = new Event(subject, startDateTime, endDateTime, description, location, isPublic);
    boolean success = calendar.addEvent(event);
    if (success) {
      notifyViews("Event created successfully: " + event);
      if (guiView != null) {
        guiView.refreshMonthView();
        guiView.displayEvents(calendar.getEventsOnDate(startDateTime));
      }
    } else {
      notifyViews("Event creation failed due to conflict or duplicate.");
    }
  }

  public void createRecurringEvent(String subject, LocalDateTime startDateTime, LocalDateTime endDateTime,
                                   String description, String location, boolean isPublic,
                                   Set<DayOfWeek> recurringDays, LocalDateTime endRecurrence) {
    String currentCalendarName = calendarManager.getCurrentCalendarName();
    if (currentCalendarName == null) {
      notifyViews("No calendar selected. Please create or select a calendar first.");
      return;
    }
    Calendar calendar = calendarManager.getCalendar(currentCalendarName);
    RecurringEvent event = new RecurringEvent(subject, startDateTime, endDateTime, description,
            location, isPublic, recurringDays, endRecurrence);
    boolean success = calendar.addEvent(event);
    if (success) {
      notifyViews("Recurring event created successfully: " + event);
      if (guiView != null) {
        guiView.refreshMonthView();
        guiView.displayEvents(calendar.getEventsOnDate(startDateTime));
      }
    } else {
      notifyViews("Recurring event creation failed due to conflict or duplicate.");
    }
  }

  public void editEvent(Event event, String property, String newValue) {
    String currentCalendarName = calendarManager.getCurrentCalendarName();
    if (currentCalendarName == null) {
      notifyViews("No calendar selected. Please create or select a calendar first.");
      return;
    }
    Calendar calendar = calendarManager.getCalendar(currentCalendarName);
    calendar.editEvent(event, property, newValue);
    notifyViews("Event updated successfully: " + event);
    if (guiView != null) {
      guiView.refreshMonthView();
      guiView.displayEvents(calendar.getEventsOnDate(event.getStartDateTime()));
    }
  }

  public void editEvents(String subject, LocalDateTime startFrom, String property, String newValue) {
    String currentCalendarName = calendarManager.getCurrentCalendarName();
    if (currentCalendarName == null) {
      notifyViews("No calendar selected. Please create or select a calendar first.");
      return;
    }
    Calendar calendar = calendarManager.getCalendar(currentCalendarName);
    List<Event> events = calendar.findEventsStartingAtOrAfter(subject, startFrom);
    for (Event event : events) {
      calendar.editEvent(event, property, newValue);
    }
    notifyViews("Edited " + events.size() + " events with subject '" + subject + "'.");
    if (guiView != null) {
      guiView.refreshMonthView();
      guiView.displayEvents(calendar.getEventsOnDate(startFrom));
    }
  }

  public void showEventsOnDate(LocalDateTime date) {
    String currentCalendarName = calendarManager.getCurrentCalendarName();
    if (currentCalendarName == null) {
      notifyViews("No calendar selected. Please create or select a calendar first.");
      return;
    }
    Calendar calendar = calendarManager.getCalendar(currentCalendarName);
    List<Event> events = calendar.getEventsOnDate(date);
    if (textView != null) {
      textView.displayEvents(events);
    }
    if (guiView != null) {
      guiView.displayEvents(events);
    }
  }

  public void exportCalendar(String filePath) {
    String currentCalendarName = calendarManager.getCurrentCalendarName();
    if (currentCalendarName == null) {
      notifyViews("No calendar selected. Please create or select a calendar first.");
      return;
    }
    Calendar calendar = calendarManager.getCalendar(currentCalendarName);
    calendar.exportToCSV(filePath);
    notifyViews("Calendar exported to: " + filePath);
  }

  public void importCalendar(String filePath) {
    String currentCalendarName = calendarManager.getCurrentCalendarName();
    if (currentCalendarName == null) {
      notifyViews("No calendar selected. Please create or select a calendar first.");
      return;
    }
    Calendar calendar = calendarManager.getCalendar(currentCalendarName);
    try {
      List<Event> importedEvents = CSVImporter.importFromCSV(filePath);
      int successfulImports = 0;
      int duplicates = 0;
      int conflicts = 0;
      for (Event event : importedEvents) {
        // Check if the event is a duplicate by comparing all fields
        boolean isDuplicate = calendar.getAllEvents().stream().anyMatch(existingEvent ->
                existingEvent.getSubject().equals(event.getSubject()) &&
                        existingEvent.getStartDateTime().equals(event.getStartDateTime()) &&
                        (existingEvent.getEndDateTime() == null && event.getEndDateTime() == null ||
                                existingEvent.getEndDateTime() != null && existingEvent.getEndDateTime().equals(event.getEndDateTime())) &&
                        existingEvent.getDescription().equals(event.getDescription()) &&
                        existingEvent.getLocation().equals(event.getLocation()) &&
                        existingEvent.isPublic() == event.isPublic()
        );
        if (isDuplicate) {
          duplicates++;
          System.out.println("Skipped duplicate event during import: " + event);
          continue;
        }
        // Attempt to add the event
        boolean added = calendar.addEvent(event);
        if (added) {
          successfulImports++;
        } else {
          conflicts++;
          System.out.println("Skipped event due to conflict during import: " + event);
        }
      }
      StringBuilder message = new StringBuilder();
      message.append("Imported ").append(successfulImports).append(" events from: ").append(filePath);
      if (duplicates > 0) {
        message.append("\nSkipped ").append(duplicates).append(" duplicate events.");
      }
      if (conflicts > 0) {
        message.append("\nSkipped ").append(conflicts).append(" events due to conflicts.");
      }
      notifyViews(message.toString());
      if (guiView != null) {
        guiView.refreshMonthView();
      }
    } catch (IllegalArgumentException e) {
      notifyViews("Failed to import calendar: " + e.getMessage());
    }
  }

  public List<Event> getEventsOnDate(LocalDateTime date) {
    String currentCalendarName = calendarManager.getCurrentCalendarName();
    if (currentCalendarName == null) {
      return new ArrayList<>();
    }
    Calendar calendar = calendarManager.getCalendar(currentCalendarName);
    return calendar.getEventsOnDate(date);
  }

  public void createCalendar(String name, String timezone) {
    calendarManager.createCalendar(name, timezone);
    System.out.println("CalendarController: Created calendar '" + name + "'. Notifying GUI view.");
    notifyViews("Calendar '" + name + "' created successfully.");
    if (guiView != null) {
      guiView.updateCalendarList(calendarManager.getCalendars(), calendarManager.getCurrentCalendarName());
      System.out.println("CalendarController: Notified GUI view to update calendar list with " + calendarManager.getCalendars().size() + " calendars.");
    } else {
      System.out.println("CalendarController: No GUI view to notify.");
    }
  }

  public void setCurrentCalendar(String name) {
    if (name != null && name.equals(calendarManager.getCurrentCalendarName())) {
      System.out.println("CalendarController: Already on calendar '" + name + "'. No update needed.");
      return;
    }
    calendarManager.setCurrentCalendar(name);
    System.out.println("CalendarController: Switched to calendar '" + name + "'. Notifying GUI view.");
    notifyViews("Switched to calendar: " + name);
    if (guiView != null) {
      guiView.updateCalendarList(calendarManager.getCalendars(), calendarManager.getCurrentCalendarName());
      guiView.refreshMonthView();
      System.out.println("CalendarController: Notified GUI view to update calendar list and refresh month view.");
    }
  }

  public Map<String, Calendar> getCalendars() {
    return calendarManager.getCalendars();
  }

  public String getCurrentCalendarName() {
    return calendarManager.getCurrentCalendarName();
  }

  private void notifyViews(String message) {
    if (textView != null) {
      textView.displayMessage(message);
    }
    if (guiView != null) {
      guiView.displayMessage(message);
    }
  }
}