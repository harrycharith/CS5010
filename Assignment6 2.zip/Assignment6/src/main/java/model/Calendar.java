package model;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import util.CSVExporter;

/**
 * Represents a calendar that manages a collection of events in a specific timezone.
 */
public class Calendar {
  /** List to store events in the calendar. */
  private List<Event> events;

  /** The timezone for this calendar. */
  private ZoneId timezone;

  /**
   * Constructs a new Calendar with the specified timezone.
   *
   * @param timezone A string representation of the timezone (e.g., "America/New_York")
   * @throws IllegalArgumentException if the provided timezone is invalid
   */
  public Calendar(String timezone) {
    this.events = new ArrayList<>();
    try {
      this.timezone = ZoneId.of(timezone);
    } catch (Exception e) {
      throw new IllegalArgumentException("Invalid timezone: " + timezone);
    }
  }

  /**
   * Returns the timezone of the calendar.
   *
   * @return The ZoneId representing the calendar's timezone
   */
  public ZoneId getTimezone() {
    return timezone;
  }

  /**
   * Sets the timezone for the calendar.
   *
   * @param timezone A string representation of the new timezone
   * @throws IllegalArgumentException if the provided timezone is invalid
   */
  public void setTimezone(String timezone) {
    try {
      this.timezone = ZoneId.of(timezone);
    } catch (Exception e) {
      throw new IllegalArgumentException("Invalid timezone: " + timezone);
    }
  }

  /**
   * Adds an event to the calendar if there are no scheduling conflicts or duplicates.
   *
   * @param event The event to be added
   * @return true if the event was added successfully, false if there is a conflict or duplicate
   */
  public boolean addEvent(Event event) {
    // Check for duplicates first
    if (isDuplicate(event)) {
      System.out.println("Duplicate event detected: " + event);
      return false;
    }
    // Check for conflicts
    if (hasConflict(event)) {
      System.out.println("Conflict detected with event: " + event);
      return false;
    }
    events.add(event);
    return true;
  }

  /**
   * Checks if the given event is a duplicate of an existing event.
   *
   * @param event The event to check
   * @return true if the event is a duplicate, false otherwise
   */
  private boolean isDuplicate(Event event) {
    return events.stream().anyMatch(existingEvent ->
            existingEvent.getSubject().equals(event.getSubject()) &&
                    existingEvent.getStartDateTime().equals(event.getStartDateTime()) &&
                    (existingEvent.getEndDateTime() == null && event.getEndDateTime() == null ||
                            existingEvent.getEndDateTime() != null && existingEvent.getEndDateTime().equals(event.getEndDateTime())) &&
                    existingEvent.getDescription().equals(event.getDescription()) &&
                    existingEvent.getLocation().equals(event.getLocation()) &&
                    existingEvent.isPublic() == event.isPublic()
    );
  }

  /**
   * Checks if the given event conflicts with any existing events.
   *
   * @param event The event to check for conflicts
   * @return true if there is a conflict, false otherwise
   */
  private boolean hasConflict(Event event) {
    return events.stream().anyMatch(existingEvent -> existingEvent.conflictsWith(event));
  }

  /**
   * Retrieves all events scheduled on a specific date.
   *
   * @param date The date to search for events
   * @return A list of events on the specified date
   */
  public List<Event> getEventsOnDate(LocalDateTime date) {
    List<Event> eventsOnDate = new ArrayList<>();
    for (Event event : events) {
      if (event.getStartDateTime().toLocalDate().equals(date.toLocalDate())) {
        eventsOnDate.add(event);
      }
    }
    return eventsOnDate;
  }

  /**
   * Returns a copy of all events in the calendar.
   *
   * @return A list of all events
   */
  public List<Event> getAllEvents() {
    return new ArrayList<>(events);
  }

  /**
   * Exports all events in the calendar to a CSV file.
   *
   * @param filePath The file path where the CSV will be saved
   */
  public void exportToCSV(String filePath) {
    CSVExporter.exportToCSV(this, filePath);
  }

  /**
   * Checks if the calendar is busy at a specific date and time.
   *
   * @param dateTime The date and time to check for availability
   * @return true if there is an event at the specified time, false otherwise
   */
  public boolean isBusy(LocalDateTime dateTime) {
    for (Event event : events) {
      if ((event.getStartDateTime().isBefore(dateTime)
              || event.getStartDateTime().isEqual(dateTime))
              && (event.getEndDateTime() == null || event.getEndDateTime().isAfter(dateTime))) {
        return true;
      }
    }
    return false;
  }

  /**
   * Finds an event with a specific subject and start time.
   *
   * @param subject The subject of the event
   * @param startDateTime The start time of the event
   * @return The matching event, or null if no event is found
   */
  public Event findEvent(String subject, LocalDateTime startDateTime) {
    for (Event event : events) {
      if (event.getSubject().equals(subject) && event.getStartDateTime().equals(startDateTime)) {
        return event;
      }
    }
    return null;
  }

  /**
   * Finds events with a specific subject starting at or after a given time.
   *
   * @param subject The subject of the events
   * @param startDateTime The start time to search from
   * @return A list of matching events
   */
  public List<Event> findEventsStartingAtOrAfter(String subject, LocalDateTime startDateTime) {
    List<Event> matchingEvents = new ArrayList<>();
    for (Event event : events) {
      if (event.getSubject().equals(subject) &&
              (event.getStartDateTime().isEqual(startDateTime)
                      || event.getStartDateTime().isAfter(startDateTime))) {
        matchingEvents.add(event);
      }
    }
    return matchingEvents;
  }

  /**
   * Edits a specific property of an event.
   *
   * @param event The event to edit
   * @param property The property to modify (subject, location, or description)
   * @param newValue The new value for the property
   * @throws IllegalArgumentException if an invalid property is specified
   */
  public void editEvent(Event event, String property, String newValue) {
    switch (property.toLowerCase()) {
      case "subject":
        event.setSubject(newValue);
        break;
      case "location":
        event.setLocation(newValue);
        break;
      case "description":
        event.setDescription(newValue);
        break;
      default:
        throw new IllegalArgumentException("Invalid property: " + property);
    }
  }

  /**
   * Copies an event to another calendar at a specified start time.
   *
   * @param event The event to copy
   * @param targetStart The start time for the copied event in the target calendar
   * @param targetCalendar The calendar to copy the event to
   * @throws IllegalArgumentException if the event cannot be added to the target calendar
   */
  public void copyEvent(Event event, LocalDateTime targetStart, Calendar targetCalendar) {
    long durationMinutes = event.getEndDateTime() != null ?
            java.time.Duration.between(event.getStartDateTime(),
                    event.getEndDateTime()).toMinutes() : 0;
    LocalDateTime newStart = targetStart;
    LocalDateTime newEnd = durationMinutes > 0 ? newStart.plusMinutes(durationMinutes) : null;

    Event copiedEvent = new Event(
            event.getSubject(),
            newStart,
            newEnd,
            event.getDescription(),
            event.getLocation(),
            event.isPublic()
    );

    if (!targetCalendar.addEvent(copiedEvent)) {
      throw new IllegalArgumentException("Cannot copy event due to conflict in target calendar.");
    }
  }

  /**
   * Copies all events from a specific date to another calendar.
   *
   * @param date The date of events to copy
   * @param targetStart The start time for the copied events in the target calendar
   * @param targetCalendar The calendar to copy the events to
   * @throws IllegalArgumentException if any event cannot be added to the target calendar
   */
  public void copyEventsOnDate(LocalDateTime date, LocalDateTime targetStart,
                               Calendar targetCalendar) {
    List<Event> eventsToCopy = getEventsOnDate(date);
    ZonedDateTime targetDayStart = targetStart.toLocalDate().
            atStartOfDay(targetCalendar.getTimezone());

    for (Event event : eventsToCopy) {
      ZonedDateTime sourceStart = event.getStartDateTime().atZone(this.timezone);
      ZonedDateTime sourceDayStart = sourceStart.toLocalDate().atStartOfDay(this.timezone);
      long offsetMinutes = java.time.Duration.between(sourceDayStart, sourceStart).toMinutes();

      LocalDateTime newStart = targetDayStart.plusMinutes(offsetMinutes).toLocalDateTime();
      long durationMinutes = event.getEndDateTime() != null ?
              java.time.Duration.between(event.getStartDateTime(),
                      event.getEndDateTime()).toMinutes() : 0;
      LocalDateTime newEnd = durationMinutes > 0 ? newStart.plusMinutes(durationMinutes) : null;

      Event copiedEvent = new Event(
              event.getSubject(),
              newStart,
              newEnd,
              event.getDescription(),
              event.getLocation(),
              event.isPublic()
      );

      if (!targetCalendar.addEvent(copiedEvent)) {
        throw new IllegalArgumentException("Cannot copy event '" + event.getSubject()
                + "' due to conflict in target calendar.");
      }
    }
  }

  /**
   * Copies events within a specified date range to another calendar.
   *
   * @param startDate The start of the date range to copy events from
   * @param endDate The end of the date range to copy events from
   * @param targetStart The start time for the copied events in the target calendar
   * @param targetCalendar The calendar to copy the events to
   * @throws IllegalArgumentException if any event cannot be added to the target calendar
   */
  public void copyEventsInRange(
          LocalDateTime startDate,
          LocalDateTime endDate,
          LocalDateTime targetStart,
          Calendar targetCalendar) {
    ZonedDateTime targetStartZoned = targetStart.atZone(targetCalendar.getTimezone());
    ZonedDateTime sourceRangeStart = startDate.toLocalDate().atStartOfDay(this.timezone);

    for (Event event : events) {
      LocalDateTime eventStart = event.getStartDateTime();
      if (eventStart.toLocalDate().isEqual(startDate.toLocalDate()) ||
              eventStart.toLocalDate().isEqual(endDate.toLocalDate()) ||
              (eventStart.toLocalDate().isAfter(startDate.toLocalDate()) &&
                      eventStart.toLocalDate().isBefore(endDate.toLocalDate()))) {
        ZonedDateTime sourceStart = eventStart.atZone(this.timezone);
        long offsetDays = java.time.Duration.between(
                sourceRangeStart, eventStart.toLocalDate().atStartOfDay(this.timezone)).toDays();
        long offsetMinutes = java.time.Duration.between(
                eventStart.toLocalDate().atStartOfDay(this.timezone), sourceStart).toMinutes();

        LocalDateTime newStart = targetStartZoned.plusDays(offsetDays).plusMinutes(offsetMinutes)
                .withZoneSameInstant(targetCalendar.getTimezone()).toLocalDateTime();
        long durationMinutes = event.getEndDateTime() != null ?
                java.time.Duration.between(event.getStartDateTime(),
                        event.getEndDateTime()).toMinutes() : 0;
        LocalDateTime newEnd = durationMinutes > 0 ? newStart.plusMinutes(durationMinutes) : null;

        Event copiedEvent = new Event(
                event.getSubject(),
                newStart,
                newEnd,
                event.getDescription(),
                event.getLocation(),
                event.isPublic()
        );

        if (!targetCalendar.addEvent(copiedEvent)) {
          throw new IllegalArgumentException("Cannot copy event '" + event.getSubject()
                  + "' due to conflict in target calendar.");
        }
      }
    }
  }
}