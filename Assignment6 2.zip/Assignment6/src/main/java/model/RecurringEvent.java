package model;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.Set;

/**
 * Represents a recurring calendar event that repeats on specified days.
 */
public class RecurringEvent extends Event {
  private Set<DayOfWeek> recurringDays;
  private LocalDateTime endRecurrence;

  /**
   * Constructs a new RecurringEvent with the specified properties.
   *
   * @param subject the event subject
   * @param startDateTime the start date and time
   * @param endDateTime the end date and time
   * @param description the event description
   * @param location the event location
   * @param isPublic whether the event is public
   * @param recurringDays the days of the week the event repeats
   * @param endRecurrence the end date for the recurrence
   */
  public RecurringEvent(
          String subject,
          LocalDateTime startDateTime,
          LocalDateTime endDateTime,
          String description,
          String location,
          boolean isPublic,
          Set<DayOfWeek> recurringDays,
          LocalDateTime endRecurrence) {
    super(subject, startDateTime, endDateTime, description, location, isPublic);
    this.recurringDays = recurringDays;
    this.endRecurrence = endRecurrence;
  }

  /**
   * Returns the days of the week this event recurs on.
   *
   * @return the set of recurring days
   */
  public Set<DayOfWeek> getRecurringDays() {
    return recurringDays;
  }

  /**
   * Sets the days of the week this event recurs on.
   *
   * @param recurringDays the new set of recurring days
   */
  public void setRecurringDays(Set<DayOfWeek> recurringDays) {
    this.recurringDays = recurringDays;
  }

  /**
   * Returns the end date of the recurrence.
   *
   * @return the recurrence end date
   */
  public LocalDateTime getEndRecurrence() {
    return endRecurrence;
  }

  /**
   * Sets the end date of the recurrence.
   *
   * @param endRecurrence the new recurrence end date
   */
  public void setEndRecurrence(LocalDateTime endRecurrence) {
    this.endRecurrence = endRecurrence;
  }

  /**
   * Checks if this recurring event conflicts with another event across its recurrence period.
   *
   * @param other the other event to check for conflicts
   * @return true if there is a conflict, false otherwise
   */
  @Override
  public boolean conflictsWith(CalendarEvent other) {
    LocalDateTime currentStart = this.getStartDateTime();
    LocalDateTime currentEnd = this.getEndDateTime();

    while (currentStart.isBefore(endRecurrence)) {
      if (recurringDays.contains(currentStart.getDayOfWeek())) {
        Event currentEvent =
                new Event(
                        this.getSubject(),
                        currentStart,
                        currentEnd,
                        this.getDescription(),
                        this.getLocation(),
                        this.isPublic());
        if (currentEvent.conflictsWith(other)) {
          return true;
        }
      }
      currentStart = currentStart.plusDays(1);
      currentEnd = currentEnd.plusDays(1);
    }
    return false;
  }

  /**
   * Returns a string representation of this recurring event.
   *
   * @return the formatted string
   */
  @Override
  public String toString() {
    return String.format(
            "Recurring Event: %s, Start: %s, End: %s, Repeats on: %s, Until: %s",
            getSubject(),
            getStartDateTime(),
            getEndDateTime(),
            recurringDays,
            endRecurrence);
  }
}