package controller;

import java.io.File;
import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;
import model.Calendar;
import model.CalendarManager;
import model.Event;
import model.RecurringEvent;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import view.CalendarView;
import view.SimpleGUICalendarView;
import static org.junit.Assert.*;

/**
 * Unit tests for the CalendarController class.
 */
public class CalendarControllerTest {

  private CalendarController controller;
  private CalendarManager calendarManager;
  private CalendarView textView;
  private SimpleGUICalendarView guiView;

  @Before
  public void setUp() {
    calendarManager = new CalendarManager();
    textView = new CalendarView();
    guiView = new SimpleGUICalendarView();
    controller = new CalendarController(calendarManager, textView, guiView);
    // Create a default calendar for testing
    controller.createCalendar("Default", "America/New_York");
    controller.setCurrentCalendar("Default");
  }

  @After
  public void tearDown() {
    // Clean up any temporary files created during tests
    File file = new File("test_export_calendar.csv");
    if (file.exists()) {
      file.delete();
    }
  }

  /**
   * Tests creating a new calendar and verifying its timezone.
   */
  @Test
  public void testCreateCalendar() {
    controller.createCalendar("Work", "America/Los_Angeles");

    Calendar calendar = calendarManager.getCalendar("Work");
    assertTrue(calendar != null);
    assertEquals("America/Los_Angeles", calendar.getTimezone().toString());
  }

  /**
   * Tests setting the current calendar.
   */
  @Test
  public void testSetCurrentCalendar() {
    controller.createCalendar("Work", "America/Los_Angeles");
    controller.setCurrentCalendar("Work");

    String currentCalendarName = calendarManager.getCurrentCalendarName();
    assertEquals("Work", currentCalendarName);
  }

  /**
   * Tests creating a single event.
   */
  @Test
  public void testCreateEvent() {
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    controller.createEvent("Meeting", start, end, "Team meeting", "Room 1", true);

    Calendar calendar = calendarManager.getCalendar("Default");
    List<Event> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    Event event = events.get(0);
    assertEquals("Meeting", event.getSubject());
    assertEquals(start, event.getStartDateTime());
    assertEquals(end, event.getEndDateTime());
    assertEquals("Team meeting", event.getDescription());
    assertEquals("Room 1", event.getLocation());
    assertTrue(event.isPublic());
  }

  /**
   * Tests creating a recurring event.
   */
  @Test
  public void testCreateRecurringEvent() {
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    LocalDateTime endRecurrence = LocalDateTime.of(2025, 10, 22, 23, 59);
    Set<DayOfWeek> recurringDays = EnumSet.of(DayOfWeek.WEDNESDAY); // Oct 15, 2025 is a Wednesday

    controller.createRecurringEvent(
            "Weekly Meeting", start, end, "Weekly team sync", "Room 1",
            true, recurringDays, endRecurrence);

    Calendar calendar = calendarManager.getCalendar("Default");
    List<Event> events = calendar.getEventsOnDate(start);
    assertEquals(1, events.size());
    Event event = events.get(0);
    assertTrue(event instanceof RecurringEvent);
    RecurringEvent recurringEvent = (RecurringEvent) event;
    assertEquals("Weekly Meeting", recurringEvent.getSubject());
    assertEquals(start, recurringEvent.getStartDateTime());
    assertEquals(end, recurringEvent.getEndDateTime());
    assertEquals(recurringDays, recurringEvent.getRecurringDays());
    assertEquals(endRecurrence, recurringEvent.getEndRecurrence());
  }

  /**
   * Tests showing events on a specific date.
   */
  @Test
  public void testShowEventsOnDate() {
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    controller.createEvent("Meeting", start, end, "Team meeting", "Room 1", true);

    LocalDateTime date = LocalDateTime.of(2025, 10, 15, 0, 0);
    controller.showEventsOnDate(date);

    Calendar calendar = calendarManager.getCalendar("Default");
    List<Event> events = calendar.getEventsOnDate(date);
    assertEquals(1, events.size());
    assertEquals("Meeting", events.get(0).getSubject());
  }

  /**
   * Tests exporting the calendar to a CSV file.
   */
  @Test
  public void testExportCalendar() {
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    controller.createEvent("Meeting", start, end, "Team meeting", "Room 1", true);

    String filePath = "test_export_calendar.csv";
    controller.exportCalendar(filePath);

    File file = new File(filePath);
    assertTrue(file.exists());
  }
}