package controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import model.Calendar;
import model.Event;


/**
 * A test implementation of CalendarController to track method calls for CommandParser testing.
 */
public class TestCalendarController extends CalendarController {

  private List<String> createdCalendars = new ArrayList<>();
  private List<String> createdCalendarTimezones = new ArrayList<>();
  private List<Event> createdEvents = new ArrayList<>();
  private List<String> setCalendars = new ArrayList<>();
  private List<String> exportedFiles = new ArrayList<>();
  private Map<String, Calendar> calendars = new HashMap<>();
  private String currentCalendarName = "Source";

  // Constructor matching the real CalendarController
  public TestCalendarController() {
    super(null, null, null); // Pass null since we don't need the real dependencies
  }

  @Override
  public void createCalendar(String name, String timezone) {
    createdCalendars.add(name);
    createdCalendarTimezones.add(timezone);
    calendars.put(name, new Calendar(timezone));
  }

  @Override
  public void createEvent(String subject, LocalDateTime startDateTime,
                          LocalDateTime endDateTime, String description, String location, boolean isPublic) {
    Event event = new Event(subject, startDateTime, endDateTime, description, location, isPublic);
    createdEvents.add(event);
    // Add the event to the current calendar for copy event testing
    calendars.get(currentCalendarName).addEvent(event);
  }

  @Override
  public void setCurrentCalendar(String name) {
    setCalendars.add(name);
    currentCalendarName = name;
  }

  @Override
  public void exportCalendar(String filePath) {
    exportedFiles.add(filePath);
  }

  @Override
  public Map<String, Calendar> getCalendars() {
    return new HashMap<>(calendars);
  }

  @Override
  public String getCurrentCalendarName() {
    return currentCalendarName;
  }

  // Methods to access tracked data for verification
  public List<String> getCreatedCalendars() {
    return createdCalendars;
  }

  public List<String> getCreatedCalendarTimezones() {
    return createdCalendarTimezones;
  }

  public List<Event> getCreatedEvents() {
    return createdEvents;
  }

  public List<String> getSetCalendars() {
    return setCalendars;
  }

  public List<String> getExportedFiles() {
    return exportedFiles;
  }
}