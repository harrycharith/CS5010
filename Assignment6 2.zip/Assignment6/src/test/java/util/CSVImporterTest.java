package util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;
import model.Event;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;


/**
 * Unit tests for the CSVImporter class.
 */
public class CSVImporterTest {

  private static final String TEST_FILE = "test_import.csv";

  @Before
  public void setUp() throws IOException {
    // Create a sample CSV file for testing
    try (FileWriter writer = new FileWriter(TEST_FILE)) {
      writer.write("Subject,Start Date,Start Time,End Date,End Time,Description,Location,Is Public\n");
      writer.write("Meeting,2025-10-15,14:00,2025-10-15,15:00,Team sync,Room 1,true\n");
      writer.write("Planning,2025-10-16,10:00,2025-10-16,11:00,Plan Q4,Room 2,false\n");
    }
  }

  @After
  public void tearDown() {
    // Clean up the test file
    File file = new File(TEST_FILE);
    if (file.exists()) {
      file.delete();
    }
  }

  /**
   * Tests importing events from a valid CSV file.
   */
  @Test
  public void testImportFromCSVValidFile() {
    List<Event> events = CSVImporter.importFromCSV(TEST_FILE);
    assertEquals(2, events.size());

    Event event1 = events.get(0);
    assertEquals("Meeting", event1.getSubject());
    assertEquals(LocalDateTime.of(2025, 10, 15, 14, 0), event1.getStartDateTime());
    assertEquals(LocalDateTime.of(2025, 10, 15, 15, 0), event1.getEndDateTime());
    assertEquals("Team sync", event1.getDescription());
    assertEquals("Room 1", event1.getLocation());
    assertTrue(event1.isPublic());

    Event event2 = events.get(1);
    assertEquals("Planning", event2.getSubject());
    assertEquals(LocalDateTime.of(2025, 10, 16, 10, 0), event2.getStartDateTime());
    assertEquals(LocalDateTime.of(2025, 10, 16, 11, 0), event2.getEndDateTime());
    assertEquals("Plan Q4", event2.getDescription());
    assertEquals("Room 2", event2.getLocation());
    assertFalse(event2.isPublic());
  }

  /**
   * Tests importing from a CSV file with a malformed line.
   */
  @Test
  public void testImportFromCSVMalformedLine() throws IOException {
    try (FileWriter writer = new FileWriter(TEST_FILE)) {
      writer.write("Subject,Start Date,Start Time,End Date,End Time,Description,Location\n");
      writer.write("Meeting,2025-10-15,14:00,2025-10-15,15:00,Team sync,Room 1\n");
      writer.write("Invalid,2025-10-16,10:00,,,,\n"); // Malformed line
    }

    List<Event> events = CSVImporter.importFromCSV(TEST_FILE);
    assertEquals(1, events.size());
    assertEquals("Meeting", events.get(0).getSubject());
  }

  /**
   * Tests importing from a CSV file with invalid date/time.
   */
  @Test
  public void testImportFromCSVInvalidDateTime() throws IOException {
    try (FileWriter writer = new FileWriter(TEST_FILE)) {
      writer.write("Subject,Start Date,Start Time,End Date,End Time,Description,Location\n");
      writer.write("Meeting,2025-10-15,14:00,2025-10-15,15:00,Team sync,Room 1\n");
      writer.write("Planning,invalid-date,10:00,2025-10-16,11:00,Plan Q4,Room 2\n");
    }

    List<Event> events = CSVImporter.importFromCSV(TEST_FILE);
    assertEquals(1, events.size());
    assertEquals("Meeting", events.get(0).getSubject());
  }

  /**
   * Tests importing from a non-existent file.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testImportFromCSVNonExistentFile() {
    File file = new File(TEST_FILE);
    if (file.exists()) {
      file.delete();
    }
    CSVImporter.importFromCSV(TEST_FILE);
  }
}