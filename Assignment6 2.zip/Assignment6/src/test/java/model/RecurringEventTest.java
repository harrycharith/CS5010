package model;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Unit tests for the RecurringEvent class.
 */
public class RecurringEventTest {
  /**
   * Tests creating a recurring event and verifying its properties.
   */
  @Test
  public void testRecurringEventCreation() {
    LocalDateTime start = LocalDateTime.of(2025, 10, 16, 9, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 16, 9, 30);
    LocalDateTime endRecurrence = LocalDateTime.of(2025, 10, 30, 9,
            30);
    Set<DayOfWeek> recurringDays = new HashSet<>();
    recurringDays.add(DayOfWeek.MONDAY);
    recurringDays.add(DayOfWeek.WEDNESDAY);
    recurringDays.add(DayOfWeek.FRIDAY);

    RecurringEvent event =
            new RecurringEvent(
                    "Standup",
                    start,
                    end,
                    "Daily standup",
                    "Zoom",
                    true,
                    recurringDays,
                    endRecurrence);

    assertEquals("Standup", event.getSubject());
    assertEquals(start, event.getStartDateTime());
    assertEquals(end, event.getEndDateTime());
    assertEquals(recurringDays, event.getRecurringDays());
    assertEquals(endRecurrence, event.getEndRecurrence());
    assertEquals("Daily standup", event.getDescription());
    assertTrue(event.isPublic());
  }

  /**
   * Tests the conflictsWith method with a recurring event against conflicting and non-conflicting
   * events.
   */
  @Test
  public void testConflictsWith() {
    LocalDateTime start = LocalDateTime.of(2025, 10, 16, 9, 0);
    // Thursday
    LocalDateTime end = LocalDateTime.of(2025, 10, 16, 9, 30);
    LocalDateTime endRecurrence = LocalDateTime.of(2025, 10, 30, 9,
            30);
    Set<DayOfWeek> recurringDays = new HashSet<>();
    recurringDays.add(DayOfWeek.MONDAY);
    recurringDays.add(DayOfWeek.WEDNESDAY);
    recurringDays.add(DayOfWeek.FRIDAY);

    RecurringEvent recurringEvent =
            new RecurringEvent(
                    "Standup",
                    start,
                    end,
                    "Daily standup",
                    "Zoom",
                    true,
                    recurringDays,
                    endRecurrence);

    // Conflict test (Friday)
    Event conflictingEvent =
            new Event(
                    "Meeting",
                    LocalDateTime.of(2025, 10, 17, 9, 15),
                    LocalDateTime.of(2025, 10, 17, 10, 0),
                    "Team meeting",
                    "Room 1",
                    true);
    assertEquals(true, recurringEvent.conflictsWith(conflictingEvent));

    // Non-conflict test (Tuesday)
    Event nonConflictingEvent =
            new Event(
                    "Lunch",
                    LocalDateTime.of(2025, 10, 21, 12, 0),
                    LocalDateTime.of(2025, 10, 21, 13, 0),
                    "Lunch break",
                    "Cafeteria",
                    true);
    assertFalse(recurringEvent.conflictsWith(nonConflictingEvent));
  }

  /**
   * Tests the conflictsWith method with an event beyond the recurrence period.
   */
  @Test
  public void testConflictsWithBeyondRecurrence() {
    LocalDateTime start = LocalDateTime.of(2025, 10, 16, 9, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 16, 9, 30);
    LocalDateTime endRecurrence = LocalDateTime.of(2025, 10, 30, 9,
            30);
    Set<DayOfWeek> recurringDays = new HashSet<>();
    recurringDays.add(DayOfWeek.MONDAY);

    RecurringEvent recurringEvent =
            new RecurringEvent(
                    "Standup",
                    start,
                    end,
                    "Daily standup",
                    "Zoom",
                    true,
                    recurringDays,
                    endRecurrence);

    Event laterEvent =
            new Event(
                    "Meeting",
                    LocalDateTime.of(2025, 11, 3, 9, 15),
                    LocalDateTime.of(2025, 11, 3, 10, 0),
                    "Team meeting",
                    "Room 1",
                    true);
    assertFalse(recurringEvent.conflictsWith(laterEvent));
  }
}