package controller;

import model.Calendar;
import model.Event;
import java.time.LocalDateTime;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

/**
 * Unit tests for the CommandParser class.
 */
public class CommandParserTest {
  private Calendar calendar;
  private CommandParser parser;

  @Before
  public void setUp() {
    calendar = new Calendar();
    parser = new CommandParser(calendar);
  }

  @Test
  public void testParseCommandBasicEvent() {
    parser.parseCommand(
            "create event --autoDecline Meeting from 2025-10-15T14:00 to 2025-10-15T15:00");
    assertEquals(1, calendar.getEventsOnDate(LocalDateTime.of(2025, 10,
            15, 14, 0)).size());
    Event event = calendar.getEventsOnDate(LocalDateTime.of(2025, 10,
            15, 14, 0)).get(0);
    assertEquals("Meeting", event.getSubject());
    assertEquals(LocalDateTime.of(2025, 10, 15,
            14, 0), event.getStartDateTime());
    assertEquals(LocalDateTime.of(2025, 10, 15,
            15, 0), event.getEndDateTime());
  }

  @Test
  public void testParseCommandInvalidCommand() {
    try {
      parser.parseCommand("invalid command");
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertTrue(e.getMessage().contains("Unknown command"));
    }
  }

  @Test
  public void testParseCommandEmptyCommand() {
    try {
      parser.parseCommand("");
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertTrue(e.getMessage().contains("Command cannot be empty"));
    }
  }

  @Test
  public void testParseCommandAllDayEvent() {
    parser.parseCommand("create event Team Meeting on 2025-10-16");
    assertEquals(1, calendar.getEventsOnDate(LocalDateTime.of(2025, 10,
            16, 0, 0)).size());
    Event event = calendar.getEventsOnDate(LocalDateTime.of(2025, 10,
            16, 0, 0)).get(0);
    assertEquals("Team Meeting", event.getSubject());
    assertEquals(LocalDateTime.of(2025, 10,
            16, 0, 0), event.getStartDateTime());
    assertEquals(null, event.getEndDateTime());
  }

  @Test
  public void testParseCommandConflictWithAutoDecline() {
    parser.parseCommand(
            "create event Meeting from 2025-10-15T14:00 to 2025-10-15T15:00");
    try {
      parser.parseCommand(
              "create event --autoDecline Workshop from 2025-10-15T14:30 to 2025-10-15T16:00");
      fail("Expected IllegalArgumentException due to conflict");
    } catch (IllegalArgumentException e) {
      assertTrue(e.getMessage().contains("conflict"));
      assertEquals(1, calendar.getEventsOnDate(LocalDateTime.of(2025, 10,
              15, 14, 0)).size());
    }
  }

  @Test
  public void testParseCommandNoConflictWithoutAutoDecline() {
    parser.parseCommand(
            "create event Meeting from 2025-10-15T14:00 to 2025-10-15T15:00");
    parser.parseCommand(
            "create event Workshop from 2025-10-15T14:30 to 2025-10-15T16:00");
    assertEquals(2, calendar.getEventsOnDate(LocalDateTime.of(2025, 10,
            15, 14, 0)).size());
  }

  @Test
  public void testParseCommandRecurringEventForTimes() {
    parser.parseCommand(
            "create event Weekly from 2025-10-15T14:00 to 2025-10-15T15:00 repeats W for 3 times");
    assertEquals(1, calendar.getEventsOnDate(LocalDateTime.of(2025, 10,
            15, 14, 0)).size());
    assertEquals(1, calendar.getEventsOnDate(LocalDateTime.of(2025, 10,
            22, 14, 0)).size());
    assertEquals(1, calendar.getEventsOnDate(LocalDateTime.of(2025, 10,
            29, 14, 0)).size());
    assertEquals(0, calendar.getEventsOnDate(LocalDateTime.of(2025, 11,
            5, 14, 0)).size());
  }

  @Test
  public void testParseCommandRecurringEventUntil() {
    parser.parseCommand(
            "create event Weekly from 2025-10-15T14:00 to 2025-10-15T15:00 repeats W until 2025-10-29T15:00");
    assertEquals(1, calendar.getEventsOnDate(LocalDateTime.of(2025, 10,
            15, 14, 0)).size());
    assertEquals(1, calendar.getEventsOnDate(LocalDateTime.of(2025, 10,
            22, 14, 0)).size());
    assertEquals(1, calendar.getEventsOnDate(LocalDateTime.of(2025, 10,
            29, 14, 0)).size());
    assertEquals(0, calendar.getEventsOnDate(LocalDateTime.of(2025, 11,
            5, 14, 0)).size());
  }

  @Test
  public void testParseCommandInvalidDateFormat() {
    try {
      parser.parseCommand(
              "create event Meeting from 2025/10/15 14:00 to 2025/10/15 15:00");
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertTrue(e.getMessage().contains("Invalid date/time format"));
    }
  }

  @Test
  public void testParseCommandEditEvent() {
    parser.parseCommand(
            "create event Meeting from 2025-10-15T14:00 to 2025-10-15T15:00");
    parser.parseCommand(
            "edit event subject Meeting from 2025-10-15T14:00 to 2025-10-15T15:00 with Team Sync");
    Event event = calendar.getEventsOnDate(LocalDateTime.of(2025, 10, 15,
            14, 0)).get(0);
    assertEquals("Team Sync", event.getSubject());
  }

  @Test
  public void testParseCommandShowStatus() {
    parser.parseCommand(
            "create event Meeting from 2025-10-15T14:00 to 2025-10-15T15:00");
    parser.parseCommand("show status on 2025-10-15T14:30");
    // Note: Can't test output directly, but can verify the command doesn't throw
  }

  @Test
  public void testParseCommandRecurringAllDayEvent() {
    parser.parseCommand(
            "create event Standup on 2025-10-15 repeats MW for 2 times");
    assertEquals(1, calendar.getEventsOnDate(LocalDateTime.of(2025, 10,
            15, 0, 0)).size());
    assertEquals(1, calendar.getEventsOnDate(LocalDateTime.of(2025, 10,
            20, 0, 0)).size()); // Monday
    assertEquals(0, calendar.getEventsOnDate(LocalDateTime.of(2025, 10,
            22, 0, 0)).size());
  }

  @Test
  public void testParseCommandInvalidRecurringFormat() {
    try {
      parser.parseCommand(
              "create event Weekly from 2025-10-15T14:00 to 2025-10-15T15:00 repeats " +
                      "XYZ for 3 times");
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      // Invalid weekdays should still process but only match valid days
    }
  }
}