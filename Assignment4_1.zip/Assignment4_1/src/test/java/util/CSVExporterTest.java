package util;

import java.io.File;
import java.time.LocalDateTime;
import model.Calendar;
import model.Event;
import org.junit.Test;

import static org.junit.Assert.assertTrue;

/**
 * Unit tests for the CSVExporter class.
 */
public class CSVExporterTest {
  /**
   * Tests exporting a calendar to a CSV file and verifying file creation.
   */
  @Test
  public void testExportToCSV() {
    Calendar calendar = new Calendar();
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    Event event = new Event("Meeting", start, end, "Team meeting",
            "Room 1", true);
    calendar.addEvent(event, false);

    String filePath = "test_calendar.csv";
    CSVExporter.exportToCSV(calendar, filePath);

    // Verify file creation (manual verification may be required)
    assertTrue(new File(filePath).exists());
  }
}