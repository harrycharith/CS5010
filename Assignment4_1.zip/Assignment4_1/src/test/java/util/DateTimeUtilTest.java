package util;

import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Unit tests for the DateTimeUtil class.
 */
public class DateTimeUtilTest {
  /**
   * Tests parsing a valid date-time string into a LocalDateTime object.
   */
  @Test
  public void testParseDateTime() {
    LocalDateTime expected = LocalDateTime.of(2025, 10, 15, 14,
            0);
    LocalDateTime actual = DateTimeUtil.parseDateTime("2025-10-15T14:00");
    assertEquals(expected, actual);
  }

  /**
   * Tests formatting a LocalDateTime object into a string.
   */
  @Test
  public void testFormatDateTime() {
    LocalDateTime dateTime = LocalDateTime.of(2025, 10, 15, 14,
            0);
    String expected = "2025-10-15T14:00";
    assertEquals(expected, DateTimeUtil.formatDateTime(dateTime));
  }

  /**
   * Tests that parsing an invalid date-time format throws a DateTimeParseException.
   */
  @Test(expected = DateTimeParseException.class)
  public void testParseDateTimeInvalidFormat() {
    DateTimeUtil.parseDateTime("2025/10/15 14:00");
  }

  /**
   * Tests that parsing a date-time with invalid values throws a DateTimeParseException.
   */
  @Test(expected = DateTimeParseException.class)
  public void testParseDateTimeInvalidValue() {
    DateTimeUtil.parseDateTime("2025-13-01T25:00"); // Invalid month and hour
  }
}