import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;
import model.Event;
import model.RecurringEvent;

public class Main {
  public static void main(String[] args) {
    // Create a single event
    LocalDateTime start1 = LocalDateTime.of(2023, 10, 15, 14, 0);
    LocalDateTime end1 = LocalDateTime.of(2023, 10, 15, 15, 0);
    Event event1 = new Event("Meeting", start1, end1, "Team meeting", "Room 1", true);

    // Create a recurring event
    LocalDateTime start2 = LocalDateTime.of(2023, 10, 16, 9, 0);
    LocalDateTime end2 = LocalDateTime.of(2023, 10, 16, 9, 30);
    LocalDateTime endRecurrence = LocalDateTime.of(2023, 10, 30, 9, 30);
    Set<DayOfWeek> recurringDays = new HashSet<>();
    recurringDays.add(DayOfWeek.MONDAY);
    recurringDays.add(DayOfWeek.WEDNESDAY);
    recurringDays.add(DayOfWeek.FRIDAY);
    RecurringEvent event2 =
            new RecurringEvent(
                    "Standup",
                    start2,
                    end2,
                    "Daily standup",
                    "Zoom",
                    true,
                    recurringDays,
                    endRecurrence);

    // Print events
    System.out.println(event1);
    System.out.println(event2);

    // Check for conflicts
    System.out.println("Conflict between event1 and event2: " + event1.conflictsWith(event2));
  }
}