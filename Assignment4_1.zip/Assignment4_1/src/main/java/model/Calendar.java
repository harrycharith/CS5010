package model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import util.CSVExporter;

/**
 * Manages a collection of events and provides methods for querying and exporting.
 */
public class Calendar {
  private List<Event> events;

  /**
   * Constructs an empty Calendar.
   */
  public Calendar() {
    this.events = new ArrayList<>();
  }

  /**
   * Adds an event to the calendar if there are no conflicts or if auto-decline is enabled.
   *
   * @param event the event to add
   * @param autoDecline if true, declines adding the event in case of conflicts
   * @return true if the event was added, false otherwise
   */
  public boolean addEvent(Event event, boolean autoDecline) {
    if (autoDecline && hasConflict(event)) {
      return false;
    }
    events.add(event);
    return true;
  }

  /**
   * Checks if the given event conflicts with any existing events.
   *
   * @param event the event to check for conflicts
   * @return true if there is a conflict, false otherwise
   */
  private boolean hasConflict(Event event) {
    return events.stream().anyMatch(existingEvent -> existingEvent.conflictsWith(event));
  }

  /**
   * Returns all events occurring on the specified date.
   *
   * @param date the date to query
   * @return a list of events on the given date
   */
  public List<Event> getEventsOnDate(LocalDateTime date) {
    List<Event> eventsOnDate = new ArrayList<>();
    for (Event event : events) {
      if (event.getStartDateTime().toLocalDate().equals(date.toLocalDate())) {
        eventsOnDate.add(event);
      }
    }
    return eventsOnDate;
  }

  /**
   * Returns a copy of all events in the calendar.
   *
   * @return a list of all events
   */
  public List<Event> getAllEvents() {
    return new ArrayList<>(events);
  }

  /**
   * Exports the calendar to a CSV file at the specified path.
   *
   * @param filePath the path to the CSV file
   */
  public void exportToCSV(String filePath) {
    CSVExporter.exportToCSV(this, filePath);
  }

  /**
   * Checks if there is an event scheduled at the specified date and time.
   *
   * @param dateTime the date and time to check
   * @return true if the user is busy, false otherwise
   */
  public boolean isBusy(LocalDateTime dateTime) {
    for (Event event : events) {
      if ((event.getStartDateTime().isBefore(dateTime)
              || event.getStartDateTime().isEqual(dateTime))
              && (event.getEndDateTime() == null || event.getEndDateTime().isAfter(dateTime))) {
        return true;
      }
    }
    return false;
  }

  /**
   * Finds an event by its subject and start time.
   *
   * @param subject the event subject
   * @param startDateTime the event start date and time
   * @return the matching event, or null if not found
   */
  public Event findEvent(String subject, LocalDateTime startDateTime) {
    for (Event event : events) {
      if (event.getSubject().equals(subject) && event.getStartDateTime().equals(startDateTime)) {
        return event;
      }
    }
    return null;
  }

  /**
   * Edits a specific property of an event.
   *
   * @param event the event to edit
   * @param property the property to modify (e.g., "subject", "location")
   * @param newValue the new value for the property
   * @throws IllegalArgumentException if the property is invalid
   */
  public void editEvent(Event event, String property, String newValue) {
    switch (property.toLowerCase()) {
      case "subject":
        event.setSubject(newValue);
        break;
      case "location":
        event.setLocation(newValue);
        break;
      case "description":
        event.setDescription(newValue);
        break;
      default:
        throw new IllegalArgumentException("Invalid property: " + property);
    }
  }
}