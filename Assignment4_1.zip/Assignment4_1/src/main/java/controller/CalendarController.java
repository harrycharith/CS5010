package controller;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;
import model.Calendar;
import model.Event;
import model.RecurringEvent;
import view.CalendarView;

/**
 * The controller for the calendar application.
 * Handles user input and updates the model and view.
 */
public class CalendarController {
  private Calendar calendar;
  private CalendarView view;

  /**
   * Constructs a CalendarController with the specified model and view.
   *
   * @param calendar the Calendar model to manage events
   * @param view the CalendarView to display updates
   */
  public CalendarController(Calendar calendar, CalendarView view) {
    this.calendar = calendar;
    this.view = view;
  }

  /**
   * Creates a single event and adds it to the calendar.
   *
   * @param subject the event subject
   * @param startDateTime the start date and time
   * @param endDateTime the end date and time
   * @param description the event description
   * @param location the event location
   * @param isPublic whether the event is public
   * @param autoDecline whether to auto-decline conflicting events
   */
  public void createEvent(
          String subject,
          LocalDateTime startDateTime,
          LocalDateTime endDateTime,
          String description,
          String location,
          boolean isPublic,
          boolean autoDecline) {
    Event event = new Event(subject, startDateTime, endDateTime, description, location, isPublic);
    boolean success = calendar.addEvent(event, autoDecline);
    if (success) {
      view.displayMessage("Event created successfully: " + event);
    } else {
      view.displayMessage("Event creation failed due to conflict.");
    }
  }

  /**
   * Creates a recurring event and adds it to the calendar.
   *
   * @param subject the event subject
   * @param startDateTime the start date and time
   * @param endDateTime the end date and time
   * @param description the event description
   * @param location the event location
   * @param isPublic whether the event is public
   * @param recurringDays the days of the week the event repeats
   * @param endRecurrence the end date for the recurrence
   * @param autoDecline whether to auto-decline conflicting events
   */
  public void createRecurringEvent(
          String subject,
          LocalDateTime startDateTime,
          LocalDateTime endDateTime,
          String description,
          String location,
          boolean isPublic,
          Set<DayOfWeek> recurringDays,
          LocalDateTime endRecurrence,
          boolean autoDecline) {
    RecurringEvent event =
            new RecurringEvent(
                    subject,
                    startDateTime,
                    endDateTime,
                    description,
                    location,
                    isPublic,
                    recurringDays,
                    endRecurrence);
    boolean success = calendar.addEvent(event, autoDecline);
    if (success) {
      view.displayMessage("Recurring event created successfully: " + event);
    } else {
      view.displayMessage("Recurring event creation failed due to conflict.");
    }
  }

  /**
   * Displays all events on a specific date.
   *
   * @param date the date to query for events
   */
  public void showEventsOnDate(LocalDateTime date) {
    List<Event> events = calendar.getEventsOnDate(date);
    view.displayEvents(events);
  }

  /**
   * Exports the calendar to a CSV file.
   *
   * @param filePath the path to the CSV file
   */
  public void exportCalendar(String filePath) {
    calendar.exportToCSV(filePath);
    view.displayMessage("Calendar exported to: " + filePath);
  }
}