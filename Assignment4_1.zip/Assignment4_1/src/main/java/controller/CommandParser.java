package controller;

import model.Calendar;
import model.Event;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Parser for calendar commands that handles creating, editing, and managing calendar events.
 * Supports single and recurring events, all-day events, and various calendar operations.
 */
public class CommandParser {
  private Calendar calendar;
  private static final DateTimeFormatter DATE_TIME_FORMATTER =
          DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");
  private static final DateTimeFormatter DATE_FORMATTER =
          DateTimeFormatter.ofPattern("yyyy-MM-dd");

  /**
   * Constructs a CommandParser with the specified calendar.
   *
   * @param calendar the calendar to operate on
   */
  public CommandParser(Calendar calendar) {
    this.calendar = calendar;
  }

  /**
   * Parses and executes a command string.
   * Supported commands: create, edit, print, export, show, exit.
   *
   * @param command the command string to parse and execute
   * @throws IllegalArgumentException if the command is invalid, empty, or null
   */
  public void parseCommand(String command) {
    if (command == null || command.trim().isEmpty()) {
      throw new IllegalArgumentException("Command cannot be empty or null");
    }

    String[] parts = command.trim().split("\\s+");

    try {
      switch (parts[0].toLowerCase()) {
        case "create":
          handleCreateCommand(command, parts);
          break;
        case "edit":
          handleEditCommand(command, parts);
          break;
        case "print":
          handlePrintCommand(parts);
          break;
        case "export":
          handleExportCommand(parts);
          break;
        case "show":
          handleShowCommand(parts);
          break;
        case "exit":
          System.exit(0);
          break;
        default:
          throw new IllegalArgumentException("Unknown command: " + parts[0]);
      }
    } catch (Exception e) {
      throw new IllegalArgumentException("Error processing command: " +
              e.getMessage(), e);
    }
  }

  /**
   * Handles the 'create' command by delegating to the appropriate event creation method.
   *
   * @param command the full command string
   * @param parts the command split into parts
   * @throws IllegalArgumentException if the command format is invalid
   */
  private void handleCreateCommand(String command, String[] parts) {
    boolean autoDecline = command.contains("--autoDecline");
    int startIndex = autoDecline ? 3 : 2;

    if (!parts[1].equalsIgnoreCase("event")) {
      throw new IllegalArgumentException("Expected 'event' after 'create'");
    }

    String commandAfterEvent = command.substring(command.indexOf("event") + 5).trim();
    int fromIndex = commandAfterEvent.indexOf("from");
    int onIndex = commandAfterEvent.indexOf("on");
    int nameStart = autoDecline ? commandAfterEvent.indexOf("--autoDecline") + 13 : 0;
    int nameEndIndex = (fromIndex != -1) ? fromIndex : (onIndex != -1) ? onIndex : -1;
    if (nameEndIndex == -1) {
      throw new IllegalArgumentException("Missing 'from' or 'on' in command");
    }
    String eventName = commandAfterEvent.substring(nameStart, nameEndIndex).trim();

    if (command.contains("on") && !command.contains("from")) {
      handleAllDayEvent(command, eventName, autoDecline);
    } else {
      // Handle regular events (with or without recurring)
      if (command.contains("repeats")) {
        handleRecurringEvent(command, eventName, autoDecline);
      } else {
        handleSingleEvent(command, eventName, autoDecline);
      }
    }
  }

  /**
   * Handles creation of a single (non-recurring) event.
   *
   * @param command the full command string
   * @param eventName the name of the event
   * @param autoDecline whether to automatically decline conflicting events
   * @throws IllegalArgumentException if the date/time format is invalid or there's a conflict
   */
  private void handleSingleEvent(String command, String eventName, boolean autoDecline) {
    Pattern pattern = Pattern.compile(
            "from (\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}) to (\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2})");
    Matcher matcher = pattern.matcher(command);

    if (!matcher.find()) {
      throw new IllegalArgumentException("Invalid date/time format for single event");
    }

    LocalDateTime start = LocalDateTime.parse(matcher.group(1), DATE_TIME_FORMATTER);
    LocalDateTime end = LocalDateTime.parse(matcher.group(2), DATE_TIME_FORMATTER);

    Event event = new Event(eventName, start, end, "", "", true);
    if (!calendar.addEvent(event, autoDecline)) {
      throw new IllegalArgumentException("Event creation failed due to conflict");
    }
  }

  /**
   * Handles creation of an all-day event (with or without recurrence).
   *
   * @param command the full command string
   * @param eventName the name of the event
   * @param autoDecline whether to automatically decline conflicting events
   * @throws IllegalArgumentException if the date format is invalid or there's a conflict
   */
  private void handleAllDayEvent(String command, String eventName, boolean autoDecline) {
    Pattern pattern = Pattern.compile("on (\\d{4}-\\d{2}-\\d{2})(?:\\s+repeats.*)?");
    Matcher matcher = pattern.matcher(command);

    if (!matcher.find()) {
      throw new IllegalArgumentException("Invalid date format for all-day event");
    }

    LocalDateTime start = LocalDateTime.parse(matcher.group(1) + "T00:00", DATE_TIME_FORMATTER);
    Event event = new Event(eventName, start, null, "", "", true);

    if (command.contains("repeats")) {
      handleRecurringAllDayEvent(command, eventName, start, autoDecline);
    } else {
      if (!calendar.addEvent(event, autoDecline)) {
        throw new IllegalArgumentException("All-day event creation failed due to conflict");
      }
    }
  }

  /**
   * Handles creation of a recurring event (non-all-day).
   *
   * @param command the full command string
   * @param eventName the name of the event
   * @param autoDecline whether to automatically decline conflicting events
   * @throws IllegalArgumentException if the format is invalid or there's a conflict
   */
  private void handleRecurringEvent(String command, String eventName, boolean autoDecline) {
    Pattern pattern = Pattern.compile(
            "from (\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}) to (\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}) " +
                    "repeats ([MTWRFSU]+) (for (\\d+) times|until (\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}))");
    Matcher matcher = pattern.matcher(command);

    if (!matcher.find()) {
      throw new IllegalArgumentException("Invalid format for recurring event");
    }

    LocalDateTime start = LocalDateTime.parse(matcher.group(1), DATE_TIME_FORMATTER);
    LocalDateTime end = LocalDateTime.parse(matcher.group(2), DATE_TIME_FORMATTER);
    String weekdays = matcher.group(3);

    if (matcher.group(5) != null) { // for N times
      int occurrences = Integer.parseInt(matcher.group(5));
      createRecurringEvents(eventName, start, end, weekdays, occurrences, autoDecline);
    } else { // until date
      LocalDateTime until = LocalDateTime.parse(matcher.group(6), DATE_TIME_FORMATTER);
      createRecurringEventsUntil(eventName, start, end, weekdays, until, autoDecline);
    }
  }

  /**
   * Handles creation of a recurring all-day event.
   *
   * @param command the full command string
   * @param eventName the name of the event
   * @param startDate the start date of the event
   * @param autoDecline whether to automatically decline conflicting events
   * @throws IllegalArgumentException if the format is invalid or there's a conflict
   */
  private void handleRecurringAllDayEvent(String command, String eventName, LocalDateTime startDate, boolean autoDecline) {
    Pattern pattern = Pattern.compile(
            "repeats ([MTWRFSU]+) (for (\\d+) times|until (\\d{4}-\\d{2}-\\d{2}))");
    Matcher matcher = pattern.matcher(command);

    if (!matcher.find()) {
      throw new IllegalArgumentException("Invalid format for recurring all-day event: " + command);
    }

    String weekdays = matcher.group(1);
    if (matcher.group(3) != null) { // for N times
      int occurrences = Integer.parseInt(matcher.group(3));
      createRecurringEvents(eventName, startDate, null, weekdays, occurrences, autoDecline);
    } else { // until date
      LocalDateTime until = LocalDateTime.parse(matcher.group(4) + "T23:59", DATE_TIME_FORMATTER);
      createRecurringEventsUntil(eventName, startDate, null, weekdays, until, autoDecline);
    }
  }

  /**
   * Creates recurring events that repeat a specified number of times.
   *
   * @param name the name of the events
   * @param start the start date and time of the first event
   * @param end the end date and time of the first event, or null for all-day events
   * @param weekdays string containing characters representing days of the week (MTWRFSU)
   * @param occurrences the number of occurrences to create
   * @param autoDecline whether to automatically decline conflicting events
   * @throws IllegalArgumentException if there's a conflict and autoDecline is true
   */
  private void createRecurringEvents(String name, LocalDateTime start, LocalDateTime end,
                                     String weekdays, int occurrences, boolean autoDecline) {
    LocalDateTime currentStart = start;
    LocalDateTime currentEnd = end;
    int count = 0;

    while (count < occurrences) {
      if (isWeekdayMatch(currentStart, weekdays)) {
        LocalDateTime eventEnd = null;
        if (currentEnd != null) {
          long hoursDiff = currentEnd.getHour() - start.getHour();
          long minutesDiff = currentEnd.getMinute() - start.getMinute();
          eventEnd = currentStart.plusHours(hoursDiff).plusMinutes(minutesDiff);
        }

        Event event = new Event(name, currentStart, eventEnd, "", "", true);
        if (!calendar.addEvent(event, autoDecline)) {
          throw new IllegalArgumentException("Recurring event creation failed due to conflict");
        }
        count++;
      }
      currentStart = currentStart.plusDays(1);
    }
  }

  /**
   * Creates recurring events that repeat until a specified date.
   *
   * @param name the name of the events
   * @param start the start date and time of the first event
   * @param end the end date and time of the first event, or null for all-day events
   * @param weekdays string containing characters representing days of the week (MTWRFSU)
   * @param until the date and time until which to create events
   * @param autoDecline whether to automatically decline conflicting events
   * @throws IllegalArgumentException if there's a conflict and autoDecline is true
   */
  private void createRecurringEventsUntil(String name, LocalDateTime start, LocalDateTime end,
                                          String weekdays, LocalDateTime until, boolean autoDecline) {
    LocalDateTime currentStart = start;

    while (currentStart.isBefore(until) || currentStart.toLocalDate().equals(until.toLocalDate())) {
      if (isWeekdayMatch(currentStart, weekdays)) {
        LocalDateTime eventEnd = null;
        if (end != null) {
          long hoursDiff = end.getHour() - start.getHour();
          long minutesDiff = end.getMinute() - start.getMinute();
          eventEnd = currentStart.plusHours(hoursDiff).plusMinutes(minutesDiff);
        }

        Event event = new Event(name, currentStart, eventEnd, "", "", true);
        if (!calendar.addEvent(event, autoDecline)) {
          throw new IllegalArgumentException("Recurring event creation failed due to conflict");
        }
      }
      currentStart = currentStart.plusDays(1);
    }
  }

  /**
   * Checks if a given date matches one of the specified weekdays.
   *
   * @param date the date to check
   * @param weekdays string containing characters representing days of the week (MTWRFSU)
   * @return true if the date's day of week is in the weekdays string
   */
  private boolean isWeekdayMatch(LocalDateTime date, String weekdays) {
    // Map Java's DayOfWeek (1-7) to MTWRFSU (0-6)
    // Monday (1) -> M (0), Tuesday (2) -> T (1), etc.
    int dayIndex = date.getDayOfWeek().getValue() - 1;
    char dayChar = "MTWRFSU".charAt(dayIndex);
    return weekdays.indexOf(dayChar) != -1;
  }

  /**
   * Handles the 'edit' command for modifying event properties.
   *
   * @param command the full command string
   * @param parts the command split into parts
   */
  private void handleEditCommand(String command, String[] parts) {
    if (parts[1].equalsIgnoreCase("event")) {
      Pattern pattern = Pattern.compile(
              "edit event (\\w+) (.+?) from (\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}) to " +
                      "(\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}) with (.+)");
      Matcher matcher = pattern.matcher(command);
      if (matcher.find()) {
        String property = matcher.group(1);
        String name = matcher.group(2);
        LocalDateTime start = LocalDateTime.parse(matcher.group(3), DATE_TIME_FORMATTER);
        String newValue = matcher.group(5);
        Event event = calendar.findEvent(name, start);
        if (event != null) {
          calendar.editEvent(event, property, newValue);
        }
      }
    }
  }

  /**
   * Handles the 'print' command for displaying calendar information.
   *
   * @param parts the command split into parts
   */
  private void handlePrintCommand(String[] parts) {
    if (parts[1].equalsIgnoreCase("events") && parts[2].equalsIgnoreCase("on")) {
      LocalDateTime date = LocalDateTime.parse(parts[3] + "T00:00", DATE_TIME_FORMATTER);
      calendar.getEventsOnDate(date).forEach(System.out::println);
    }
  }

  /**
   * Handles the 'export' command for exporting calendar data.
   *
   * @param parts the command split into parts
   */
  private void handleExportCommand(String[] parts) {
    if (parts[1].equalsIgnoreCase("cal")) {
      calendar.exportToCSV(parts[2]);
    }
  }

  /**
   * Handles the 'show' command for displaying calendar status.
   *
   * @param parts the command split into parts
   */
  private void handleShowCommand(String[] parts) {
    if (parts[1].equalsIgnoreCase("status") && parts[2].equalsIgnoreCase("on")) {
      LocalDateTime dateTime = LocalDateTime.parse(parts[3], DATE_TIME_FORMATTER);
      System.out.println(calendar.isBusy(dateTime) ? "Busy" : "Available");
    }
  }
}