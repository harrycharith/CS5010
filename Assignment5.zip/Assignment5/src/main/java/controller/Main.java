package controller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import model.Calendar;
import view.CalendarView;

public class Main {
  private static Map<String, Calendar> calendars = new HashMap<>();
  private static String currentCalendarName = null; // Track the active calendar
  private static CalendarView view = new CalendarView();
  private static CalendarController controller;

  public static void main(String[] args) {
    if (args.length > 0 && args[0].equalsIgnoreCase("--mode")) {
      String mode = args[1];
      if (mode.equalsIgnoreCase("headless")) {
        if (args.length < 3) {
          System.err.println("Error: Missing file path for headless mode.");
          return;
        }
        String filePath = args[2];
        runHeadlessMode(filePath);
      } else if (mode.equalsIgnoreCase("interactive")) {
        runInteractiveMode();
      } else {
        System.err.println("Error: Invalid mode. Use 'interactive' or 'headless'.");
      }
    } else {
      System.err.println("Error: Missing --mode argument. Use 'interactive' or 'headless'.");
    }
  }

  private static void runHeadlessMode(String filePath) {
    try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
      String command;
      while ((command = reader.readLine()) != null) {
        command = command.trim();
        if (!command.isEmpty()) {
          executeCommand(command);
        }
      }
    } catch (IOException e) {
      System.err.println("Error reading file: " + e.getMessage());
    }
  }

  private static void runInteractiveMode() {
    Scanner scanner = new Scanner(System.in);
    while (true) {
      System.out.print("> ");
      String command = scanner.nextLine().trim();
      if (command.equalsIgnoreCase("exit")) {
        break;
      }
      executeCommand(command);
    }
    scanner.close();
  }

  private static void executeCommand(String command) {
    try {
      CommandParser parser = new CommandParser();
      parser.parseCommand(command);
    } catch (IllegalArgumentException e) {
      System.err.println("Error: " + e.getMessage());
    }
  }

  // Methods to manage calendars
  public static void createCalendar(String name, String timezone) {
    if (calendars.containsKey(name)) {
      throw new IllegalArgumentException("Calendar with name '" + name + "' already exists.");
    }
    Calendar calendar = new Calendar(); // Updated constructor with timezone
    calendars.put(name, calendar);
  }

  public static Calendar getCalendar(String name) {
    Calendar calendar = calendars.get(name);
    if (calendar == null) {
      throw new IllegalArgumentException("Calendar with name '" + name + "' does not exist.");
    }
    return calendar;
  }

  public static void setCurrentCalendar(String name) {
    if (!calendars.containsKey(name)) {
      throw new IllegalArgumentException("Calendar with name '" + name + "' does not exist.");
    }
    currentCalendarName = name;
    controller = new CalendarController(calendars.get(name), view);
  }

  public static String getCurrentCalendarName() {
    return currentCalendarName;
  }

  public static void editCalendar(String oldName, String property, String newValue) {
    Calendar calendar = getCalendar(oldName);
    switch (property.toLowerCase()) {
      case "name":
        if (calendars.containsKey(newValue)) {
          throw new IllegalArgumentException("Calendar with name '" + newValue + "' already exists.");
        }
        calendars.remove(oldName);
        calendars.put(newValue, calendar);
        if (currentCalendarName != null && currentCalendarName.equals(oldName)) {
          currentCalendarName = newValue;
        }
        break;
      case "timezone":
        calendar.setTimezone(newValue);
        break;
      default:
        throw new IllegalArgumentException("Invalid property: " + property);
    }
  }
}