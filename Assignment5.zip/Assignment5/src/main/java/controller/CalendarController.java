package controller;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;
import model.Calendar;
import model.Event;
import model.RecurringEvent;
import view.CalendarView;

public class CalendarController {
  private Calendar calendar;
  private CalendarView view;

  public CalendarController(Calendar calendar, CalendarView view) {
    this.calendar = calendar;
    this.view = view;
  }

  public void createEvent(
          String subject,
          LocalDateTime startDateTime,
          LocalDateTime endDateTime,
          String description,
          String location,
          boolean isPublic) { // Removed autoDecline
    Event event = new Event(subject, startDateTime, endDateTime, description, location, isPublic);
    boolean success = calendar.addEvent(event);
    if (success) {
      view.displayMessage("Event created successfully: " + event);
    } else {
      view.displayMessage("Event creation failed due to conflict.");
    }
  }

  public void createRecurringEvent(
          String subject,
          LocalDateTime startDateTime,
          LocalDateTime endDateTime,
          String description,
          String location,
          boolean isPublic,
          Set<DayOfWeek> recurringDays,
          LocalDateTime endRecurrence) { // Removed autoDecline
    RecurringEvent event =
            new RecurringEvent(
                    subject,
                    startDateTime,
                    endDateTime,
                    description,
                    location,
                    isPublic,
                    recurringDays,
                    endRecurrence);
    boolean success = calendar.addEvent(event);
    if (success) {
      view.displayMessage("Recurring event created successfully: " + event);
    } else {
      view.displayMessage("Recurring event creation failed due to conflict.");
    }
  }

  public void showEventsOnDate(LocalDateTime date) {
    List<Event> events = calendar.getEventsOnDate(date);
    view.displayEvents(events);
  }

  public void exportCalendar(String filePath) {
    calendar.exportToCSV(filePath);
    view.displayMessage("Calendar exported to: " + filePath);
  }
}