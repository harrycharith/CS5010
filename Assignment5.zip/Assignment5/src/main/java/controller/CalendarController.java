package controller;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;
import model.Calendar;
import model.Event;
import model.RecurringEvent;
import view.CalendarView;

/**
 * Controls the creation, management, and display of calendar events.
 * Acts as an intermediary between the Calendar model and CalendarView.
 */
public class CalendarController {
  /** The calendar being managed by this controller. */
  private Calendar calendar;

  /** The view used to display calendar information. */
  private CalendarView view;

  /**
   * Constructs a new CalendarController with a specified calendar and view.
   *
   * @param calendar The calendar to be managed
   * @param view The view for displaying calendar information
   */
  public CalendarController(Calendar calendar, CalendarView view) {
    this.calendar = calendar;
    this.view = view;
  }

  /**
   * Creates a new event and attempts to add it to the calendar.
   *
   * @param subject The subject or title of the event
   * @param startDateTime The start date and time of the event
   * @param endDateTime The end date and time of the event
   * @param description A description of the event
   * @param location The location of the event
   * @param isPublic Whether the event is public or private
   */
  public void createEvent(
          String subject,
          LocalDateTime startDateTime,
          LocalDateTime endDateTime,
          String description,
          String location,
          boolean isPublic) {
    Event event = new Event(subject, startDateTime, endDateTime, description, location, isPublic);
    boolean success = calendar.addEvent(event);
    if (success) {
      view.displayMessage("Event created successfully: " + event);
    } else {
      view.displayMessage("Event creation failed due to conflict.");
    }
  }

  /**
   * Creates a new recurring event and attempts to add it to the calendar.
   *
   * @param subject The subject or title of the recurring event
   * @param startDateTime The start date and time of the recurring event
   * @param endDateTime The end date and time of a single occurrence
   * @param description A description of the recurring event
   * @param location The location of the recurring event
   * @param isPublic Whether the event is public or private
   * @param recurringDays Set of days on which the event recurs
   * @param endRecurrence The date when the recurring event series ends
   */
  public void createRecurringEvent(
          String subject,
          LocalDateTime startDateTime,
          LocalDateTime endDateTime,
          String description,
          String location,
          boolean isPublic,
          Set<DayOfWeek> recurringDays,
          LocalDateTime endRecurrence) {
    RecurringEvent event =
            new RecurringEvent(
                    subject,
                    startDateTime,
                    endDateTime,
                    description,
                    location,
                    isPublic,
                    recurringDays,
                    endRecurrence);
    boolean success = calendar.addEvent(event);
    if (success) {
      view.displayMessage("Recurring event created successfully: " + event);
    } else {
      view.displayMessage("Recurring event creation failed due to conflict.");
    }
  }

  /**
   * Displays all events scheduled on a specific date.
   *
   * @param date The date for which to show events
   */
  public void showEventsOnDate(LocalDateTime date) {
    List<Event> events = calendar.getEventsOnDate(date);
    view.displayEvents(events);
  }

  /**
   * Exports the calendar to a CSV file.
   *
   * @param filePath The file path where the CSV will be saved
   */
  public void exportCalendar(String filePath) {
    calendar.exportToCSV(filePath);
    view.displayMessage("Calendar exported to: " + filePath);
  }
}