package controller;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import model.Calendar;
import model.Event;

/**
 * Parses and processes text commands for calendar management.
 * Supports various operations like creating calendars, events, copying events, etc.
 */
public class CommandParser {
  /** Formatter for parsing date and time in "yyyy-MM-dd'T'HH:mm" format. */
  private static final DateTimeFormatter DATE_TIME_FORMATTER =
          DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");

  /** Formatter for parsing dates in "yyyy-MM-dd" format. */
  private static final DateTimeFormatter DATE_FORMATTER =
          DateTimeFormatter.ofPattern("yyyy-MM-dd");

  /** Default constructor. */
  public CommandParser() {
    // Empty constructor intentionally left blank
  }

  /**
   * Parses and processes a command string.
   *
   * @param command The command to be parsed and processed
   * @throws IllegalArgumentException If the command is invalid or cannot be processed
   */
  public void parseCommand(String command) {
    if (command == null || command.trim().isEmpty()) {
      throw new IllegalArgumentException("Command cannot be empty or null");
    }

    String[] parts = command.trim().split("\\s+");

    try {
      switch (parts[0].toLowerCase()) {
        case "create":
          if (parts[1].equalsIgnoreCase("calendar")) {
            handleCreateCalendarCommand(command);
          } else {
            handleCreateCommand(command, parts);
          }
          break;
        case "set":
          if (parts[1].equalsIgnoreCase("calendar")) {
            handleSetCalendarCommand(command);
          } else {
            throw new IllegalArgumentException("Unknown set type: " + parts[1]);
          }
          break;
        case "copy":
          if (parts[1].equalsIgnoreCase("event")) {
            handleCopyEventCommand(command);
          } else {
            throw new IllegalArgumentException("Unknown copy type: " + parts[1]);
          }
          break;
        case "export":
          if (parts[1].equalsIgnoreCase("calendar")) {
            handleExportCalendarCommand(command);
          } else {
            throw new IllegalArgumentException("Unknown export type: " + parts[1]);
          }
          break;
        default:
          throw new IllegalArgumentException("Unknown command: " + parts[0]);
      }
    } catch (Exception e) {
      throw new IllegalArgumentException("Error processing command: " + e.getMessage(), e);
    }
  }

  /**
   * Handles the creation of a new calendar command.
   *
   * @param command The full create calendar command string
   */
  private void handleCreateCalendarCommand(String command) {
    Pattern pattern = Pattern.compile("create calendar --name (\\w+) --timezone (\\S+(?:/\\S+)?)");
    Matcher matcher = pattern.matcher(command);
    if (!matcher.find()) {
      throw new IllegalArgumentException("Invalid format for create calendar command. Correct format: " +
              "create calendar --name <name> --timezone <timezone>");
    }
    String name = matcher.group(1);
    String timezone = matcher.group(2);
    Main.createCalendar(name, timezone);
  }

  /**
   * Handles the creation of different types of create commands.
   *
   * @param command The full create command string
   * @param parts The command split into parts
   */
  private void handleCreateCommand(String command, String[] parts) {
    if (parts.length < 2) {
      throw new IllegalArgumentException("Invalid create command");
    }
    if (parts[1].equalsIgnoreCase("event")) {
      if (command.contains("--allDay")) {
        handleAllDayEvent(command);
      } else {
        handleCreateEventCommand(command);
      }
    } else {
      throw new IllegalArgumentException("Unknown create type: " + parts[1]);
    }
  }

  /**
   * Handles the creation of a standard event command.
   *
   * @param command The full create event command string
   */
  private void handleCreateEventCommand(String command) {
    Pattern pattern = Pattern.compile(
            "create event --subject (\\w+) " +
                    "--start (\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}) " +
                    "--end (\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}) " +
                    "--description (\\w+) --location (\\w+) --(public|private)"
    );
    Matcher matcher = pattern.matcher(command);
    if (!matcher.find()) {
      throw new IllegalArgumentException("Invalid format for create event command. Correct format: " +
              "create event --subject <name> --start <yyyy-MM-ddTHH:mm> --end <yyyy-MM-ddTHH:mm> " +
              "--description <text> --location <text> --public/--private");
    }
    String subject = matcher.group(1);
    LocalDateTime start = LocalDateTime.parse(matcher.group(2), DATE_TIME_FORMATTER);
    LocalDateTime end = LocalDateTime.parse(matcher.group(3), DATE_TIME_FORMATTER);
    String description = matcher.group(4);
    String location = matcher.group(5);
    boolean isPublic = matcher.group(6).equalsIgnoreCase("public");

    Event event = new Event(subject, start, end, description, location, isPublic);
    if (!Main.getCalendar(Main.getCurrentCalendarName()).addEvent(event)) {
      throw new IllegalArgumentException("Event creation failed due to conflict with existing event");
    }
  }

  /**
   * Handles the creation of an all-day event command.
   *
   * @param command The full create all-day event command string
   */
  private void handleAllDayEvent(String command) {
    Pattern pattern = Pattern.compile(
            "create event --subject (\\w+) " +
                    "--allDay (\\d{4}-\\d{2}-\\d{2}) " +
                    "--description (\\w+) --location (\\w+) --(public|private)"
    );
    Matcher matcher = pattern.matcher(command);
    if (!matcher.find()) {
      throw new IllegalArgumentException("Invalid format for all-day event. Correct format: " +
              "create event --subject <name> --allDay <yyyy-MM-dd> --description <text> --location <text> --public/--private");
    }
    String subject = matcher.group(1);
    LocalDateTime date = LocalDateTime.parse(matcher.group(2) + "T00:00", DATE_TIME_FORMATTER);
    String description = matcher.group(3);
    String location = matcher.group(4);
    boolean isPublic = matcher.group(5).equalsIgnoreCase("public");

    Event event = new Event(subject, date, date.plusDays(1).minusMinutes(1), description, location, isPublic);
    if (!Main.getCalendar(Main.getCurrentCalendarName()).addEvent(event)) {
      throw new IllegalArgumentException("All-day event creation failed due to conflict with existing event");
    }
  }

  /**
   * Handles the copying of an event from one calendar to another with detailed conflict detection.
   *
   * @param command The full copy event command string
   */
  private void handleCopyEventCommand(String command) {
    Pattern pattern = Pattern.compile(
            "copy event --subject (\\w+) --start (\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}) " +
                    "--targetCalendar (\\w+) --targetStart (\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2})"
    );
    Matcher matcher = pattern.matcher(command);
    if (!matcher.find()) {
      throw new IllegalArgumentException("Invalid format for copy event command. Correct format: " +
              "copy event --subject <name> --start <yyyy-MM-ddTHH:mm> --targetCalendar <name> --targetStart <yyyy-MM-ddTHH:mm>");
    }
    String subject = matcher.group(1);
    LocalDateTime sourceStart = LocalDateTime.parse(matcher.group(2), DATE_TIME_FORMATTER);
    String targetCalendarName = matcher.group(3);
    LocalDateTime targetStart = LocalDateTime.parse(matcher.group(4), DATE_TIME_FORMATTER);

    Calendar sourceCal = Main.getCalendar(Main.getCurrentCalendarName());
    Calendar targetCal = Main.getCalendar(targetCalendarName);

    // Get all events on the source date
    List<Event> eventsToCopy = sourceCal.getEventsOnDate(sourceStart);
    if (eventsToCopy.isEmpty()) {
      throw new IllegalArgumentException("No events found to copy on " + sourceStart.format(DATE_TIME_FORMATTER));
    }

    boolean anyCopied = false;
    boolean anyConflict = false;
    StringBuilder conflictMessages = new StringBuilder();

    for (Event event : eventsToCopy) {
      if (event.getSubject().equals(subject)) {
        // Calculate new times while maintaining the same duration
        Duration duration = Duration.between(event.getStartDateTime(), event.getEndDateTime());
        LocalDateTime newStart = targetStart
                .withHour(event.getStartDateTime().getHour())
                .withMinute(event.getStartDateTime().getMinute());
        LocalDateTime newEnd = newStart.plus(duration);

        // Create a copy of the event
        Event copiedEvent = new Event(
                event.getSubject(),
                newStart,
                newEnd,
                event.getDescription(),
                event.getLocation(),
                event.isPublic()
        );

        // Try to add to target calendar
        if (targetCal.addEvent(copiedEvent)) {
          anyCopied = true;
        } else {
          anyConflict = true;
          conflictMessages.append("Conflict detected for event '")
                  .append(event.getSubject())
                  .append("' at ")
                  .append(newStart.format(DATE_TIME_FORMATTER))
                  .append("-")
                  .append(newEnd.format(DATE_TIME_FORMATTER))
                  .append("\n");
        }
      }
    }

    if (!anyCopied && !anyConflict) {
      throw new IllegalArgumentException("No events with subject '" + subject +
              "' found on " + sourceStart.format(DATE_TIME_FORMATTER));
    }

    if (anyConflict) {
      throw new IllegalArgumentException("Some events could not be copied due to conflicts:\n" +
              conflictMessages.toString() +
              (anyCopied ? "Other events were copied successfully." : ""));
    }
  }

  /**
   * Handles setting the current active calendar.
   *
   * @param command The full set calendar command string
   */
  private void handleSetCalendarCommand(String command) {
    Pattern pattern = Pattern.compile("set calendar --name (\\w+)");
    Matcher matcher = pattern.matcher(command);
    if (!matcher.find()) {
      throw new IllegalArgumentException("Invalid format for set calendar command. Correct format: " +
              "set calendar --name <calendarName>");
    }
    String name = matcher.group(1);
    Main.setCurrentCalendar(name);
  }

  /**
   * Handles exporting the current calendar to a CSV file.
   *
   * @param command The full export calendar command string
   */
  private void handleExportCalendarCommand(String command) {
    Pattern pattern = Pattern.compile("export calendar --file (\\S+)");
    Matcher matcher = pattern.matcher(command);
    if (!matcher.find()) {
      throw new IllegalArgumentException("Invalid format for export calendar command. Correct format: " +
              "export calendar --file <filePath>");
    }
    String filePath = matcher.group(1);
    Calendar currentCal = Main.getCalendar(Main.getCurrentCalendarName());
    currentCal.exportToCSV(filePath);
  }
}