package controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import model.Calendar;
import model.Event;

public class CommandParser {
  private static final DateTimeFormatter DATE_TIME_FORMATTER =
          DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");
  private static final DateTimeFormatter DATE_FORMATTER =
          DateTimeFormatter.ofPattern("yyyy-MM-dd");

  public CommandParser() {}

  public void parseCommand(String command) {
    if (command == null || command.trim().isEmpty()) {
      throw new IllegalArgumentException("Command cannot be empty or null");
    }

    String[] parts = command.trim().split("\\s+");

    try {
      switch (parts[0].toLowerCase()) {
        case "create":
          if (parts[1].equalsIgnoreCase("calendar")) {
            handleCreateCalendarCommand(command, parts);
          } else {
            handleCreateCommand(command, parts);
          }
          break;
        case "edit":
          if (parts[1].equalsIgnoreCase("calendar")) {
            handleEditCalendarCommand(command, parts);
          } else {
            handleEditCommand(command, parts);
          }
          break;
        case "use":
          handleUseCalendarCommand(parts);
          break;
        case "copy":
          handleCopyCommand(command, parts);
          break;
        case "print":
          handlePrintCommand(parts);
          break;
        case "export":
          handleExportCommand(parts);
          break;
        case "show":
          handleShowCommand(parts);
          break;
        case "exit":
          System.exit(0);
          break;
        default:
          throw new IllegalArgumentException("Unknown command: " + parts[0]);
      }
    } catch (Exception e) {
      throw new IllegalArgumentException("Error processing command: " + e.getMessage(), e);
    }
  }

  private void handleCreateCalendarCommand(String command, String[] parts) {
    Pattern pattern = Pattern.compile("create calendar --name (\\w+) --timezone (\\S+/\\S+)");
    Matcher matcher = pattern.matcher(command);
    if (!matcher.find()) {
      throw new IllegalArgumentException("Invalid format for create calendar command");
    }
    String name = matcher.group(1);
    String timezone = matcher.group(2);
    Main.createCalendar(name, timezone);
  }

  private void handleEditCalendarCommand(String command, String[] parts) {
    Pattern pattern = Pattern.compile("edit calendar --name (\\w+) --property (\\w+) (\\S+)");
    Matcher matcher = pattern.matcher(command);
    if (!matcher.find()) {
      throw new IllegalArgumentException("Invalid format for edit calendar command");
    }
    String name = matcher.group(1);
    String property = matcher.group(2);
    String newValue = matcher.group(3);
    Main.editCalendar(name, property, newValue);
  }

  private void handleUseCalendarCommand(String[] parts) {
    if (!parts[1].equalsIgnoreCase("calendar") || !parts[2].equalsIgnoreCase("--name")) {
      throw new IllegalArgumentException("Invalid format for use calendar command");
    }
    String name = parts[3];
    Main.setCurrentCalendar(name);
  }

  private void handleCreateCommand(String command, String[] parts) {
    checkCalendarInUse();
    if (!parts[1].equalsIgnoreCase("event")) {
      throw new IllegalArgumentException("Expected 'event' after 'create'");
    }

    String commandAfterEvent = command.substring(command.indexOf("event") + 5).trim();
    int fromIndex = commandAfterEvent.indexOf("from");
    int onIndex = commandAfterEvent.indexOf("on");
    int nameEndIndex = (fromIndex != -1) ? fromIndex : (onIndex != -1) ? onIndex : -1;
    if (nameEndIndex == -1) {
      throw new IllegalArgumentException("Missing 'from' or 'on' in command");
    }
    String eventName = commandAfterEvent.substring(0, nameEndIndex).trim();

    if (command.contains("on") && !command.contains("from")) {
      handleAllDayEvent(command, eventName);
    } else {
      if (command.contains("repeats")) {
        handleRecurringEvent(command, eventName);
      } else {
        handleSingleEvent(command, eventName);
      }
    }
  }

  private void handleSingleEvent(String command, String eventName) {
    Pattern pattern = Pattern.compile("from (\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}) to " +
            "(\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2})");
    Matcher matcher = pattern.matcher(command);

    if (!matcher.find()) {
      throw new IllegalArgumentException("Invalid date/time format for single event");
    }

    LocalDateTime start = LocalDateTime.parse(matcher.group(1), DATE_TIME_FORMATTER);
    LocalDateTime end = LocalDateTime.parse(matcher.group(2), DATE_TIME_FORMATTER);

    Event event = new Event(eventName, start, end, "", "", true);
    if (!Main.getCalendar(Main.getCurrentCalendarName()).addEvent(event)) {
      throw new IllegalArgumentException("Event creation failed due to conflict");
    }
  }

  private void handleAllDayEvent(String command, String eventName) {
    Pattern pattern = Pattern.compile("on (\\d{4}-\\d{2}-\\d{2})(?:\\s+repeats.*)?");
    Matcher matcher = pattern.matcher(command);

    if (!matcher.find()) {
      throw new IllegalArgumentException("Invalid date format for all-day event");
    }

    LocalDateTime start = LocalDateTime.parse(matcher.group(1) + "T00:00", DATE_TIME_FORMATTER);
    Event event = new Event(eventName, start, null, "", "", true);

    if (command.contains("repeats")) {
      handleRecurringAllDayEvent(command, eventName, start);
    } else {
      if (!Main.getCalendar(Main.getCurrentCalendarName()).addEvent(event)) {
        throw new IllegalArgumentException("All-day event creation failed due to conflict");
      }
    }
  }

  private void handleRecurringEvent(String command, String eventName) {
    Pattern pattern = Pattern.compile("from (\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}) to " +
            "(\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}) repeats ([MTWRFSU]+) " +
            "(for (\\d+) times|until (\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}))");
    Matcher matcher = pattern.matcher(command);

    if (!matcher.find()) {
      throw new IllegalArgumentException("Invalid format for recurring event");
    }

    LocalDateTime start = LocalDateTime.parse(matcher.group(1), DATE_TIME_FORMATTER);
    LocalDateTime end = LocalDateTime.parse(matcher.group(2), DATE_TIME_FORMATTER);
    String weekdays = matcher.group(3);

    if (matcher.group(5) != null) { // for N times
      int occurrences = Integer.parseInt(matcher.group(5));
      createRecurringEvents(eventName, start, end, weekdays, occurrences);
    } else { // until date
      LocalDateTime until = LocalDateTime.parse(matcher.group(6), DATE_TIME_FORMATTER);
      createRecurringEventsUntil(eventName, start, end, weekdays, until);
    }
  }

  private void handleRecurringAllDayEvent(String command, String eventName, LocalDateTime startDate) {
    Pattern pattern = Pattern.compile("repeats ([MTWRFSU]+) " +
            "(for (\\d+) times|until (\\d{4}-\\d{2}-\\d{2}))");
    Matcher matcher = pattern.matcher(command);

    if (!matcher.find()) {
      throw new IllegalArgumentException("Invalid format for recurring all-day event: " + command);
    }

    String weekdays = matcher.group(1);
    if (matcher.group(3) != null) { // for N times
      int occurrences = Integer.parseInt(matcher.group(3));
      createRecurringEvents(eventName, startDate, null, weekdays, occurrences);
    } else { // until date
      LocalDateTime until = LocalDateTime.parse(matcher.group(4) + "T23:59", DATE_TIME_FORMATTER);
      createRecurringEventsUntil(eventName, startDate, null, weekdays, until);
    }
  }

  private void createRecurringEvents(String name, LocalDateTime start, LocalDateTime end,
                                     String weekdays, int occurrences) {
    LocalDateTime currentStart = start;
    LocalDateTime currentEnd = end;
    int count = 0;

    while (count < occurrences) {
      if (isWeekdayMatch(currentStart, weekdays)) {
        LocalDateTime eventEnd = (currentEnd != null)
                ? currentStart.plusHours(currentEnd.getHour() - start.getHour())
                .plusMinutes(currentEnd.getMinute() - start.getMinute())
                : null;
        Event event = new Event(name, currentStart, eventEnd, "", "", true);
        if (!Main.getCalendar(Main.getCurrentCalendarName()).addEvent(event)) {
          throw new IllegalArgumentException("Recurring event creation failed due to conflict");
        }
        count++;
      }
      currentStart = currentStart.plusDays(1);
    }
  }

  private void createRecurringEventsUntil(String name, LocalDateTime start,
                                          LocalDateTime end, String weekdays,
                                          LocalDateTime until) {
    LocalDateTime currentStart = start;

    while (currentStart.isBefore(until) || currentStart.toLocalDate().equals(until.toLocalDate())) {
      if (isWeekdayMatch(currentStart, weekdays)) {
        LocalDateTime eventEnd = (end != null)
                ? currentStart.plusHours(end.getHour() - start.getHour())
                .plusMinutes(end.getMinute() - start.getMinute())
                : null;
        Event event = new Event(name, currentStart, eventEnd, "", "", true);
        if (!Main.getCalendar(Main.getCurrentCalendarName()).addEvent(event)) {
          throw new IllegalArgumentException("Recurring event creation failed due to conflict");
        }
      }
      currentStart = currentStart.plusDays(1);
    }
  }

  private boolean isWeekdayMatch(LocalDateTime date, String weekdays) {
    int dayIndex = date.getDayOfWeek().getValue() - 1;
    char dayChar = "MTWRFSU".charAt(dayIndex);
    return weekdays.indexOf(dayChar) != -1;
  }

  private void handleEditCommand(String command, String[] parts) {
    checkCalendarInUse();
    if (parts[1].equalsIgnoreCase("event")) {
      Pattern pattern = Pattern.compile("edit event (\\w+) (\\w+) from " +
              "(\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}) with (.+)");
      Matcher matcher = pattern.matcher(command);
      if (matcher.find()) {
        String property = matcher.group(1);
        String name = matcher.group(2);
        LocalDateTime start = LocalDateTime.parse(matcher.group(3), DATE_TIME_FORMATTER);
        String newValue = matcher.group(4);
        Calendar calendar = Main.getCalendar(Main.getCurrentCalendarName());
        List<Event> events = calendar.findEventsStartingAtOrAfter(name, start);
        if (events.isEmpty()) {
          throw new IllegalArgumentException("No events found with name '" + name + "' starting at or after " + start);
        }
        for (Event event : events) {
          calendar.editEvent(event, property, newValue);
          // Check for conflicts after editing
          List<Event> otherEvents = new ArrayList<>(calendar.getAllEvents());
          otherEvents.remove(event);
          for (Event other : otherEvents) {
            if (event.conflictsWith(other)) {
              throw new IllegalArgumentException("Editing event '" + name + "' creates a conflict with another event.");
            }
          }
        }
      } else {
        throw new IllegalArgumentException("Invalid format for edit event command");
      }
    }
  }

  private void handleCopyCommand(String command, String[] parts) {
    checkCalendarInUse();
    if (parts[1].equalsIgnoreCase("event")) {
      Pattern pattern = Pattern.compile("copy event (\\w+) on (\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}) " +
              "--target (\\w+) to (\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2})");
      Matcher matcher = pattern.matcher(command);
      if (matcher.find()) {
        String eventName = matcher.group(1);
        LocalDateTime sourceDate = LocalDateTime.parse(matcher.group(2), DATE_TIME_FORMATTER);
        String targetCalendarName = matcher.group(3);
        LocalDateTime targetDate = LocalDateTime.parse(matcher.group(4), DATE_TIME_FORMATTER);

        Calendar sourceCalendar = Main.getCalendar(Main.getCurrentCalendarName());
        Calendar targetCalendar = Main.getCalendar(targetCalendarName);
        Event event = sourceCalendar.findEvent(eventName, sourceDate);
        if (event == null) {
          throw new IllegalArgumentException("Event '" + eventName + "' not found on " + sourceDate);
        }
        sourceCalendar.copyEvent(event, targetDate, targetCalendar);
      } else {
        throw new IllegalArgumentException("Invalid format for copy event command");
      }
    } else if (parts[1].equalsIgnoreCase("events")) {
      if (command.contains("between")) {
        Pattern pattern = Pattern.compile("copy events between (\\d{4}-\\d{2}-\\d{2}) and " +
                "(\\d{4}-\\d{2}-\\d{2}) --target (\\w+) to (\\d{4}-\\d{2}-\\d{2})");
        Matcher matcher = pattern.matcher(command);
        if (matcher.find()) {
          LocalDateTime startDate = LocalDateTime.parse(matcher.group(1) + "T00:00", DATE_TIME_FORMATTER);
          LocalDateTime endDate = LocalDateTime.parse(matcher.group(2) + "T23:59", DATE_TIME_FORMATTER);
          String targetCalendarName = matcher.group(3);
          LocalDateTime targetStart = LocalDateTime.parse(matcher.group(4) + "T00:00", DATE_TIME_FORMATTER);

          Calendar sourceCalendar = Main.getCalendar(Main.getCurrentCalendarName());
          Calendar targetCalendar = Main.getCalendar(targetCalendarName);
          sourceCalendar.copyEventsInRange(startDate, endDate, targetStart, targetCalendar);
        } else {
          throw new IllegalArgumentException("Invalid format for copy events between command");
        }
      } else {
        Pattern pattern = Pattern.compile("copy events on (\\d{4}-\\d{2}-\\d{2}) " +
                "--target (\\w+) to (\\d{4}-\\d{2}-\\d{2})");
        Matcher matcher = pattern.matcher(command);
        if (matcher.find()) {
          LocalDateTime sourceDate = LocalDateTime.parse(matcher.group(1) + "T00:00", DATE_TIME_FORMATTER);
          String targetCalendarName = matcher.group(2);
          LocalDateTime targetDate = LocalDateTime.parse(matcher.group(3) + "T00:00", DATE_TIME_FORMATTER);

          Calendar sourceCalendar = Main.getCalendar(Main.getCurrentCalendarName());
          Calendar targetCalendar = Main.getCalendar(targetCalendarName);
          sourceCalendar.copyEventsOnDate(sourceDate, targetDate, targetCalendar);
        } else {
          throw new IllegalArgumentException("Invalid format for copy events on command");
        }
      }
    }
  }

  private void handlePrintCommand(String[] parts) {
    checkCalendarInUse();
    if (parts[1].equalsIgnoreCase("events") && parts[2].equalsIgnoreCase("on")) {
      LocalDateTime date = LocalDateTime.parse(parts[3] + "T00:00", DATE_TIME_FORMATTER);
      Main.getCalendar(Main.getCurrentCalendarName()).getEventsOnDate(date).forEach(System.out::println);
    }
  }

  private void handleExportCommand(String[] parts) {
    checkCalendarInUse();
    if (parts[1].equalsIgnoreCase("cal")) {
      Main.getCalendar(Main.getCurrentCalendarName()).exportToCSV(parts[2]);
    }
  }

  private void handleShowCommand(String[] parts) {
    checkCalendarInUse();
    if (parts[1].equalsIgnoreCase("status") && parts[2].equalsIgnoreCase("on")) {
      LocalDateTime dateTime = LocalDateTime.parse(parts[3], DATE_TIME_FORMATTER);
      System.out.println(Main.getCalendar(Main.getCurrentCalendarName()).isBusy(dateTime) ? "Busy" : "Available");
    }
  }

  private void checkCalendarInUse() {
    if (Main.getCurrentCalendarName() == null) {
      throw new IllegalArgumentException("No calendar in use. Use 'use calendar --name <name>' to select a calendar.");
    }
  }
}