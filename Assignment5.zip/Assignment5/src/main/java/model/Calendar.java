package model;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import util.CSVExporter;

public class Calendar {
  private List<Event> events;
  private ZoneId timezone;

  public Calendar(String timezone) {
    this.events = new ArrayList<>();
    try {
      this.timezone = ZoneId.of(timezone);
    } catch (Exception e) {
      throw new IllegalArgumentException("Invalid timezone: " + timezone);
    }
  }

  public ZoneId getTimezone() {
    return timezone;
  }

  public void setTimezone(String timezone) {
    try {
      this.timezone = ZoneId.of(timezone);  // Fixed: Convert String to ZoneId
    } catch (Exception e) {
      throw new IllegalArgumentException("Invalid timezone: " + timezone);
    }
  }

  public boolean addEvent(Event event) {
    if (hasConflict(event)) {
      return false;
    }
    events.add(event);
    return true;
  }

  private boolean hasConflict(Event event) {
    return events.stream().anyMatch(existingEvent -> existingEvent.conflictsWith(event));
  }

  public List<Event> getEventsOnDate(LocalDateTime date) {
    List<Event> eventsOnDate = new ArrayList<>();
    for (Event event : events) {
      if (event.getStartDateTime().toLocalDate().equals(date.toLocalDate())) {
        eventsOnDate.add(event);
      }
    }
    return eventsOnDate;
  }

  public List<Event> getAllEvents() {
    return new ArrayList<>(events);
  }

  public void exportToCSV(String filePath) {
    CSVExporter.exportToCSV(this, filePath);
  }

  public boolean isBusy(LocalDateTime dateTime) {
    for (Event event : events) {
      if ((event.getStartDateTime().isBefore(dateTime) || event.getStartDateTime().isEqual(dateTime))
              && (event.getEndDateTime() == null || event.getEndDateTime().isAfter(dateTime))) {
        return true;
      }
    }
    return false;
  }

  public Event findEvent(String subject, LocalDateTime startDateTime) {
    for (Event event : events) {
      if (event.getSubject().equals(subject) && event.getStartDateTime().equals(startDateTime)) {
        return event;
      }
    }
    return null;
  }

  public List<Event> findEventsStartingAtOrAfter(String subject, LocalDateTime startDateTime) {
    List<Event> matchingEvents = new ArrayList<>();
    for (Event event : events) {
      if (event.getSubject().equals(subject) &&
              (event.getStartDateTime().isEqual(startDateTime) || event.getStartDateTime().isAfter(startDateTime))) {
        matchingEvents.add(event);
      }
    }
    return matchingEvents;
  }

  public void editEvent(Event event, String property, String newValue) {
    switch (property.toLowerCase()) {
      case "subject":
        event.setSubject(newValue);
        break;
      case "location":
        event.setLocation(newValue);
        break;
      case "description":
        event.setDescription(newValue);
        break;
      default:
        throw new IllegalArgumentException("Invalid property: " + property);
    }
  }

  public void copyEvent(Event event, LocalDateTime targetStart, Calendar targetCalendar) {
    ZonedDateTime sourceStart = event.getStartDateTime().atZone(this.timezone);
    ZonedDateTime targetStartZoned = targetStart.atZone(targetCalendar.getTimezone());
    long durationMinutes = event.getEndDateTime() != null ?
            java.time.Duration.between(event.getStartDateTime(), event.getEndDateTime()).toMinutes() : 0;

    LocalDateTime newStart = targetStartZoned.withZoneSameInstant(this.timezone).toLocalDateTime();
    LocalDateTime newEnd = durationMinutes > 0 ? newStart.plusMinutes(durationMinutes) : null;

    Event copiedEvent = new Event(
            event.getSubject(),
            newStart,
            newEnd,
            event.getDescription(),
            event.getLocation(),
            event.isPublic()
    );

    if (!targetCalendar.addEvent(copiedEvent)) {
      throw new IllegalArgumentException("Cannot copy event due to conflict in target calendar.");
    }
  }

  public void copyEventsOnDate(LocalDateTime date, LocalDateTime targetStart, Calendar targetCalendar) {
    List<Event> eventsToCopy = getEventsOnDate(date);
    ZonedDateTime targetStartZoned = targetStart.atZone(targetCalendar.getTimezone());

    for (Event event : eventsToCopy) {
      ZonedDateTime sourceStart = event.getStartDateTime().atZone(this.timezone);
      ZonedDateTime sourceDayStart = date.toLocalDate().atStartOfDay(this.timezone);
      long offsetMinutes = java.time.Duration.between(sourceDayStart, sourceStart).toMinutes();

      LocalDateTime newStart = targetStartZoned.plusMinutes(offsetMinutes)
              .withZoneSameInstant(targetCalendar.getTimezone()).toLocalDateTime();
      long durationMinutes = event.getEndDateTime() != null ?
              java.time.Duration.between(event.getStartDateTime(), event.getEndDateTime()).toMinutes() : 0;
      LocalDateTime newEnd = durationMinutes > 0 ? newStart.plusMinutes(durationMinutes) : null;

      Event copiedEvent = new Event(
              event.getSubject(),
              newStart,
              newEnd,
              event.getDescription(),
              event.getLocation(),
              event.isPublic()
      );

      if (!targetCalendar.addEvent(copiedEvent)) {
        throw new IllegalArgumentException("Cannot copy event '" + event.getSubject() + "' due to conflict in target calendar.");
      }
    }
  }

  public void copyEventsInRange(LocalDateTime startDate, LocalDateTime endDate,
                                LocalDateTime targetStart, Calendar targetCalendar) {
    ZonedDateTime targetStartZoned = targetStart.atZone(targetCalendar.getTimezone());
    ZonedDateTime sourceRangeStart = startDate.toLocalDate().atStartOfDay(this.timezone);

    for (Event event : events) {
      LocalDateTime eventStart = event.getStartDateTime();
      if (eventStart.toLocalDate().isEqual(startDate.toLocalDate()) ||
              eventStart.toLocalDate().isEqual(endDate.toLocalDate()) ||
              (eventStart.toLocalDate().isAfter(startDate.toLocalDate()) &&
                      eventStart.toLocalDate().isBefore(endDate.toLocalDate()))) {
        ZonedDateTime sourceStart = eventStart.atZone(this.timezone);
        long offsetDays = java.time.Duration.between(
                sourceRangeStart, eventStart.toLocalDate().atStartOfDay(this.timezone)).toDays();
        long offsetMinutes = java.time.Duration.between(
                eventStart.toLocalDate().atStartOfDay(this.timezone), sourceStart).toMinutes();

        LocalDateTime newStart = targetStartZoned.plusDays(offsetDays).plusMinutes(offsetMinutes)
                .withZoneSameInstant(targetCalendar.getTimezone()).toLocalDateTime();
        long durationMinutes = event.getEndDateTime() != null ?
                java.time.Duration.between(event.getStartDateTime(), event.getEndDateTime()).toMinutes() : 0;
        LocalDateTime newEnd = durationMinutes > 0 ? newStart.plusMinutes(durationMinutes) : null;

        Event copiedEvent = new Event(
                event.getSubject(),
                newStart,
                newEnd,
                event.getDescription(),
                event.getLocation(),
                event.isPublic()
        );

        if (!targetCalendar.addEvent(copiedEvent)) {
          throw new IllegalArgumentException("Cannot copy event '" + event.getSubject() + "' due to conflict in target calendar.");
        }
      }
    }
  }
}