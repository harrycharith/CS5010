package model;

import java.time.LocalDateTime;

/**
 * Represents a single calendar event with a start and end time.
 */
public class Event {
  private String subject;
  private LocalDateTime startDateTime;
  private LocalDateTime endDateTime;
  private String description;
  private String location;
  private boolean isPublic;

  /**
   * Constructs a new Event with the specified properties.
   *
   * @param subject the event subject
   * @param startDateTime the start date and time
   * @param endDateTime the end date and time (can be null for all-day events)
   * @param description the event description
   * @param location the event location
   * @param isPublic whether the event is public
   */
  public Event(
          String subject,
          LocalDateTime startDateTime,
          LocalDateTime endDateTime,
          String description,
          String location,
          boolean isPublic) {
    this.subject = subject;
    this.startDateTime = startDateTime;
    this.endDateTime = endDateTime;
    this.description = description;
    this.location = location;
    this.isPublic = isPublic;
  }

  /**
   * Returns the event subject.
   *
   * @return the subject
   */
  public String getSubject() {
    return subject;
  }

  /**
   * Sets the event subject.
   *
   * @param subject the new subject
   */
  public void setSubject(String subject) {
    this.subject = subject;
  }

  /**
   * Returns the start date and time of the event.
   *
   * @return the start date and time
   */
  public LocalDateTime getStartDateTime() {
    return startDateTime;
  }

  /**
   * Sets the start date and time of the event.
   *
   * @param startDateTime the new start date and time
   */
  public void setStartDateTime(LocalDateTime startDateTime) {
    this.startDateTime = startDateTime;
  }

  /**
   * Returns the end date and time of the event.
   *
   * @return the end date and time, or null if all-day
   */
  public LocalDateTime getEndDateTime() {
    return endDateTime;
  }

  /**
   * Sets the end date and time of the event.
   *
   * @param endDateTime the new end date and time
   */
  public void setEndDateTime(LocalDateTime endDateTime) {
    this.endDateTime = endDateTime;
  }

  /**
   * Returns the event description.
   *
   * @return the description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Sets the event description.
   *
   * @param description the new description
   */
  public void setDescription(String description) {
    this.description = description;
  }

  /**
   * Returns the event location.
   *
   * @return the location
   */
  public String getLocation() {
    return location;
  }

  /**
   * Sets the event location.
   *
   * @param location the new location
   */
  public void setLocation(String location) {
    this.location = location;
  }

  /**
   * Returns whether the event is public.
   *
   * @return true if public, false otherwise
   */
  public boolean isPublic() {
    return isPublic;
  }

  /**
   * Sets whether the event is public.
   *
   * @param isPublic the new public status
   */
  public void setPublic(boolean isPublic) {
    this.isPublic = isPublic;
  }

  /**
   * Checks if this event conflicts with another event.
   *
   * @param other the other event to check for conflicts
   * @return true if there is a conflict, false otherwise
   */
  public boolean conflictsWith(Event other) {
    if (this.endDateTime == null || other.getEndDateTime() == null) {
      // All-day events conflict if they occur on the same day
      return this.startDateTime.toLocalDate().equals(other.getStartDateTime().toLocalDate());
    }
    return this.startDateTime.isBefore(other.getEndDateTime())
            && this.endDateTime.isAfter(other.getStartDateTime());
  }

  /**
   * Returns a string representation of this event.
   *
   * @return the formatted string
   */
  @Override
  public String toString() {
    return String.format(
            "Event: %s, Start: %s, End: %s, Location: %s",
            subject,
            startDateTime,
            endDateTime != null ? endDateTime : "All Day",
            location);
  }
}