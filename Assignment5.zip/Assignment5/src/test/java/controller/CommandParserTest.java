package controller;

import model.Event;
import java.time.LocalDateTime;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class CommandParserTest {
  private CommandParser parser;

  @Before
  public void setUp() {
    parser = new CommandParser();
    Main.createCalendar("default", "America/New_York");
    Main.setCurrentCalendar("default");
  }

  @Test
  public void testParseCommandBasicEvent() {
    parser.parseCommand(
            "create event Meeting from 2025-10-15T14:00 to 2025-10-15T15:00");
    assertEquals(1, Main.getCalendar("default").getEventsOnDate(LocalDateTime.of(2025, 10,
            15, 14, 0)).size());
    Event event = Main.getCalendar("default").getEventsOnDate(LocalDateTime.of(2025, 10,
            15, 14, 0)).get(0);
    assertEquals("Meeting", event.getSubject());
    assertEquals(LocalDateTime.of(2025, 10, 15, 14, 0), event.getStartDateTime());
    assertEquals(LocalDateTime.of(2025, 10, 15, 15, 0), event.getEndDateTime());
  }

  @Test
  public void testParseCommandInvalidCommand() {
    try {
      parser.parseCommand("invalid command");
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertTrue(e.getMessage().contains("Unknown command"));
    }
  }

  @Test
  public void testParseCommandEmptyCommand() {
    try {
      parser.parseCommand("");
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertTrue(e.getMessage().contains("Command cannot be empty"));
    }
  }

  @Test
  public void testParseCommandAllDayEvent() {
    parser.parseCommand("create event Team Meeting on 2025-10-16");
    assertEquals(1, Main.getCalendar("default").getEventsOnDate(LocalDateTime.of(2025, 10,
            16, 0, 0)).size());
    Event event = Main.getCalendar("default").getEventsOnDate(LocalDateTime.of(2025, 10,
            16, 0, 0)).get(0);
    assertEquals("Team Meeting", event.getSubject());
    assertEquals(LocalDateTime.of(2025, 10, 16, 0, 0), event.getStartDateTime());
    assertEquals(null, event.getEndDateTime());
  }

  @Test
  public void testParseCommandConflict() {
    parser.parseCommand(
            "create event Meeting from 2025-10-15T14:00 to 2025-10-15T15:00");
    try {
      parser.parseCommand(
              "create event Workshop from 2025-10-15T14:30 to 2025-10-15T16:00");
      fail("Expected IllegalArgumentException due to conflict");
    } catch (IllegalArgumentException e) {
      assertTrue(e.getMessage().contains("conflict"));
      assertEquals(1, Main.getCalendar("default").getEventsOnDate(LocalDateTime.of(2025, 10,
              15, 14, 0)).size());
    }
  }

  @Test
  public void testParseCommandRecurringEventForTimes() {
    parser.parseCommand(
            "create event Weekly from 2025-10-15T14:00 to 2025-10-15T15:00 repeats W for 3 times");
    assertEquals(1, Main.getCalendar("default").getEventsOnDate(LocalDateTime.of(2025, 10,
            15, 14, 0)).size());
    assertEquals(1, Main.getCalendar("default").getEventsOnDate(LocalDateTime.of(2025, 10,
            22, 14, 0)).size());
    assertEquals(1, Main.getCalendar("default").getEventsOnDate(LocalDateTime.of(2025, 10,
            29, 14, 0)).size());
    assertEquals(0, Main.getCalendar("default").getEventsOnDate(LocalDateTime.of(2025, 11,
            5, 14, 0)).size());
  }

  @Test
  public void testParseCommandRecurringEventUntil() {
    parser.parseCommand(
            "create event Weekly from 2025-10-15T14:00 to 2025-10-15T15:00 repeats W " +
                    "until 2025-10-29T15:00");
    assertEquals(1, Main.getCalendar("default").getEventsOnDate(LocalDateTime.of(2025, 10,
            15, 14, 0)).size());
    assertEquals(1, Main.getCalendar("default").getEventsOnDate(LocalDateTime.of(2025, 10,
            22, 14, 0)).size());
    assertEquals(1, Main.getCalendar("default").getEventsOnDate(LocalDateTime.of(2025, 10,
            29, 14, 0)).size());
    assertEquals(0, Main.getCalendar("default").getEventsOnDate(LocalDateTime.of(2025, 11,
            5, 14, 0)).size());
  }

  @Test
  public void testParseCommandInvalidDateFormat() {
    try {
      parser.parseCommand(
              "create event Meeting from 2025/10/15 14:00 to 2025/10/15 15:00");
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      assertTrue(e.getMessage().contains("Invalid date/time format"));
    }
  }

  @Test
  public void testParseCommandEditEvent() {
    parser.parseCommand(
            "create event Meeting from 2025-10-15T14:00 to 2025-10-15T15:00");
    parser.parseCommand(
            "create event Meeting from 2025-10-16T14:00 to 2025-10-16T15:00");
    parser.parseCommand(
            "edit event subject Meeting from 2025-10-15T14:00 with Team Sync");
    Event event1 = Main.getCalendar("default").getEventsOnDate(LocalDateTime.of(2025, 10, 15,
            14, 0)).get(0);
    Event event2 = Main.getCalendar("default").getEventsOnDate(LocalDateTime.of(2025, 10, 16,
            14, 0)).get(0);
    assertEquals("Team Sync", event1.getSubject());
    assertEquals("Team Sync", event2.getSubject());
  }

  @Test
  public void testParseCommandShowStatus() {
    parser.parseCommand(
            "create event Meeting from 2025-10-15T14:00 to 2025-10-15T15:00");
    parser.parseCommand("show status on 2025-10-15T14:30");
    LocalDateTime dateTime = LocalDateTime.of(2025, 10, 15, 14, 30);
    assertTrue(Main.getCalendar("default").isBusy(dateTime));
  }

  @Test
  public void testParseCommandRecurringAllDayEvent() {
    parser.parseCommand(
            "create event Standup on 2025-10-15 repeats MW for 2 times");
    assertEquals(1, Main.getCalendar("default").getEventsOnDate(LocalDateTime.of(2025, 10,
            15, 0, 0)).size());
    assertEquals(1, Main.getCalendar("default").getEventsOnDate(LocalDateTime.of(2025, 10,
            20, 0, 0)).size());
    assertEquals(0, Main.getCalendar("default").getEventsOnDate(LocalDateTime.of(2025, 10,
            22, 0, 0)).size());
  }

  @Test
  public void testParseCommandInvalidRecurringFormat() {
    try {
      parser.parseCommand(
              "create event Weekly from 2025-10-15T14:00 to 2025-10-15T15:00 repeats " +
                      "XYZ for 3 times");
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      // Invalid weekdays should still process but only match valid days
    }
  }

  @Test
  public void testCreateCalendar() {
    parser.parseCommand("create calendar --name testCal --timezone Europe/Paris");
    assertEquals("Europe/Paris", Main.getCalendar("testCal").getTimezone().toString());
  }

  @Test
  public void testUseCalendar() {
    parser.parseCommand("create calendar --name testCal --timezone Europe/Paris");
    parser.parseCommand("use calendar --name testCal");
    assertEquals("testCal", Main.getCurrentCalendarName());
  }

  @Test
  public void testCopyEvent() {
    parser.parseCommand("create calendar --name targetCal --timezone Asia/Tokyo");
    parser.parseCommand(
            "create event Meeting from 2025-10-15T14:00 to 2025-10-15T15:00");
    parser.parseCommand(
            "copy event Meeting on 2025-10-15T14:00 --target targetCal to 2025-10-16T14:00");
    Event copiedEvent = Main.getCalendar("targetCal").getEventsOnDate(LocalDateTime.of(2025, 10, 16, 14, 0)).get(0);
    assertEquals("Meeting", copiedEvent.getSubject());
    assertEquals(LocalDateTime.of(2025, 10, 16, 14, 0), copiedEvent.getStartDateTime());
  }
}