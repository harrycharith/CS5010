package controller;

import java.io.File;
import java.time.LocalDateTime;
import java.util.List;
import model.Calendar;
import model.Event;
import org.junit.Test;
import view.CalendarView;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class CalendarControllerTest {
  @Test
  public void testCreateEvent() {
    Calendar calendar = new Calendar();
    CalendarView view = new CalendarView();
    CalendarController controller = new CalendarController(calendar, view);

    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    controller.createEvent("Meeting", start, end, "Team meeting", "Room 1", true);

    List<Event> events = calendar.getEventsOnDate(start);
    assertEquals(1, events.size());
    assertEquals("Meeting", events.get(0).getSubject());
  }

  @Test
  public void testCreateEventWithConflict() {
    Calendar calendar = new Calendar();
    CalendarView view = new CalendarView();
    CalendarController controller = new CalendarController(calendar, view);

    LocalDateTime start1 = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end1 = LocalDateTime.of(2025, 10, 15, 15, 0);
    controller.createEvent("Meeting", start1, end1, "Team meeting", "Room 1", true);

    LocalDateTime start2 = LocalDateTime.of(2025, 10, 15, 14, 30);
    LocalDateTime end2 = LocalDateTime.of(2025, 10, 15, 16, 0);
    controller.createEvent("Workshop", start2, end2, "Java Workshop", "Room 2", true);

    List<Event> events = calendar.getEventsOnDate(start1);
    assertEquals(1, events.size()); // Second event should not be added due to conflict
  }

  @Test
  public void testShowEventsOnDate() {
    Calendar calendar = new Calendar();
    CalendarView view = new CalendarView();
    CalendarController controller = new CalendarController(calendar, view);

    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    controller.createEvent("Meeting", start, end, "Team meeting", "Room 1", true);

    controller.showEventsOnDate(start);
    List<Event> events = calendar.getEventsOnDate(start);
    assertEquals(1, events.size());
    assertEquals("Meeting", events.get(0).getSubject());
  }

  @Test
  public void testExportCalendar() {
    Calendar calendar = new Calendar();
    CalendarView view = new CalendarView();
    CalendarController controller = new CalendarController(calendar, view);

    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    controller.createEvent("Meeting", start, end, "Team meeting", "Room 1", true);

    String filePath = "test_calendar.csv";
    controller.exportCalendar(filePath);

    assertTrue(new File(filePath).exists());
  }
}