package controller;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;
import model.Calendar;
import model.Event;
import model.RecurringEvent;
import view.CalendarView;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;


/**
 * Unit tests for the CalendarController class.
 */
public class CalendarControllerTest {
  private CalendarController controller;
  private Calendar calendar;


  @Before
  public void setUp() {
    calendar = new Calendar("America/New_York");
    CalendarView view = new CalendarView();
    controller = new CalendarController(calendar, view);
  }

  @Test
  public void testCreateEvent() {
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    controller.createEvent("Meeting", start, end, "Team meeting",
            "Room 1", true);

    List<Event> events = calendar.getAllEvents();
    assertEquals(1, events.size());
    Event event = events.get(0);
    assertEquals("Meeting", event.getSubject());
    assertEquals(start, event.getStartDateTime());
    assertEquals(end, event.getEndDateTime());
    assertEquals("Team meeting", event.getDescription());
    assertEquals("Room 1", event.getLocation());
    assertTrue(event.isPublic());
  }

  @Test
  public void testCreateEventWithConflict() {
    LocalDateTime start1 = LocalDateTime.of(2025, 10, 15,
            14, 0);
    LocalDateTime end1 = LocalDateTime.of(2025, 10, 15, 15, 0);
    controller.createEvent("Meeting1", start1, end1, "Team meeting 1",
            "Room 1", true);

    LocalDateTime start2 = LocalDateTime.of(2025, 10, 15, 14,
            30);
    LocalDateTime end2 = LocalDateTime.of(2025, 10, 15, 15, 30);
    controller.createEvent("Meeting2", start2, end2, "Team meeting 2",
            "Room 2", true);

    List<Event> events = calendar.getAllEvents();
    assertEquals(1, events.size());  // Only first event should be added due to conflict
    assertEquals("Meeting1", events.get(0).getSubject());
  }

  @Test
  public void testCreateRecurringEvent() {
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    LocalDateTime endRecurrence = LocalDateTime.of(2025, 10, 22,
            23, 59);
    Set<DayOfWeek> recurringDays = EnumSet.of(DayOfWeek.WEDNESDAY);  // Oct 15, 2025 is a Wednesday

    controller.createRecurringEvent(
            "Weekly Meeting", start, end, "Weekly team sync", "Room 1",
            true, recurringDays, endRecurrence
    );

    List<Event> events = calendar.getEventsOnDate(start);
    assertEquals(1, events.size());
    Event event = events.get(0);
    assertTrue(event instanceof RecurringEvent);
    RecurringEvent recurringEvent = (RecurringEvent) event;
    assertEquals("Weekly Meeting", recurringEvent.getSubject());
    assertEquals(start, recurringEvent.getStartDateTime());
    assertEquals(end, recurringEvent.getEndDateTime());
    assertEquals(recurringDays, recurringEvent.getRecurringDays());
    assertEquals(endRecurrence, recurringEvent.getEndRecurrence());
  }

  @Test
  public void testShowEventsOnDate() {
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    controller.createEvent("Meeting", start, end, "Team meeting",
            "Room 1", true);

    LocalDateTime date = LocalDateTime.of(2025, 10, 15, 0, 0);
    controller.showEventsOnDate(date);

    List<Event> events = calendar.getEventsOnDate(date);
    assertEquals(1, events.size());
    assertEquals("Meeting", events.get(0).getSubject());

  }

  @Test
  public void testExportCalendar() {
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    controller.createEvent("Meeting", start, end, "Team meeting",
            "Room 1", true);

    String filePath = "test_export_calendar.csv";
    controller.exportCalendar(filePath);

    java.io.File file = new java.io.File(filePath);
    assertTrue(file.exists());
  }
}