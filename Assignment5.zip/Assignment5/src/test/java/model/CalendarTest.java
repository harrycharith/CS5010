package model;

import java.time.LocalDateTime;
import java.util.List;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Unit tests for the Calendar class.
 */
public class CalendarTest {
  /**
   * Tests adding an event to the calendar and verifying its presence.
   */
  @Test
  public void testAddEvent() {
    Calendar calendar = new Calendar();
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    Event event = new Event("Meeting", start, end, "Team meeting",
            "Room 1", true);

    assertTrue(calendar.addEvent(event, false));
    assertEquals(1, calendar.getEventsOnDate(start).size());
  }

  /**
   * Tests adding an event with a conflict and verifying it is declined when auto-decline is true.
   */
  @Test
  public void testAddEventWithConflict() {
    Calendar calendar = new Calendar();
    LocalDateTime start = LocalDateTime.of(2025, 10, 15, 14, 0);
    LocalDateTime end = LocalDateTime.of(2025, 10, 15, 15, 0);
    Event event1 = new Event("Meeting", start, end, "Team meeting",
            "Room 1", true);
    Event event2 =
            new Event(
                    "Workshop",
                    LocalDateTime.of(2025, 10, 15, 14, 30),
                    LocalDateTime.of(2025, 10, 15, 16, 0),
                    "Java Workshop",
                    "Room 2",
                    true);

    calendar.addEvent(event1, false);
    assertFalse(calendar.addEvent(event2, true)); // Conflict, auto-decline
  }

  /**
   * Tests retrieving events on a specific date and verifying the result.
   */
  @Test
  public void testGetEventsOnDate() {
    Calendar calendar = new Calendar();
    LocalDateTime start1 = LocalDateTime.of(2025, 10, 15, 14,
            0);
    LocalDateTime end1 = LocalDateTime.of(2025, 10, 15, 15, 0);
    Event event1 = new Event("Meeting", start1, end1, "Team meeting",
            "Room 1", true);

    LocalDateTime start2 = LocalDateTime.of(2025, 10, 16, 9, 0);
    LocalDateTime end2 = LocalDateTime.of(2025, 10, 16, 9, 30);
    Event event2 = new Event("Standup", start2, end2, "Daily standup",
            "Zoom", true);

    calendar.addEvent(event1, false);
    calendar.addEvent(event2, false);

    List<Event> eventsOnDate = calendar.getEventsOnDate(start1);
    assertEquals(1, eventsOnDate.size());
    assertEquals("Meeting", eventsOnDate.get(0).getSubject());
  }
}