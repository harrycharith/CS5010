## Instructions on How to Run the Program

1. **Open in IntelliJ**:
    - File > Open > Select project folder

2. **Run Tests**:
    - Open CommandParserTest.java or CalendarTest.java
    - Right-click > Run 'CommandParserTest'

3. **Run Interactive Mode**:
    - Run > Edit Configurations > Add Application
    - controller.Main class: controller.Main
    - Arguments: --mode interactive
    - Run the configuration

4. **Run Headless Mode**:
   - Run > Edit Configurations > Add Application
   - controller.Main class: controller.Main
   - Arguments:--mode headless res/1.txt
   - Run the configuration

## Features Status

### Working Features:
- Create single events with start/end times (`create event ... from ... to ...`)
- Create all-day events (`create event ... on ...`)
- Auto-decline option for conflict handling (`--autoDecline`)
- Recurring events with "for N times" and "until date" options
- Edit individual event properties (subject, location, description)
- Print events on a specific date (`print events on ...`)
- Show busy/available status at a specific time (`show status on ...`)
- Export to CSV (basic implementation)

### Not Fully Implemented:
- Range-based event printing (`print events from ... to ...`) - only single-day printing works
- Editing multiple events at once (`edit devents ...`) - only single event editing implemented
- Full validation of all command variations (some edge cases might not be caught)
- Pretty printing of event details (basic toString output only)


## Team Member Contributions
- **Shahana**:
    - Implemented the `Calendar` model class and `Event` class (50%)
    - Contributed to initial project setup and model-related testing
    - Worked on conflict detection and event management logic

- **Srihari**:
    - Developed the `CommandParser` class and wrote unit tests (50%)
    - Implemented the command-line interface in `CalendarApp`
    - Created documentation and handled `res/` folder contents

*Note*: Work was collaborative, with both team members contributing to debugging and refinement across all components.